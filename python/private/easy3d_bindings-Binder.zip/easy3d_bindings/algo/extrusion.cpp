#include <easy3d/algo/extrusion.h>
#include <easy3d/algo/gaussian_noise.h>
#include <easy3d/algo/point_cloud_normals.h>
#include <easy3d/algo/point_cloud_poisson_reconstruction.h>
#include <easy3d/algo/point_cloud_ransac.h>
#include <easy3d/core/point_cloud.h>
#include <easy3d/core/polygon.h>
#include <easy3d/core/surface_mesh.h>
#include <easy3d/core/vec.h>
#include <ios>
#include <memory>
#include <ostream>
#include <sstream> // __str__
#include <streambuf>
#include <string>
#include <string_view>
#include <typeinfo>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_algo_extrusion(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	// easy3d::extrude(const class std::vector<class easy3d::GenericPolygon<float> > &, float) file:easy3d/algo/extrusion.h line:49
	M("easy3d").def("extrude", (class easy3d::SurfaceMesh * (*)(const class std::vector<class easy3d::GenericPolygon<float> > &, float)) &easy3d::extrude, "Extrudes a 3D surface mesh from a set of simple contours.\n \n\n The input contours, which must be simple, i.e.,\n      - free of intersections,\n      - CCW contours defining the outer boundary and CW contours defining holes.\n      Simple contours can be obtained using the tessellator.\n \n\n The height (in the Z direction) of the extruded 3D model.\n \n\n The extruded surface mesh model. NULL on failure.\n\nC++: easy3d::extrude(const class std::vector<class easy3d::GenericPolygon<float> > &, float) --> class easy3d::SurfaceMesh *", pybind11::return_value_policy::automatic, pybind11::arg("contours"), pybind11::arg("height"));

	// easy3d::extrude(class easy3d::SurfaceMesh *, const class std::vector<class easy3d::GenericPolygon<float> > &, float) file:easy3d/algo/extrusion.h line:61
	M("easy3d").def("extrude", (bool (*)(class easy3d::SurfaceMesh *, const class std::vector<class easy3d::GenericPolygon<float> > &, float)) &easy3d::extrude, "Extrudes a 3D surface mesh from a set of simple contours.\n \n\n The output mesh model. Must be allocated before hand.\n \n\n The input contours, which must be simple, i.e.,\n      - free of intersections,\n      - CCW contours defining the outer boundary and CW contours defining holes.\n      Simple contours can be obtained using the tessellator.\n \n\n The height (in the Z direction) of the extruded 3D model.\n \n\n True on success and false on failure.\n\nC++: easy3d::extrude(class easy3d::SurfaceMesh *, const class std::vector<class easy3d::GenericPolygon<float> > &, float) --> bool", pybind11::arg("mesh"), pybind11::arg("contours"), pybind11::arg("height"));

	{ // easy3d::GaussianNoise file:easy3d/algo/gaussian_noise.h line:38
		pybind11::class_<easy3d::GaussianNoise, std::shared_ptr<easy3d::GaussianNoise>> cl(M("easy3d"), "GaussianNoise", "Add Gaussian noise to 3D models.\n \n");
		cl.def( pybind11::init( [](){ return new easy3d::GaussianNoise(); } ) );
		cl.def_static("apply", (void (*)(class easy3d::SurfaceMesh *, float)) &easy3d::GaussianNoise::apply, "Add Gaussian noise (that has a normal distribution) to the surface mesh.\n \n\n The surface mesh.\n \n\n The standard deviation of the noise distribution. So about 68 percent of the noise values are\n              within one standard deviation of the mean (mathematically, μ ± σ, where μ is the arithmetic\n              mean), about 95 percent are within two standard deviations (μ ± 2σ).\n\nC++: easy3d::GaussianNoise::apply(class easy3d::SurfaceMesh *, float) --> void", pybind11::arg("mesh"), pybind11::arg("sigma"));
		cl.def_static("apply", (void (*)(class easy3d::PointCloud *, float)) &easy3d::GaussianNoise::apply, "Add Gaussian noise (that has a normal distribution) to a point cloud.\n \n\n The point cloud.\n \n\n The standard deviation of the noise distribution. So about 68 percent of the noise values are\n              within one standard deviation of the mean (mathematically, μ ± σ, where μ is the arithmetic\n              mean), about 95 percent are within two standard deviations (μ ± 2σ).\n\nC++: easy3d::GaussianNoise::apply(class easy3d::PointCloud *, float) --> void", pybind11::arg("cloud"), pybind11::arg("sigma"));
	}
	{ // easy3d::PointCloudNormals file:easy3d/algo/point_cloud_normals.h line:38
		pybind11::class_<easy3d::PointCloudNormals, std::shared_ptr<easy3d::PointCloudNormals>> cl(M("easy3d"), "PointCloudNormals", "Estimate point cloud normals. It also allows to reorients the point cloud normals based on a minimum\n spanning tree algorithm.\n \n");
		cl.def( pybind11::init( [](){ return new easy3d::PointCloudNormals(); } ) );
		cl.def_static("estimate", [](class easy3d::PointCloud * a0) -> bool { return easy3d::PointCloudNormals::estimate(a0); }, "", pybind11::arg("cloud"));
		cl.def_static("estimate", [](class easy3d::PointCloud * a0, unsigned int const & a1) -> bool { return easy3d::PointCloudNormals::estimate(a0, a1); }, "", pybind11::arg("cloud"), pybind11::arg("k"));
		cl.def_static("estimate", (bool (*)(class easy3d::PointCloud *, unsigned int, bool)) &easy3d::PointCloudNormals::estimate, "Estimates the point cloud normals using PCA.\n \n\n The input point cloud.\n \n\n the number of neighboring points to construct the covariance matrix.\n \n\n also computes the curvature?\n\nC++: easy3d::PointCloudNormals::estimate(class easy3d::PointCloud *, unsigned int, bool) --> bool", pybind11::arg("cloud"), pybind11::arg("k"), pybind11::arg("compute_curvature"));
		cl.def_static("reorient", [](class easy3d::PointCloud * a0) -> bool { return easy3d::PointCloudNormals::reorient(a0); }, "", pybind11::arg("cloud"));
		cl.def_static("reorient", (bool (*)(class easy3d::PointCloud *, unsigned int)) &easy3d::PointCloudNormals::reorient, "Reorients the point cloud normals.\n This method implements the normal reorientation method described in\n Hoppe et al. Surface reconstruction from unorganized points. SIGGRAPH 1992.\n \n\n The input point cloud.\n \n\n the number of neighboring points to construct the graph.\n\nC++: easy3d::PointCloudNormals::reorient(class easy3d::PointCloud *, unsigned int) --> bool", pybind11::arg("cloud"), pybind11::arg("k"));
	}
	{ // easy3d::PoissonReconstruction file:easy3d/algo/point_cloud_poisson_reconstruction.h line:41
		pybind11::class_<easy3d::PoissonReconstruction, std::shared_ptr<easy3d::PoissonReconstruction>> cl(M("easy3d"), "PoissonReconstruction", "Poisson surface reconstruction.\n \n");
		cl.def( pybind11::init( [](){ return new easy3d::PoissonReconstruction(); } ) );
		cl.def("set_depth", (void (easy3d::PoissonReconstruction::*)(int)) &easy3d::PoissonReconstruction::set_depth, "Set reconstruction depth.\n This integer is the maximum depth of the tree that will be used for surface reconstruction. Running at depth\n d corresponds to solving on a voxel grid whose resolution is no larger than 2^d x 2^d x 2^d. Note that since\n the reconstructor adapts the octree to the sampling density, the specified reconstruction depth is only an\n upper bound. The default value for this parameter is 8.\n\nC++: easy3d::PoissonReconstruction::set_depth(int) --> void", pybind11::arg("d"));
		cl.def("set_samples_per_node", (void (easy3d::PoissonReconstruction::*)(float)) &easy3d::PoissonReconstruction::set_samples_per_node, "Set the minimum number of samples.\n This floating point value specifies the minimum number of sample points that should fall within an octree\n node as the octree construction is adapted to sampling density. For noise-free samples, small values in the\n range [1.0 - 5.0] can be used. For more noisy samples, larger values in the range [15.0 - 20.0] may be needed\n to provide a smoother, noise-reduced, reconstruction. The default value is 1.0.\n\nC++: easy3d::PoissonReconstruction::set_samples_per_node(float) --> void", pybind11::arg("s"));
		cl.def("apply", [](easy3d::PoissonReconstruction const &o, const class easy3d::PointCloud * a0) -> easy3d::SurfaceMesh * { return o.apply(a0); }, "", pybind11::return_value_policy::automatic, pybind11::arg("cloud"));
		cl.def("apply", (class easy3d::SurfaceMesh * (easy3d::PoissonReconstruction::*)(const class easy3d::PointCloud *, const std::string &) const) &easy3d::PoissonReconstruction::apply, "reconstruction\n\nC++: easy3d::PoissonReconstruction::apply(const class easy3d::PointCloud *, const std::string &) const --> class easy3d::SurfaceMesh *", pybind11::return_value_policy::automatic, pybind11::arg("cloud"), pybind11::arg("density_attr_name"));
		cl.def_static("trim", (class easy3d::SurfaceMesh * (*)(class easy3d::SurfaceMesh *, const std::string &, float, float, bool)) &easy3d::PoissonReconstruction::trim, "Trim the reconstructed surface model based on the density attribute.\n\nC++: easy3d::PoissonReconstruction::trim(class easy3d::SurfaceMesh *, const std::string &, float, float, bool) --> class easy3d::SurfaceMesh *", pybind11::return_value_policy::automatic, pybind11::arg("mesh"), pybind11::arg("density_attr_name"), pybind11::arg("trim_value"), pybind11::arg("area_ratio"), pybind11::arg("triangulate"));
		cl.def("set_full_depth", (void (easy3d::PoissonReconstruction::*)(int)) &easy3d::PoissonReconstruction::set_full_depth, "Other parameters for Poisson surface reconstruction algorithm.\n These parameters are usually not needed\n\nC++: easy3d::PoissonReconstruction::set_full_depth(int) --> void", pybind11::arg("v"));
		cl.def("set_cg_depth", (void (easy3d::PoissonReconstruction::*)(int)) &easy3d::PoissonReconstruction::set_cg_depth, "C++: easy3d::PoissonReconstruction::set_cg_depth(int) --> void", pybind11::arg("v"));
		cl.def("set_scale", (void (easy3d::PoissonReconstruction::*)(float)) &easy3d::PoissonReconstruction::set_scale, "C++: easy3d::PoissonReconstruction::set_scale(float) --> void", pybind11::arg("v"));
		cl.def("set_point_weight", (void (easy3d::PoissonReconstruction::*)(float)) &easy3d::PoissonReconstruction::set_point_weight, "C++: easy3d::PoissonReconstruction::set_point_weight(float) --> void", pybind11::arg("v"));
		cl.def("set_gs_iter", (void (easy3d::PoissonReconstruction::*)(int)) &easy3d::PoissonReconstruction::set_gs_iter, "C++: easy3d::PoissonReconstruction::set_gs_iter(int) --> void", pybind11::arg("v"));
		cl.def("set_verbose", (void (easy3d::PoissonReconstruction::*)(bool)) &easy3d::PoissonReconstruction::set_verbose, "C++: easy3d::PoissonReconstruction::set_verbose(bool) --> void", pybind11::arg("v"));
	}
	{ // easy3d::PrimitivesRansac file:easy3d/algo/point_cloud_ransac.h line:52
		pybind11::class_<easy3d::PrimitivesRansac, std::shared_ptr<easy3d::PrimitivesRansac>> cl(M("easy3d"), "PrimitivesRansac", "Extract primitives from point clouds using RANSAC.\n \n\n\n Usage example:\n  \n\n\n\n\n\n     ");
		cl.def( pybind11::init( [](){ return new easy3d::PrimitivesRansac(); } ) );
		cl.def( pybind11::init( [](easy3d::PrimitivesRansac const &o){ return new easy3d::PrimitivesRansac(o); } ) );

		pybind11::enum_<easy3d::PrimitivesRansac::PrimType>(cl, "PrimType", pybind11::arithmetic(), "")
			.value("PLANE", easy3d::PrimitivesRansac::PLANE)
			.value("SPHERE", easy3d::PrimitivesRansac::SPHERE)
			.value("CYLINDER", easy3d::PrimitivesRansac::CYLINDER)
			.value("CONE", easy3d::PrimitivesRansac::CONE)
			.value("TORUS", easy3d::PrimitivesRansac::TORUS)
			.value("UNKNOWN", easy3d::PrimitivesRansac::UNKNOWN)
			.export_values();

		cl.def("add_primitive_type", (void (easy3d::PrimitivesRansac::*)(enum easy3d::PrimitivesRansac::PrimType)) &easy3d::PrimitivesRansac::add_primitive_type, "Setup the primitive types to be extracted.\n \n\n This is done by adding the interested primitive types one by one.\n\nC++: easy3d::PrimitivesRansac::add_primitive_type(enum easy3d::PrimitivesRansac::PrimType) --> void", pybind11::arg("t"));
		cl.def("remove_primitive_type", (void (easy3d::PrimitivesRansac::*)(enum easy3d::PrimitivesRansac::PrimType)) &easy3d::PrimitivesRansac::remove_primitive_type, "Exclude a primitive types to be extracted.\n \n\n This is done by removing the primitive type from the existing list.\n\nC++: easy3d::PrimitivesRansac::remove_primitive_type(enum easy3d::PrimitivesRansac::PrimType) --> void", pybind11::arg("t"));
		cl.def("detect", [](easy3d::PrimitivesRansac &o, class easy3d::PointCloud * a0) -> int { return o.detect(a0); }, "", pybind11::arg("cloud"));
		cl.def("detect", [](easy3d::PrimitivesRansac &o, class easy3d::PointCloud * a0, unsigned int const & a1) -> int { return o.detect(a0, a1); }, "", pybind11::arg("cloud"), pybind11::arg("min_support"));
		cl.def("detect", [](easy3d::PrimitivesRansac &o, class easy3d::PointCloud * a0, unsigned int const & a1, float const & a2) -> int { return o.detect(a0, a1, a2); }, "", pybind11::arg("cloud"), pybind11::arg("min_support"), pybind11::arg("dist_threshold"));
		cl.def("detect", [](easy3d::PrimitivesRansac &o, class easy3d::PointCloud * a0, unsigned int const & a1, float const & a2, float const & a3) -> int { return o.detect(a0, a1, a2, a3); }, "", pybind11::arg("cloud"), pybind11::arg("min_support"), pybind11::arg("dist_threshold"), pybind11::arg("bitmap_resolution"));
		cl.def("detect", [](easy3d::PrimitivesRansac &o, class easy3d::PointCloud * a0, unsigned int const & a1, float const & a2, float const & a3, float const & a4) -> int { return o.detect(a0, a1, a2, a3, a4); }, "", pybind11::arg("cloud"), pybind11::arg("min_support"), pybind11::arg("dist_threshold"), pybind11::arg("bitmap_resolution"), pybind11::arg("normal_threshold"));
		cl.def("detect", (int (easy3d::PrimitivesRansac::*)(class easy3d::PointCloud *, unsigned int, float, float, float, float)) &easy3d::PrimitivesRansac::detect, "Extract primitives from a point cloud.\n \n\n The extracted primitives are stored as properties:\n      - \"v:primitive_type\"  (one of PLANE, SPHERE, CYLINDER, CONE, TORUS, and UNKNOWN)\n      - \"v:primitive_index\" (-1, 0, 1, 2...). -1 meaning a vertex does not belong to any primitive (thus its\n        primitive_type must be UNKNOWN.\n \n\n The input point cloud.\n \n\n The minimal number of points required for a primitive.\n \n\n The distance threshold, defined relative to the bounding box's max dimension.\n \n\n The bitmap resolution, defined relative to the bounding box width.\n \n\n The cosine of the maximal normal deviation.\n \n\n The probability with which a primitive is overlooked.\n \n\n The number of extracted primitives.\n\nC++: easy3d::PrimitivesRansac::detect(class easy3d::PointCloud *, unsigned int, float, float, float, float) --> int", pybind11::arg("cloud"), pybind11::arg("min_support"), pybind11::arg("dist_threshold"), pybind11::arg("bitmap_resolution"), pybind11::arg("normal_threshold"), pybind11::arg("overlook_probability"));
		cl.def("detect", [](easy3d::PrimitivesRansac &o, class easy3d::PointCloud * a0, const class std::vector<int> & a1) -> int { return o.detect(a0, a1); }, "", pybind11::arg("cloud"), pybind11::arg("vertices"));
		cl.def("detect", [](easy3d::PrimitivesRansac &o, class easy3d::PointCloud * a0, const class std::vector<int> & a1, unsigned int const & a2) -> int { return o.detect(a0, a1, a2); }, "", pybind11::arg("cloud"), pybind11::arg("vertices"), pybind11::arg("min_support"));
		cl.def("detect", [](easy3d::PrimitivesRansac &o, class easy3d::PointCloud * a0, const class std::vector<int> & a1, unsigned int const & a2, float const & a3) -> int { return o.detect(a0, a1, a2, a3); }, "", pybind11::arg("cloud"), pybind11::arg("vertices"), pybind11::arg("min_support"), pybind11::arg("dist_threshold"));
		cl.def("detect", [](easy3d::PrimitivesRansac &o, class easy3d::PointCloud * a0, const class std::vector<int> & a1, unsigned int const & a2, float const & a3, float const & a4) -> int { return o.detect(a0, a1, a2, a3, a4); }, "", pybind11::arg("cloud"), pybind11::arg("vertices"), pybind11::arg("min_support"), pybind11::arg("dist_threshold"), pybind11::arg("bitmap_resolution"));
		cl.def("detect", [](easy3d::PrimitivesRansac &o, class easy3d::PointCloud * a0, const class std::vector<int> & a1, unsigned int const & a2, float const & a3, float const & a4, float const & a5) -> int { return o.detect(a0, a1, a2, a3, a4, a5); }, "", pybind11::arg("cloud"), pybind11::arg("vertices"), pybind11::arg("min_support"), pybind11::arg("dist_threshold"), pybind11::arg("bitmap_resolution"), pybind11::arg("normal_threshold"));
		cl.def("detect", (int (easy3d::PrimitivesRansac::*)(class easy3d::PointCloud *, const class std::vector<int> &, unsigned int, float, float, float, float)) &easy3d::PrimitivesRansac::detect, "Extract primitives from a subset of a point cloud..\n \n\n The extracted primitives are stored as properties:\n      - \"v:primitive_type\"  (one of PLANE, SPHERE, CYLINDER, CONE, TORUS, and UNKNOWN)\n      - \"v:primitive_index\" (-1, 0, 1, 2...). -1 meaning a vertex does not belong to any primitive (thus its\n        primitive_type must be UNKNOWN.\n \n\n The input point cloud.\n \n\n The indices of the subset of the input point cloud.\n \n\n The minimal number of points required for a primitive.\n \n\n The distance threshold, defined relative to the bounding box's max dimension.\n \n\n The bitmap resolution, defined relative to the bounding box width.\n \n\n The cosine of the maximal normal deviation.\n \n\n The probability with which a primitive is overlooked.\n \n\n The number of extracted primitives.\n\nC++: easy3d::PrimitivesRansac::detect(class easy3d::PointCloud *, const class std::vector<int> &, unsigned int, float, float, float, float) --> int", pybind11::arg("cloud"), pybind11::arg("vertices"), pybind11::arg("min_support"), pybind11::arg("dist_threshold"), pybind11::arg("bitmap_resolution"), pybind11::arg("normal_threshold"), pybind11::arg("overlook_probability"));
		cl.def("get_planes", (const class std::vector<struct easy3d::PrimitivesRansac::PlanePrim> & (easy3d::PrimitivesRansac::*)() const) &easy3d::PrimitivesRansac::get_planes, "C++: easy3d::PrimitivesRansac::get_planes() const --> const class std::vector<struct easy3d::PrimitivesRansac::PlanePrim> &", pybind11::return_value_policy::automatic);
		cl.def("get_cylinders", (const class std::vector<struct easy3d::PrimitivesRansac::CylinderPrim> & (easy3d::PrimitivesRansac::*)() const) &easy3d::PrimitivesRansac::get_cylinders, "C++: easy3d::PrimitivesRansac::get_cylinders() const --> const class std::vector<struct easy3d::PrimitivesRansac::CylinderPrim> &", pybind11::return_value_policy::automatic);
		cl.def("assign", (class easy3d::PrimitivesRansac & (easy3d::PrimitivesRansac::*)(const class easy3d::PrimitivesRansac &)) &easy3d::PrimitivesRansac::operator=, "C++: easy3d::PrimitivesRansac::operator=(const class easy3d::PrimitivesRansac &) --> class easy3d::PrimitivesRansac &", pybind11::return_value_policy::automatic, pybind11::arg(""));

		{ // easy3d::PrimitivesRansac::PlanePrim file:easy3d/algo/point_cloud_ransac.h line:126
			auto & enclosing_class = cl;
			pybind11::class_<easy3d::PrimitivesRansac::PlanePrim, std::shared_ptr<easy3d::PrimitivesRansac::PlanePrim>> cl(enclosing_class, "PlanePrim", "");
			cl.def( pybind11::init( [](){ return new easy3d::PrimitivesRansac::PlanePrim(); } ) );
			cl.def( pybind11::init( [](easy3d::PrimitivesRansac::PlanePrim const &o){ return new easy3d::PrimitivesRansac::PlanePrim(o); } ) );
			cl.def_readwrite("primitive_index", &easy3d::PrimitivesRansac::PlanePrim::primitive_index);
			cl.def_readwrite("vertices", &easy3d::PrimitivesRansac::PlanePrim::vertices);
			cl.def_readwrite("plane", &easy3d::PrimitivesRansac::PlanePrim::plane);
			cl.def_readwrite("position", &easy3d::PrimitivesRansac::PlanePrim::position);
			cl.def_readwrite("normal", &easy3d::PrimitivesRansac::PlanePrim::normal);
			cl.def("assign", (struct easy3d::PrimitivesRansac::PlanePrim & (easy3d::PrimitivesRansac::PlanePrim::*)(const struct easy3d::PrimitivesRansac::PlanePrim &)) &easy3d::PrimitivesRansac::PlanePrim::operator=, "C++: easy3d::PrimitivesRansac::PlanePrim::operator=(const struct easy3d::PrimitivesRansac::PlanePrim &) --> struct easy3d::PrimitivesRansac::PlanePrim &", pybind11::return_value_policy::automatic, pybind11::arg(""));
		}

		{ // easy3d::PrimitivesRansac::CylinderPrim file:easy3d/algo/point_cloud_ransac.h line:135
			auto & enclosing_class = cl;
			pybind11::class_<easy3d::PrimitivesRansac::CylinderPrim, std::shared_ptr<easy3d::PrimitivesRansac::CylinderPrim>> cl(enclosing_class, "CylinderPrim", "");
			cl.def( pybind11::init( [](){ return new easy3d::PrimitivesRansac::CylinderPrim(); } ) );
			cl.def( pybind11::init( [](easy3d::PrimitivesRansac::CylinderPrim const &o){ return new easy3d::PrimitivesRansac::CylinderPrim(o); } ) );
			cl.def_readwrite("primitive_index", &easy3d::PrimitivesRansac::CylinderPrim::primitive_index);
			cl.def_readwrite("vertices", &easy3d::PrimitivesRansac::CylinderPrim::vertices);
			cl.def_readwrite("radius", &easy3d::PrimitivesRansac::CylinderPrim::radius);
			cl.def_readwrite("position", &easy3d::PrimitivesRansac::CylinderPrim::position);
			cl.def_readwrite("direction", &easy3d::PrimitivesRansac::CylinderPrim::direction);
			cl.def("assign", (struct easy3d::PrimitivesRansac::CylinderPrim & (easy3d::PrimitivesRansac::CylinderPrim::*)(const struct easy3d::PrimitivesRansac::CylinderPrim &)) &easy3d::PrimitivesRansac::CylinderPrim::operator=, "C++: easy3d::PrimitivesRansac::CylinderPrim::operator=(const struct easy3d::PrimitivesRansac::CylinderPrim &) --> struct easy3d::PrimitivesRansac::CylinderPrim &", pybind11::return_value_policy::automatic, pybind11::arg(""));
		}

	}
}
