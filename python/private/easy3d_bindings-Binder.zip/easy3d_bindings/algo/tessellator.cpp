#include <easy3d/algo/tessellator.h>
#include <easy3d/core/polygon.h>
#include <memory>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_algo_tessellator(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	// easy3d::csg::tessellate(class std::vector<class easy3d::GenericPolygon<float> > &, enum easy3d::Tessellator::WindingRule) file:easy3d/algo/tessellator.h line:280
	M("easy3d::csg").def("tessellate", (void (*)(class std::vector<class easy3d::GenericPolygon<float> > &, enum easy3d::Tessellator::WindingRule)) &easy3d::csg::tessellate, "Tessellate a set of polygons of an unknown structure into simple contours according to the winding\n rule. Useful for complex CSG operations.\n The resulting polygons will have the following properties:\n  - free of intersections,\n  - CCW contours define the outer boundary and CW contours define holes.\n \n\n The input polygons, and the result on return.\n  The winding rule to determine the interior and exterior of the complex shape.\n\nC++: easy3d::csg::tessellate(class std::vector<class easy3d::GenericPolygon<float> > &, enum easy3d::Tessellator::WindingRule) --> void", pybind11::arg("polygons"), pybind11::arg("rule"));

	// easy3d::csg::union_of(class std::vector<class easy3d::GenericPolygon<float> > &) file:easy3d/algo/tessellator.h line:286
	M("easy3d::csg").def("union_of", (void (*)(class std::vector<class easy3d::GenericPolygon<float> > &)) &easy3d::csg::union_of, "Compute the union of a set of polygons.\n \n\n The input polygons, and the result on return.\n\nC++: easy3d::csg::union_of(class std::vector<class easy3d::GenericPolygon<float> > &) --> void", pybind11::arg("polygons"));

}
