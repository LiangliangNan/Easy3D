#include <easy3d/algo/surface_mesh_hole_filling.h>
#include <easy3d/algo/surface_mesh_parameterization.h>
#include <easy3d/algo/surface_mesh_polygonization.h>
#include <easy3d/algo/surface_mesh_remeshing.h>
#include <easy3d/algo/surface_mesh_sampler.h>
#include <easy3d/algo/surface_mesh_simplification.h>
#include <easy3d/core/point_cloud.h>
#include <easy3d/core/surface_mesh.h>
#include <easy3d/core/vec.h>
#include <memory>
#include <ostream>
#include <sstream> // __str__
#include <string>
#include <string_view>
#include <typeinfo>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_algo_surface_mesh_hole_filling(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	{ // easy3d::SurfaceMeshHoleFilling file:easy3d/algo/surface_mesh_hole_filling.h line:31
		pybind11::class_<easy3d::SurfaceMeshHoleFilling, std::shared_ptr<easy3d::SurfaceMeshHoleFilling>> cl(M("easy3d"), "SurfaceMeshHoleFilling", "This class closes simple holes in a surface mesh.\n \n\n\n \n It closes simple holes (boundary loops of manifold vertices) by first filling the hole with an\n angle/area-minimizing triangulation, followed by isometric remeshing, and finished by curvature-minimizing\n fairing of the filled-in patch. See the following paper for more details:\n  - Peter Liepa. Filling holes in meshes. SGP, pages 200–205, 2003.");
		cl.def( pybind11::init<class easy3d::SurfaceMesh *>(), pybind11::arg("mesh") );

		cl.def( pybind11::init( [](easy3d::SurfaceMeshHoleFilling const &o){ return new easy3d::SurfaceMeshHoleFilling(o); } ) );
		cl.def("fill_hole", (bool (easy3d::SurfaceMeshHoleFilling::*)(struct easy3d::SurfaceMesh::Halfedge)) &easy3d::SurfaceMeshHoleFilling::fill_hole, "fill the hole specified by halfedge h\n\nC++: easy3d::SurfaceMeshHoleFilling::fill_hole(struct easy3d::SurfaceMesh::Halfedge) --> bool", pybind11::arg("h"));
		cl.def("assign", (class easy3d::SurfaceMeshHoleFilling & (easy3d::SurfaceMeshHoleFilling::*)(const class easy3d::SurfaceMeshHoleFilling &)) &easy3d::SurfaceMeshHoleFilling::operator=, "C++: easy3d::SurfaceMeshHoleFilling::operator=(const class easy3d::SurfaceMeshHoleFilling &) --> class easy3d::SurfaceMeshHoleFilling &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::SurfaceMeshParameterization file:easy3d/algo/surface_mesh_parameterization.h line:28
		pybind11::class_<easy3d::SurfaceMeshParameterization, std::shared_ptr<easy3d::SurfaceMeshParameterization>> cl(M("easy3d"), "SurfaceMeshParameterization", "A class for surface parameterization.\n \n\n\n \n It implements two parameterization methods described in the following papers:\n  - Bruno Lévy et al. Least squares conformal maps for automatic texture atlas generation. SIGGRAPH, 2002.\n  - Mathieu Desbrun et al. Intrinsic parameterizations of surface meshes. CGF, 21(3):209–218, 2002.");
		cl.def( pybind11::init<class easy3d::SurfaceMesh *>(), pybind11::arg("mesh") );

		cl.def("harmonic", [](easy3d::SurfaceMeshParameterization &o) -> void { return o.harmonic(); }, "");
		cl.def("harmonic", (void (easy3d::SurfaceMeshParameterization::*)(bool)) &easy3d::SurfaceMeshParameterization::harmonic, "Compute discrete harmonic parameterization.\n\nC++: easy3d::SurfaceMeshParameterization::harmonic(bool) --> void", pybind11::arg("use_uniform_weights"));
		cl.def("lscm", (void (easy3d::SurfaceMeshParameterization::*)()) &easy3d::SurfaceMeshParameterization::lscm, "Compute parameterization based on least squares conformal mapping.\n\nC++: easy3d::SurfaceMeshParameterization::lscm() --> void");
	}
	{ // easy3d::SurfaceMeshPolygonization file:easy3d/algo/surface_mesh_polygonization.h line:40
		pybind11::class_<easy3d::SurfaceMeshPolygonization, std::shared_ptr<easy3d::SurfaceMeshPolygonization>> cl(M("easy3d"), "SurfaceMeshPolygonization", "Merge connected coplanar faces into a general polygon face.\n \n\n\n \n Support faces with holes (i.e., polygons with multiple contours)");
		cl.def( pybind11::init( [](){ return new easy3d::SurfaceMeshPolygonization(); } ) );
		cl.def("apply", [](easy3d::SurfaceMeshPolygonization &o, class easy3d::SurfaceMesh * a0) -> void { return o.apply(a0); }, "", pybind11::arg("mesh"));
		cl.def("apply", (void (easy3d::SurfaceMeshPolygonization::*)(class easy3d::SurfaceMesh *, float)) &easy3d::SurfaceMeshPolygonization::apply, "Merges connected coplanar faces into a general polygon face.\n \n\n The result is a general polygonal mesh.\n \n\n The input surface mesh. Upon return, the mesh will be modified.\n \n\n Two faces sharing a common edge are considered coplanar if the dihedral angle is\n      smaller than  (in degrees).\n \n\n The current implementation doesn't support polygon faces with holes.\n\nC++: easy3d::SurfaceMeshPolygonization::apply(class easy3d::SurfaceMesh *, float) --> void", pybind11::arg("mesh"), pybind11::arg("angle_threshold"));
		cl.def("merge_colinear_edges", [](easy3d::SurfaceMeshPolygonization &o, class easy3d::SurfaceMesh * a0) -> void { return o.merge_colinear_edges(a0); }, "", pybind11::arg("mesh"));
		cl.def("merge_colinear_edges", (void (easy3d::SurfaceMeshPolygonization::*)(class easy3d::SurfaceMesh *, float)) &easy3d::SurfaceMeshPolygonization::merge_colinear_edges, "Removes 2-degree vertices.\n \n\n For every 2-degree vertex, if the angle between its two incident edges is smaller than a threshold,\n merge the two incident edges by removing this vertex.\n \n\n The input surface mesh. Upon return, the mesh will be modified.\n \n\n Two edges sharing the same vertex are considered colinear if their angle is smaller\n      than  (in degrees).\n\nC++: easy3d::SurfaceMeshPolygonization::merge_colinear_edges(class easy3d::SurfaceMesh *, float) --> void", pybind11::arg("mesh"), pybind11::arg("angle_threshold"));
	}
	{ // easy3d::SurfaceMeshRemeshing file:easy3d/algo/surface_mesh_remeshing.h line:31
		pybind11::class_<easy3d::SurfaceMeshRemeshing, std::shared_ptr<easy3d::SurfaceMeshRemeshing>> cl(M("easy3d"), "SurfaceMeshRemeshing", "A class for uniform and adaptive surface remeshing.\n\n \n\n \n The algorithm implemented here performs incremental remeshing based on edge collapse, split, flip,\n and tangential relaxation. See the following papers for more details:\n  - Mario Botsch and Leif Kobbelt. A remeshing approach to multiresolution modeling. SGP, 2004.\n  - Marion Dunyach et al. Adaptive remeshing for real-time mesh deformation. EG (Short Papers) 2013.");
		cl.def( pybind11::init<class easy3d::SurfaceMesh *>(), pybind11::arg("mesh") );

		cl.def("uniform_remeshing", [](easy3d::SurfaceMeshRemeshing &o, float const & a0) -> void { return o.uniform_remeshing(a0); }, "", pybind11::arg("edge_length"));
		cl.def("uniform_remeshing", [](easy3d::SurfaceMeshRemeshing &o, float const & a0, unsigned int const & a1) -> void { return o.uniform_remeshing(a0, a1); }, "", pybind11::arg("edge_length"), pybind11::arg("iterations"));
		cl.def("uniform_remeshing", (void (easy3d::SurfaceMeshRemeshing::*)(float, unsigned int, bool)) &easy3d::SurfaceMeshRemeshing::uniform_remeshing, "Perform uniform remeshing.\n \n\n the target edge length.\n \n\n the number of iterations\n \n\n use back-projection to the input surface\n\nC++: easy3d::SurfaceMeshRemeshing::uniform_remeshing(float, unsigned int, bool) --> void", pybind11::arg("edge_length"), pybind11::arg("iterations"), pybind11::arg("use_projection"));
		cl.def("adaptive_remeshing", [](easy3d::SurfaceMeshRemeshing &o, float const & a0, float const & a1, float const & a2) -> void { return o.adaptive_remeshing(a0, a1, a2); }, "", pybind11::arg("min_edge_length"), pybind11::arg("max_edge_length"), pybind11::arg("approx_error"));
		cl.def("adaptive_remeshing", [](easy3d::SurfaceMeshRemeshing &o, float const & a0, float const & a1, float const & a2, unsigned int const & a3) -> void { return o.adaptive_remeshing(a0, a1, a2, a3); }, "", pybind11::arg("min_edge_length"), pybind11::arg("max_edge_length"), pybind11::arg("approx_error"), pybind11::arg("iterations"));
		cl.def("adaptive_remeshing", (void (easy3d::SurfaceMeshRemeshing::*)(float, float, float, unsigned int, bool)) &easy3d::SurfaceMeshRemeshing::adaptive_remeshing, "Perform adaptive remeshing.\n \n\n the minimum edge length.\n \n\n the maximum edge length.\n \n\n the maximum approximation error\n \n\n the number of iterations\n \n\n use back-projection to the input surface\n\nC++: easy3d::SurfaceMeshRemeshing::adaptive_remeshing(float, float, float, unsigned int, bool) --> void", pybind11::arg("min_edge_length"), pybind11::arg("max_edge_length"), pybind11::arg("approx_error"), pybind11::arg("iterations"), pybind11::arg("use_projection"));
	}
	{ // easy3d::SurfaceMeshSampler file:easy3d/algo/surface_mesh_sampler.h line:38
		pybind11::class_<easy3d::SurfaceMeshSampler, std::shared_ptr<easy3d::SurfaceMeshSampler>> cl(M("easy3d"), "SurfaceMeshSampler", "Sample a surface mesh (near uniformly) into a point cloud.\n \n");
		cl.def( pybind11::init( [](){ return new easy3d::SurfaceMeshSampler(); } ) );
		cl.def_static("apply", [](const class easy3d::SurfaceMesh * a0) -> easy3d::PointCloud * { return easy3d::SurfaceMeshSampler::apply(a0); }, "", pybind11::return_value_policy::automatic, pybind11::arg("mesh"));
		cl.def_static("apply", (class easy3d::PointCloud * (*)(const class easy3d::SurfaceMesh *, int)) &easy3d::SurfaceMeshSampler::apply, "The expected point number, must be greater than the number of vertices of the surface mesh.\n\nC++: easy3d::SurfaceMeshSampler::apply(const class easy3d::SurfaceMesh *, int) --> class easy3d::PointCloud *", pybind11::return_value_policy::automatic, pybind11::arg("mesh"), pybind11::arg("num"));
	}
	{ // easy3d::Quadric file:easy3d/algo/surface_mesh_simplification.h line:25
		pybind11::class_<easy3d::Quadric, std::shared_ptr<easy3d::Quadric>> cl(M("easy3d"), "Quadric", "A quadric as a symmetric 4x4 matrix. Used by the error quadric mesh decimation algorithms.");
		cl.def( pybind11::init<double, double, double, double, double, double, double, double, double, double>(), pybind11::arg("a"), pybind11::arg("b"), pybind11::arg("c"), pybind11::arg("d"), pybind11::arg("e"), pybind11::arg("f"), pybind11::arg("g"), pybind11::arg("h"), pybind11::arg("i"), pybind11::arg("j") );

		cl.def( pybind11::init( [](){ return new easy3d::Quadric(); } ), "doc" );
		cl.def( pybind11::init( [](double const & a0){ return new easy3d::Quadric(a0); } ), "doc" , pybind11::arg("a"));
		cl.def( pybind11::init( [](double const & a0, double const & a1){ return new easy3d::Quadric(a0, a1); } ), "doc" , pybind11::arg("a"), pybind11::arg("b"));
		cl.def( pybind11::init( [](double const & a0, double const & a1, double const & a2){ return new easy3d::Quadric(a0, a1, a2); } ), "doc" , pybind11::arg("a"), pybind11::arg("b"), pybind11::arg("c"));
		cl.def( pybind11::init<double, double, double, double>(), pybind11::arg("a"), pybind11::arg("b"), pybind11::arg("c"), pybind11::arg("d") );

		cl.def( pybind11::init<const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &>(), pybind11::arg("n"), pybind11::arg("p") );

		cl.def( pybind11::init( [](easy3d::Quadric const &o){ return new easy3d::Quadric(o); } ) );
		cl.def("clear", (void (easy3d::Quadric::*)()) &easy3d::Quadric::clear, "set all matrix entries to zero\n\nC++: easy3d::Quadric::clear() --> void");
		cl.def("__iadd__", (class easy3d::Quadric & (easy3d::Quadric::*)(const class easy3d::Quadric &)) &easy3d::Quadric::operator+=, "add given quadric to this quadric\n\nC++: easy3d::Quadric::operator+=(const class easy3d::Quadric &) --> class easy3d::Quadric &", pybind11::return_value_policy::automatic, pybind11::arg("q"));
		cl.def("__imul__", (class easy3d::Quadric & (easy3d::Quadric::*)(double)) &easy3d::Quadric::operator*=, "multiply quadric by a scalar\n\nC++: easy3d::Quadric::operator*=(double) --> class easy3d::Quadric &", pybind11::return_value_policy::automatic, pybind11::arg("s"));
		cl.def("__call__", (double (easy3d::Quadric::*)(const class easy3d::Vec<3, float> &) const) &easy3d::Quadric::operator(), "evaluate quadric Q at position p by computing (p^T * Q * p)\n\nC++: easy3d::Quadric::operator()(const class easy3d::Vec<3, float> &) const --> double", pybind11::arg("p"));
		cl.def("assign", (class easy3d::Quadric & (easy3d::Quadric::*)(const class easy3d::Quadric &)) &easy3d::Quadric::operator=, "C++: easy3d::Quadric::operator=(const class easy3d::Quadric &) --> class easy3d::Quadric &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::NormalCone file:easy3d/algo/surface_mesh_simplification.h line:102
		pybind11::class_<easy3d::NormalCone, std::shared_ptr<easy3d::NormalCone>> cl(M("easy3d"), "NormalCone", "A class implementing a normal cone.");
		cl.def( pybind11::init( [](){ return new easy3d::NormalCone(); } ) );
		cl.def( pybind11::init( [](const class easy3d::Vec<3, float> & a0){ return new easy3d::NormalCone(a0); } ), "doc" , pybind11::arg("normal"));
		cl.def( pybind11::init<const class easy3d::Vec<3, float> &, float>(), pybind11::arg("normal"), pybind11::arg("angle") );

		cl.def( pybind11::init( [](easy3d::NormalCone const &o){ return new easy3d::NormalCone(o); } ) );
		cl.def("center_normal", (const class easy3d::Vec<3, float> & (easy3d::NormalCone::*)() const) &easy3d::NormalCone::center_normal, "returns center normal\n\nC++: easy3d::NormalCone::center_normal() const --> const class easy3d::Vec<3, float> &", pybind11::return_value_policy::automatic);
		cl.def("angle", (float (easy3d::NormalCone::*)() const) &easy3d::NormalCone::angle, "returns size of cone (radius in radians)\n\nC++: easy3d::NormalCone::angle() const --> float");
		cl.def("merge", (class easy3d::NormalCone & (easy3d::NormalCone::*)(const class easy3d::Vec<3, float> &)) &easy3d::NormalCone::merge, "merge *this with n.\n\nC++: easy3d::NormalCone::merge(const class easy3d::Vec<3, float> &) --> class easy3d::NormalCone &", pybind11::return_value_policy::automatic, pybind11::arg("n"));
		cl.def("merge", (class easy3d::NormalCone & (easy3d::NormalCone::*)(const class easy3d::NormalCone &)) &easy3d::NormalCone::merge, "merge *this with nc. *this will then enclose both cones.\n\nC++: easy3d::NormalCone::merge(const class easy3d::NormalCone &) --> class easy3d::NormalCone &", pybind11::return_value_policy::automatic, pybind11::arg("nc"));
		cl.def("assign", (class easy3d::NormalCone & (easy3d::NormalCone::*)(const class easy3d::NormalCone &)) &easy3d::NormalCone::operator=, "C++: easy3d::NormalCone::operator=(const class easy3d::NormalCone &) --> class easy3d::NormalCone &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::SurfaceMeshSimplification file:easy3d/algo/surface_mesh_simplification.h line:166
		pybind11::class_<easy3d::SurfaceMeshSimplification, std::shared_ptr<easy3d::SurfaceMeshSimplification>> cl(M("easy3d"), "SurfaceMeshSimplification", "Surface mesh simplification based on approximation error and fairness criteria.\n \n\n\n \n It performs incremental greedy mesh simplification based on halfedge collapses. See the following paper\n for more details:\n  - Michael Garland and Paul Seagrave Heckbert. Surface simplification using quadric error metrics. SIGGRAPH 1997.\n  - Leif Kobbelt et al. A general framework for mesh decimation. In Proceedings of Graphics Interface, 1998.");
		cl.def( pybind11::init<class easy3d::SurfaceMesh *>(), pybind11::arg("mesh") );

		cl.def("initialize", [](easy3d::SurfaceMeshSimplification &o) -> void { return o.initialize(); }, "");
		cl.def("initialize", [](easy3d::SurfaceMeshSimplification &o, float const & a0) -> void { return o.initialize(a0); }, "", pybind11::arg("aspect_ratio"));
		cl.def("initialize", [](easy3d::SurfaceMeshSimplification &o, float const & a0, float const & a1) -> void { return o.initialize(a0, a1); }, "", pybind11::arg("aspect_ratio"), pybind11::arg("edge_length"));
		cl.def("initialize", [](easy3d::SurfaceMeshSimplification &o, float const & a0, float const & a1, unsigned int const & a2) -> void { return o.initialize(a0, a1, a2); }, "", pybind11::arg("aspect_ratio"), pybind11::arg("edge_length"), pybind11::arg("max_valence"));
		cl.def("initialize", [](easy3d::SurfaceMeshSimplification &o, float const & a0, float const & a1, unsigned int const & a2, float const & a3) -> void { return o.initialize(a0, a1, a2, a3); }, "", pybind11::arg("aspect_ratio"), pybind11::arg("edge_length"), pybind11::arg("max_valence"), pybind11::arg("normal_deviation"));
		cl.def("initialize", (void (easy3d::SurfaceMeshSimplification::*)(float, float, unsigned int, float, float)) &easy3d::SurfaceMeshSimplification::initialize, "Initialize with given parameters.\n\nC++: easy3d::SurfaceMeshSimplification::initialize(float, float, unsigned int, float, float) --> void", pybind11::arg("aspect_ratio"), pybind11::arg("edge_length"), pybind11::arg("max_valence"), pybind11::arg("normal_deviation"), pybind11::arg("hausdorff_error"));
		cl.def("simplify", (void (easy3d::SurfaceMeshSimplification::*)(unsigned int)) &easy3d::SurfaceMeshSimplification::simplify, "Simplify mesh to  vertices.\n\nC++: easy3d::SurfaceMeshSimplification::simplify(unsigned int) --> void", pybind11::arg("n_vertices"));
	}
}
