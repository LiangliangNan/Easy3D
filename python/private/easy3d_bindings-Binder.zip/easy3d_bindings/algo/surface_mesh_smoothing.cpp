#include <__functional/operations.h>
#include <easy3d/algo/surface_mesh_components.h>
#include <easy3d/algo/surface_mesh_smoothing.h>
#include <easy3d/algo/surface_mesh_stitching.h>
#include <easy3d/algo/surface_mesh_subdivision.h>
#include <easy3d/algo/surface_mesh_tetrahedralization.h>
#include <easy3d/algo/surface_mesh_topology.h>
#include <easy3d/algo/surface_mesh_triangulation.h>
#include <easy3d/algo/tessellator.h>
#include <easy3d/core/box.h>
#include <easy3d/core/poly_mesh.h>
#include <easy3d/core/surface_mesh.h>
#include <easy3d/core/vec.h>
#include <memory>
#include <ostream>
#include <set>
#include <sstream> // __str__
#include <string>
#include <string_view>
#include <typeinfo>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_algo_surface_mesh_smoothing(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	{ // easy3d::SurfaceMeshSmoothing file:easy3d/algo/surface_mesh_smoothing.h line:26
		pybind11::class_<easy3d::SurfaceMeshSmoothing, std::shared_ptr<easy3d::SurfaceMeshSmoothing>> cl(M("easy3d"), "SurfaceMeshSmoothing", "A class for Laplacian smoothing.\n \n\n\n See the following papers for more details:\n  - Mathieu Desbrun et al. Implicit fairing of irregular meshes using diffusion and curvature flow. SIGGRAPH, 1999.\n  - Misha Kazhdan et al. Can mean‐curvature flow be modified to be non‐singular? CGF, 2012.");
		cl.def( pybind11::init<class easy3d::SurfaceMesh *>(), pybind11::arg("mesh") );

		cl.def("explicit_smoothing", [](easy3d::SurfaceMeshSmoothing &o) -> void { return o.explicit_smoothing(); }, "");
		cl.def("explicit_smoothing", [](easy3d::SurfaceMeshSmoothing &o, unsigned int const & a0) -> void { return o.explicit_smoothing(a0); }, "", pybind11::arg("iters"));
		cl.def("explicit_smoothing", (void (easy3d::SurfaceMeshSmoothing::*)(unsigned int, bool)) &easy3d::SurfaceMeshSmoothing::explicit_smoothing, "Perform  iterations of explicit Laplacian smoothing.\n Decide whether to use uniform Laplacian or cotan Laplacian (default: cotan).\n\nC++: easy3d::SurfaceMeshSmoothing::explicit_smoothing(unsigned int, bool) --> void", pybind11::arg("iters"), pybind11::arg("use_uniform_laplace"));
		cl.def("implicit_smoothing", [](easy3d::SurfaceMeshSmoothing &o) -> void { return o.implicit_smoothing(); }, "");
		cl.def("implicit_smoothing", [](easy3d::SurfaceMeshSmoothing &o, float const & a0) -> void { return o.implicit_smoothing(a0); }, "", pybind11::arg("timestep"));
		cl.def("implicit_smoothing", [](easy3d::SurfaceMeshSmoothing &o, float const & a0, bool const & a1) -> void { return o.implicit_smoothing(a0, a1); }, "", pybind11::arg("timestep"), pybind11::arg("use_uniform_laplace"));
		cl.def("implicit_smoothing", (void (easy3d::SurfaceMeshSmoothing::*)(float, bool, bool)) &easy3d::SurfaceMeshSmoothing::implicit_smoothing, "Perform implicit Laplacian smoothing with \n Decide whether to use uniform Laplacian or cotan Laplacian (default: cotan).\n Decide whether to re-center and re-scale model after smoothing (default: true).\n\nC++: easy3d::SurfaceMeshSmoothing::implicit_smoothing(float, bool, bool) --> void", pybind11::arg("timestep"), pybind11::arg("use_uniform_laplace"), pybind11::arg("rescale"));
		cl.def("initialize", [](easy3d::SurfaceMeshSmoothing &o) -> void { return o.initialize(); }, "");
		cl.def("initialize", (void (easy3d::SurfaceMeshSmoothing::*)(bool)) &easy3d::SurfaceMeshSmoothing::initialize, "Initialize edge and vertex weights.\n\nC++: easy3d::SurfaceMeshSmoothing::initialize(bool) --> void", pybind11::arg("use_uniform_laplace"));
	}
	{ // easy3d::SurfaceMeshStitching file:easy3d/algo/surface_mesh_stitching.h line:47
		pybind11::class_<easy3d::SurfaceMeshStitching, std::shared_ptr<easy3d::SurfaceMeshStitching>> cl(M("easy3d"), "SurfaceMeshStitching", "Stitch coincident border edges of a surface mesh.\n\n \n\n \n This class only performs stitching, without reversing the orientation of components having\n coincident but incompatible boundary cycles. It dose the same thing as Surfacer::stitch_borders()\n To stitch incompatible boundaries please use Surfacer::merge_reversible_connected_components().");
		cl.def( pybind11::init<class easy3d::SurfaceMesh *>(), pybind11::arg("mesh") );

		cl.def( pybind11::init( [](easy3d::SurfaceMeshStitching const &o){ return new easy3d::SurfaceMeshStitching(o); } ) );
		cl.def("apply", [](easy3d::SurfaceMeshStitching &o) -> void { return o.apply(); }, "");
		cl.def("apply", (void (easy3d::SurfaceMeshStitching::*)(float)) &easy3d::SurfaceMeshStitching::apply, "C++: easy3d::SurfaceMeshStitching::apply(float) --> void", pybind11::arg("dist_threshold"));
		cl.def("assign", (class easy3d::SurfaceMeshStitching & (easy3d::SurfaceMeshStitching::*)(const class easy3d::SurfaceMeshStitching &)) &easy3d::SurfaceMeshStitching::operator=, "C++: easy3d::SurfaceMeshStitching::operator=(const class easy3d::SurfaceMeshStitching &) --> class easy3d::SurfaceMeshStitching &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::SurfaceMeshSubdivision file:easy3d/algo/surface_mesh_subdivision.h line:22
		pybind11::class_<easy3d::SurfaceMeshSubdivision, std::shared_ptr<easy3d::SurfaceMeshSubdivision>> cl(M("easy3d"), "SurfaceMeshSubdivision", "SurfaceMeshSubdivision implement several well-known subdivision algorithms.\n \n");
		cl.def( pybind11::init( [](){ return new easy3d::SurfaceMeshSubdivision(); } ) );
		cl.def_static("catmull_clark", (bool (*)(class easy3d::SurfaceMesh *)) &easy3d::SurfaceMeshSubdivision::catmull_clark, "The Catmull-Clark subdivision. \n\nC++: easy3d::SurfaceMeshSubdivision::catmull_clark(class easy3d::SurfaceMesh *) --> bool", pybind11::arg("mesh"));
		cl.def_static("loop", (bool (*)(class easy3d::SurfaceMesh *)) &easy3d::SurfaceMeshSubdivision::loop, "The Loop subdivision. \n\nC++: easy3d::SurfaceMeshSubdivision::loop(class easy3d::SurfaceMesh *) --> bool", pybind11::arg("mesh"));
		cl.def_static("sqrt3", (bool (*)(class easy3d::SurfaceMesh *)) &easy3d::SurfaceMeshSubdivision::sqrt3, "The sqrt3 subdivision. \n\nC++: easy3d::SurfaceMeshSubdivision::sqrt3(class easy3d::SurfaceMesh *) --> bool", pybind11::arg("mesh"));
	}
	{ // easy3d::SurfaceMeshTetrehedralization file:easy3d/algo/surface_mesh_tetrahedralization.h line:26
		pybind11::class_<easy3d::SurfaceMeshTetrehedralization, std::shared_ptr<easy3d::SurfaceMeshTetrehedralization>> cl(M("easy3d"), "SurfaceMeshTetrehedralization", "Generate quality tetrahedralization from closed shells.\n \n");
		cl.def( pybind11::init( [](){ return new easy3d::SurfaceMeshTetrehedralization(); } ) );
		cl.def( pybind11::init( [](easy3d::SurfaceMeshTetrehedralization const &o){ return new easy3d::SurfaceMeshTetrehedralization(o); } ) );
		cl.def("set_allow_steiner_points_on_boundary", (void (easy3d::SurfaceMeshTetrehedralization::*)(bool)) &easy3d::SurfaceMeshTetrehedralization::set_allow_steiner_points_on_boundary, "Sets if Steiner points are allowed on the boundary edges and faces of the input surface. Default is true.\n \n\n Disable this will preserve the input boundary edges and faces. In this case, Steiner points (if\n      there exists any) will appear only in the interior space of the input surface.\n\nC++: easy3d::SurfaceMeshTetrehedralization::set_allow_steiner_points_on_boundary(bool) --> void", pybind11::arg("x"));
		cl.def("set_max_tet_shape", (void (easy3d::SurfaceMeshTetrehedralization::*)(double)) &easy3d::SurfaceMeshTetrehedralization::set_max_tet_shape, "Sets the maximum allowable radius-edge ratio. Default value is 2.0.\n The value controls how new points can be added to improve the mesh quality.\n More complicated constraints can be set by using set_command_line(). See the \"-q\" switch in tetgen manual.\n http://wias-berlin.de/software/tetgen/1.5/doc/manual/manual005.html#cmd-q\n \n\n set_max_dihedral_angle()\n\nC++: easy3d::SurfaceMeshTetrehedralization::set_max_tet_shape(double) --> void", pybind11::arg("x"));
		cl.def("set_min_dihedral_angle", (void (easy3d::SurfaceMeshTetrehedralization::*)(double)) &easy3d::SurfaceMeshTetrehedralization::set_min_dihedral_angle, "Sets the minimum allowable dihedral angle. Default value is 0.\n The value controls how new points can be added to improve the mesh quality.\n More complicated constraints can be set by using set_command_line(). See the \"-q\" switch in tetgen manual.\n http://wias-berlin.de/software/tetgen/1.5/doc/manual/manual005.html#cmd-q\n \n\n set_max_tet_shape()\n\nC++: easy3d::SurfaceMeshTetrehedralization::set_min_dihedral_angle(double) --> void", pybind11::arg("x"));
		cl.def("set_max_tet_volume", (void (easy3d::SurfaceMeshTetrehedralization::*)(double)) &easy3d::SurfaceMeshTetrehedralization::set_max_tet_volume, "Sets the maximum volume constraint on all tetrahedra. Default value is -1 (no max volume constraint).\n \n\n A positive value indicates that no tetrahedra is generated whose volume is larger than this value.\n \n\n A negative value indicates no such a constraint.\n More complicated constraints can be set by using set_command_line(). See the \"-a\" switch in tetgen manual.\n http://wias-berlin.de/software/tetgen/1.5/doc/manual/manual005.html#cmd-a\n\nC++: easy3d::SurfaceMeshTetrehedralization::set_max_tet_volume(double) --> void", pybind11::arg("x"));
		cl.def("set_tag_regions", (void (easy3d::SurfaceMeshTetrehedralization::*)(bool)) &easy3d::SurfaceMeshTetrehedralization::set_tag_regions, "If enabled, assigns an additional attribute (an integer number) to each tetrahedron that identifies to what\n facet-bounded region it belongs. In the output mesh, all tetrahedra in the same region will get a\n corresponding non-zero attribute.\n\nC++: easy3d::SurfaceMeshTetrehedralization::set_tag_regions(bool) --> void", pybind11::arg("x"));
		cl.def("set_command_line", (void (easy3d::SurfaceMeshTetrehedralization::*)(const std::string &)) &easy3d::SurfaceMeshTetrehedralization::set_command_line, "If specified, overrides all other options. \n\nC++: easy3d::SurfaceMeshTetrehedralization::set_command_line(const std::string &) --> void", pybind11::arg("x"));
		cl.def("apply", (class easy3d::PolyMesh * (easy3d::SurfaceMeshTetrehedralization::*)(class easy3d::SurfaceMesh *)) &easy3d::SurfaceMeshTetrehedralization::apply, "Performs tetrahedralization on the input mesh. \n\nC++: easy3d::SurfaceMeshTetrehedralization::apply(class easy3d::SurfaceMesh *) --> class easy3d::PolyMesh *", pybind11::return_value_policy::automatic, pybind11::arg("mesh"));
		cl.def("assign", (class easy3d::SurfaceMeshTetrehedralization & (easy3d::SurfaceMeshTetrehedralization::*)(const class easy3d::SurfaceMeshTetrehedralization &)) &easy3d::SurfaceMeshTetrehedralization::operator=, "C++: easy3d::SurfaceMeshTetrehedralization::operator=(const class easy3d::SurfaceMeshTetrehedralization &) --> class easy3d::SurfaceMeshTetrehedralization &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::SurfaceMeshTopology file:easy3d/algo/surface_mesh_topology.h line:23
		pybind11::class_<easy3d::SurfaceMeshTopology, std::shared_ptr<easy3d::SurfaceMeshTopology>> cl(M("easy3d"), "SurfaceMeshTopology", "Compute various topological characteristics of a surface mesh component.\n \n");
		cl.def( pybind11::init<const class easy3d::SurfaceMeshComponent *>(), pybind11::arg("comp") );

		cl.def("euler_poincare", (int (easy3d::SurfaceMeshTopology::*)() const) &easy3d::SurfaceMeshTopology::euler_poincare, "returns the Euler-Poincare characteristic,\n   1: a disc\n   2: a sphere\n\nC++: easy3d::SurfaceMeshTopology::euler_poincare() const --> int");
		cl.def("number_of_borders", (std::size_t (easy3d::SurfaceMeshTopology::*)() const) &easy3d::SurfaceMeshTopology::number_of_borders, "returns 0 for a closed surface. \n\nC++: easy3d::SurfaceMeshTopology::number_of_borders() const --> std::size_t");
		cl.def("largest_border_size", (std::size_t (easy3d::SurfaceMeshTopology::*)() const) &easy3d::SurfaceMeshTopology::largest_border_size, "returns the number of edges in the largest border. \n\nC++: easy3d::SurfaceMeshTopology::largest_border_size() const --> std::size_t");
		cl.def("is_closed", (bool (easy3d::SurfaceMeshTopology::*)() const) &easy3d::SurfaceMeshTopology::is_closed, "returns if the surface is closed. \n\nC++: easy3d::SurfaceMeshTopology::is_closed() const --> bool");
		cl.def("is_sphere", (bool (easy3d::SurfaceMeshTopology::*)() const) &easy3d::SurfaceMeshTopology::is_sphere, "returns if the surface is topologically equivalent to a sphere. \n\nC++: easy3d::SurfaceMeshTopology::is_sphere() const --> bool");
		cl.def("is_disc", (bool (easy3d::SurfaceMeshTopology::*)() const) &easy3d::SurfaceMeshTopology::is_disc, "returns if the surface is topologically equivalent to a disk. \n\nC++: easy3d::SurfaceMeshTopology::is_disc() const --> bool");
		cl.def("is_cylinder", (bool (easy3d::SurfaceMeshTopology::*)() const) &easy3d::SurfaceMeshTopology::is_cylinder, "returns if the surface is topologically equivalent to a cylinder. \n\nC++: easy3d::SurfaceMeshTopology::is_cylinder() const --> bool");
		cl.def("is_torus", (bool (easy3d::SurfaceMeshTopology::*)() const) &easy3d::SurfaceMeshTopology::is_torus, "returns if the surface is topologically equivalent to a torus. \n\nC++: easy3d::SurfaceMeshTopology::is_torus() const --> bool");
	}
	{ // easy3d::SurfaceMeshTriangulation file:easy3d/algo/surface_mesh_triangulation.h line:31
		pybind11::class_<easy3d::SurfaceMeshTriangulation, std::shared_ptr<easy3d::SurfaceMeshTriangulation>> cl(M("easy3d"), "SurfaceMeshTriangulation", "Triangulate a polygonal mesh into a pure triangle mesh.\n \n\n\n \n Triangulate n-gons into n-2 triangles. Find the triangulation that minimizes the sum of squared triangle\n      areas. See the following paper for more details:\n          - Peter Liepa. Filling holes in meshes. SGP, 2003.");
		cl.def( pybind11::init<class easy3d::SurfaceMesh *>(), pybind11::arg("mesh") );

		cl.def( pybind11::init( [](easy3d::SurfaceMeshTriangulation const &o){ return new easy3d::SurfaceMeshTriangulation(o); } ) );

		pybind11::enum_<easy3d::SurfaceMeshTriangulation::Objective>(cl, "Objective", pybind11::arithmetic(), "triangulation objective: find the triangulation that minimizes the\n sum of squared triangle areas, or the one that maximizes the minimum\n angle.")
			.value("MIN_AREA", easy3d::SurfaceMeshTriangulation::MIN_AREA)
			.value("MAX_ANGLE", easy3d::SurfaceMeshTriangulation::MAX_ANGLE)
			.export_values();

		cl.def("triangulate", [](easy3d::SurfaceMeshTriangulation &o) -> void { return o.triangulate(); }, "");
		cl.def("triangulate", (void (easy3d::SurfaceMeshTriangulation::*)(enum easy3d::SurfaceMeshTriangulation::Objective)) &easy3d::SurfaceMeshTriangulation::triangulate, "triangulate all faces\n\nC++: easy3d::SurfaceMeshTriangulation::triangulate(enum easy3d::SurfaceMeshTriangulation::Objective) --> void", pybind11::arg("obj"));
		cl.def("triangulate", [](easy3d::SurfaceMeshTriangulation &o, struct easy3d::SurfaceMesh::Face const & a0) -> void { return o.triangulate(a0); }, "", pybind11::arg("f"));
		cl.def("triangulate", (void (easy3d::SurfaceMeshTriangulation::*)(struct easy3d::SurfaceMesh::Face, enum easy3d::SurfaceMeshTriangulation::Objective)) &easy3d::SurfaceMeshTriangulation::triangulate, "triangulate a particular face f\n\nC++: easy3d::SurfaceMeshTriangulation::triangulate(struct easy3d::SurfaceMesh::Face, enum easy3d::SurfaceMeshTriangulation::Objective) --> void", pybind11::arg("f"), pybind11::arg("obj"));
		cl.def("assign", (class easy3d::SurfaceMeshTriangulation & (easy3d::SurfaceMeshTriangulation::*)(const class easy3d::SurfaceMeshTriangulation &)) &easy3d::SurfaceMeshTriangulation::operator=, "C++: easy3d::SurfaceMeshTriangulation::operator=(const class easy3d::SurfaceMeshTriangulation &) --> class easy3d::SurfaceMeshTriangulation &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::Tessellator file:easy3d/algo/tessellator.h line:56
		pybind11::class_<easy3d::Tessellator, std::shared_ptr<easy3d::Tessellator>> cl(M("easy3d"), "Tessellator", "Tessellator subdivides concave planar polygons, polygons with holes, or polygons with intersecting edges\n into triangles or simple contours. \n\n\n \n\n\n This implementation is also able to keep track of the unique vertices and respective indices, which allows to\n take advantage of the element buffer for efficient rendering (i.e., avoid sending vertices with the same\n geometry to the GPU).\n \n\n\n Typical applications:\n   - Tessellate concave polygons, polygons with holes, or polygons with intersecting edges;\n   - Generate buffer data for rendering;\n   - Triangulate non-triangle surfaces;\n   - Stitch patches of a triangle meshes;\n   - CSG operations\n  \n\n\n   - csg::tessellate(std::vector<Polygon2> &polygons, Tessellator::WindingRule rule);\n   - csg::union_of(std::vector<Polygon2> &polygons);\n   - csg::intersection_of(const Polygon2& polygon_a, const Polygon2& polygon_b, std::vector<Polygon2> &result);\n   - csg::difference_of(const Polygon2& polygon_a, const Polygon2& polygon_b, std::vector<Polygon2> &result).");
		cl.def( pybind11::init( [](){ return new easy3d::Tessellator(); } ) );
		cl.def( pybind11::init( [](easy3d::Tessellator const &o){ return new easy3d::Tessellator(o); } ) );

		pybind11::enum_<easy3d::Tessellator::WindingRule>(cl, "WindingRule", pybind11::arithmetic(), "The winding rule (default rule is ODD, modify if needed)")
			.value("WINDING_ODD", easy3d::Tessellator::WINDING_ODD)
			.value("WINDING_NONZERO", easy3d::Tessellator::WINDING_NONZERO)
			.value("WINDING_POSITIVE", easy3d::Tessellator::WINDING_POSITIVE)
			.value("WINDING_NEGATIVE", easy3d::Tessellator::WINDING_NEGATIVE)
			.value("WINDING_ABS_GEQ_TWO", easy3d::Tessellator::WINDING_ABS_GEQ_TWO)
			.export_values();

		cl.def("set_boundary_only", (void (easy3d::Tessellator::*)(bool)) &easy3d::Tessellator::set_boundary_only, "Set the working mode of the tessellator.\n \n\n The tessellator has two working modes and this function sets its working mode.\n The two working modes:\n  - Filled polygons: complex polygons are tessellated into filled polygons;\n  - Boundary only: complex polygons are tessellated into simple line loops separating the polygon interior\n                   and exterior\n  \n\n true for the boundary only mode and false for the filled polygons mode.\n\nC++: easy3d::Tessellator::set_boundary_only(bool) --> void", pybind11::arg("b"));
		cl.def("set_winding_rule", (void (easy3d::Tessellator::*)(enum easy3d::Tessellator::WindingRule)) &easy3d::Tessellator::set_winding_rule, "Set the wining rule. The new rule will be effective until being changed by calling this function again.\n With the winding rules, complex CSG operations can be implemented:\n  - UNION: Draw all input contours as a single polygon. The winding number of each resulting region is the\n           number of original polygons that cover it. The union can be extracted by using the WINDING_NONZERO\n           or WINDING_POSITIVE winding rules. Note that with the WINDING_NONZERO winding rule, we would get\n           the same result if all contour orientations were reversed.\n  - INTERSECTION: This only works for two contours at a time. Draw a single polygon using two contours.\n           Extract the result using WINDING_ABS_GEQ_TWO.\n  - DIFFERENCE: Suppose you want to compute A diff (B union C union D). Draw a single polygon consisting of\n           the unmodified contours from A, followed by the contours of B, C, and D, with their vertex order\n           reversed. To extract the result, use the WINDING_POSITIVE winding rule. (If B, C, and D are the\n           result of a BOUNDARY_ONLY operation, an alternative to reversing the vertex order is to reverse\n           the sign of the supplied normal. See begin_polygon().\n Explanation of the winding rule can be found here:\n https://www.glprogramming.com/red/chapter11.html\n\nC++: easy3d::Tessellator::set_winding_rule(enum easy3d::Tessellator::WindingRule) --> void", pybind11::arg("rule"));
		cl.def("begin_polygon", (void (easy3d::Tessellator::*)(const class easy3d::Vec<3, float> &)) &easy3d::Tessellator::begin_polygon, "Begin the tessellation of a complex polygon.\n \n\n This function lets the user supply the polygon normal if known (to improve robustness or to achieve\n        a specific tessellation purpose like CSG). All input data is projected into a plane perpendicular to\n        the normal before tesselation.  All output triangles are oriented CCW with respect to the normal.\n        If the supplied normal is (0,0,0) (the default value), the normal is determined as follows. The\n        direction of the normal, up to its sign, is found by fitting a plane to the vertices, without regard\n        to how the vertices are connected. It is expected that the input data lies approximately in plane;\n        otherwise projection perpendicular to the computed normal may substantially change the geometry. The\n        sign of the normal is chosen so that the sum of the signed areas of all input contours is non-negative\n        (where a CCW contour has positive area).\n \n\n The supplied normal persists until it is changed by another call to this function.\n\nC++: easy3d::Tessellator::begin_polygon(const class easy3d::Vec<3, float> &) --> void", pybind11::arg("normal"));
		cl.def("begin_polygon", (void (easy3d::Tessellator::*)()) &easy3d::Tessellator::begin_polygon, "Begin the tessellation of a complex polygon.\n \n\n This function does not provide the polygon normal and let the tessellator decide.\n\nC++: easy3d::Tessellator::begin_polygon() --> void");
		cl.def("begin_contour", (void (easy3d::Tessellator::*)()) &easy3d::Tessellator::begin_contour, "Begin a contour of a complex polygon (a polygon may have multiple contours).\n\nC++: easy3d::Tessellator::begin_contour() --> void");
		cl.def("add_vertex", (void (easy3d::Tessellator::*)(const struct easy3d::Tessellator::Vertex &)) &easy3d::Tessellator::add_vertex, "Add a vertex of a contour to the tessellator.\n \n\n The vertex data.\n \n\n The index of this vertex. Providing a non-negative index allows to map a resulting vertex to\n            the original vertex. Any new vertex generated in the tessellation will have a negative index -1.\n\nC++: easy3d::Tessellator::add_vertex(const struct easy3d::Tessellator::Vertex &) --> void", pybind11::arg("data"));
		cl.def("add_vertex", [](easy3d::Tessellator &o, const float * a0, unsigned int const & a1) -> void { return o.add_vertex(a0, a1); }, "", pybind11::arg("data"), pybind11::arg("size"));
		cl.def("add_vertex", (void (easy3d::Tessellator::*)(const float *, unsigned int, int)) &easy3d::Tessellator::add_vertex, "C++: easy3d::Tessellator::add_vertex(const float *, unsigned int, int) --> void", pybind11::arg("data"), pybind11::arg("size"), pybind11::arg("idx"));
		cl.def("add_vertex", [](easy3d::Tessellator &o, const class easy3d::Vec<3, float> & a0) -> void { return o.add_vertex(a0); }, "", pybind11::arg("xyz"));
		cl.def("add_vertex", (void (easy3d::Tessellator::*)(const class easy3d::Vec<3, float> &, int)) &easy3d::Tessellator::add_vertex, "C++: easy3d::Tessellator::add_vertex(const class easy3d::Vec<3, float> &, int) --> void", pybind11::arg("xyz"), pybind11::arg("idx"));
		cl.def("add_vertex", [](easy3d::Tessellator &o, const class easy3d::Vec<3, float> & a0, const class easy3d::Vec<2, float> & a1) -> void { return o.add_vertex(a0, a1); }, "", pybind11::arg("xyz"), pybind11::arg("t"));
		cl.def("add_vertex", (void (easy3d::Tessellator::*)(const class easy3d::Vec<3, float> &, const class easy3d::Vec<2, float> &, int)) &easy3d::Tessellator::add_vertex, "C++: easy3d::Tessellator::add_vertex(const class easy3d::Vec<3, float> &, const class easy3d::Vec<2, float> &, int) --> void", pybind11::arg("xyz"), pybind11::arg("t"), pybind11::arg("idx"));
		cl.def("add_vertex", [](easy3d::Tessellator &o, const class easy3d::Vec<3, float> & a0, const class easy3d::Vec<3, float> & a1) -> void { return o.add_vertex(a0, a1); }, "", pybind11::arg("xyz"), pybind11::arg("v1"));
		cl.def("add_vertex", (void (easy3d::Tessellator::*)(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &, int)) &easy3d::Tessellator::add_vertex, "C++: easy3d::Tessellator::add_vertex(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &, int) --> void", pybind11::arg("xyz"), pybind11::arg("v1"), pybind11::arg("idx"));
		cl.def("add_vertex", [](easy3d::Tessellator &o, const class easy3d::Vec<3, float> & a0, const class easy3d::Vec<3, float> & a1, const class easy3d::Vec<2, float> & a2) -> void { return o.add_vertex(a0, a1, a2); }, "", pybind11::arg("xyz"), pybind11::arg("v1"), pybind11::arg("t"));
		cl.def("add_vertex", (void (easy3d::Tessellator::*)(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &, const class easy3d::Vec<2, float> &, int)) &easy3d::Tessellator::add_vertex, "C++: easy3d::Tessellator::add_vertex(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &, const class easy3d::Vec<2, float> &, int) --> void", pybind11::arg("xyz"), pybind11::arg("v1"), pybind11::arg("t"), pybind11::arg("idx"));
		cl.def("add_vertex", [](easy3d::Tessellator &o, const class easy3d::Vec<3, float> & a0, const class easy3d::Vec<3, float> & a1, const class easy3d::Vec<3, float> & a2) -> void { return o.add_vertex(a0, a1, a2); }, "", pybind11::arg("xyz"), pybind11::arg("v1"), pybind11::arg("v2"));
		cl.def("add_vertex", (void (easy3d::Tessellator::*)(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &, int)) &easy3d::Tessellator::add_vertex, "C++: easy3d::Tessellator::add_vertex(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &, int) --> void", pybind11::arg("xyz"), pybind11::arg("v1"), pybind11::arg("v2"), pybind11::arg("idx"));
		cl.def("add_vertex", [](easy3d::Tessellator &o, const class easy3d::Vec<3, float> & a0, const class easy3d::Vec<3, float> & a1, const class easy3d::Vec<3, float> & a2, const class easy3d::Vec<2, float> & a3) -> void { return o.add_vertex(a0, a1, a2, a3); }, "", pybind11::arg("xyz"), pybind11::arg("v1"), pybind11::arg("v2"), pybind11::arg("t"));
		cl.def("add_vertex", (void (easy3d::Tessellator::*)(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &, const class easy3d::Vec<2, float> &, int)) &easy3d::Tessellator::add_vertex, "C++: easy3d::Tessellator::add_vertex(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &, const class easy3d::Vec<2, float> &, int) --> void", pybind11::arg("xyz"), pybind11::arg("v1"), pybind11::arg("v2"), pybind11::arg("t"), pybind11::arg("idx"));
		cl.def("end_contour", (void (easy3d::Tessellator::*)()) &easy3d::Tessellator::end_contour, "Finish the current contour of a polygon.\n\nC++: easy3d::Tessellator::end_contour() --> void");
		cl.def("end_polygon", (void (easy3d::Tessellator::*)()) &easy3d::Tessellator::end_polygon, "Finish the current polygon.\n\nC++: easy3d::Tessellator::end_polygon() --> void");
		cl.def("vertices", (const class std::vector<struct easy3d::Tessellator::Vertex *> & (easy3d::Tessellator::*)() const) &easy3d::Tessellator::vertices, "The list of vertices in the result.\n\nC++: easy3d::Tessellator::vertices() const --> const class std::vector<struct easy3d::Tessellator::Vertex *> &", pybind11::return_value_policy::automatic);
		cl.def("elements", (const class std::vector<class std::vector<unsigned int> > & (easy3d::Tessellator::*)() const) &easy3d::Tessellator::elements, "The list of elements (triangle or contour) created over many calls. Each element is represented by\n its vertex indices.\n\nC++: easy3d::Tessellator::elements() const --> const class std::vector<class std::vector<unsigned int> > &", pybind11::return_value_policy::automatic);
		cl.def("num_elements_in_polygon", (unsigned int (easy3d::Tessellator::*)() const) &easy3d::Tessellator::num_elements_in_polygon, "The number of elements (triangle or contour) in the last polygon.\n \n\n must be used after call to end_polygon() and before the next call to begin_polygon().\n\nC++: easy3d::Tessellator::num_elements_in_polygon() const --> unsigned int");
		cl.def("reset", (void (easy3d::Tessellator::*)()) &easy3d::Tessellator::reset, "Clear all recorded data (triangle list and vertices) and restart index counter.\n This function is useful if you want to selectively stitch faces/components. In this case, call reset()\n before you process each set. Then for each set, you collect the vertices and vertex indices of the triangles.\n\nC++: easy3d::Tessellator::reset() --> void");
		cl.def("assign", (class easy3d::Tessellator & (easy3d::Tessellator::*)(const class easy3d::Tessellator &)) &easy3d::Tessellator::operator=, "C++: easy3d::Tessellator::operator=(const class easy3d::Tessellator &) --> class easy3d::Tessellator &", pybind11::return_value_policy::automatic, pybind11::arg(""));

		{ // easy3d::Tessellator::Vertex file:easy3d/algo/tessellator.h line:59
			auto & enclosing_class = cl;
			pybind11::class_<easy3d::Tessellator::Vertex, std::shared_ptr<easy3d::Tessellator::Vertex>, std::vector<double>> cl(enclosing_class, "Vertex", "A vertex carries both xyz coordinates and its attributes (e.g., color, texcoord). ");
			cl.def( pybind11::init( [](const class easy3d::Vec<3, float> & a0){ return new easy3d::Tessellator::Vertex(a0); } ), "doc" , pybind11::arg("xyz"));
			cl.def( pybind11::init<const class easy3d::Vec<3, float> &, int>(), pybind11::arg("xyz"), pybind11::arg("idx") );

			cl.def( pybind11::init( [](){ return new easy3d::Tessellator::Vertex(); } ), "doc" );
			cl.def( pybind11::init( [](std::size_t const & a0){ return new easy3d::Tessellator::Vertex(a0); } ), "doc" , pybind11::arg("size"));
			cl.def( pybind11::init<std::size_t, int>(), pybind11::arg("size"), pybind11::arg("idx") );

			cl.def( pybind11::init( [](easy3d::Tessellator::Vertex const &o){ return new easy3d::Tessellator::Vertex(o); } ) );
			cl.def_readwrite("index", &easy3d::Tessellator::Vertex::index);
			cl.def("append", (void (easy3d::Tessellator::Vertex::*)(const class easy3d::Vec<3, float> &)) &easy3d::Tessellator::Vertex::append<easy3d::Vec<3, float>>, "C++: easy3d::Tessellator::Vertex::append(const class easy3d::Vec<3, float> &) --> void", pybind11::arg("v"));
			cl.def("assign", (struct easy3d::Tessellator::Vertex & (easy3d::Tessellator::Vertex::*)(const struct easy3d::Tessellator::Vertex &)) &easy3d::Tessellator::Vertex::operator=, "C++: easy3d::Tessellator::Vertex::operator=(const struct easy3d::Tessellator::Vertex &) --> struct easy3d::Tessellator::Vertex &", pybind11::return_value_policy::automatic, pybind11::arg(""));
		}

	}
}
