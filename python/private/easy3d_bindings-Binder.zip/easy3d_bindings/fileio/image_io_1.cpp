#include <easy3d/core/vec.h>
#include <easy3d/fileio/image_io.h>
#include <easy3d/fileio/ply_reader_writer.h>
#include <memory>
#include <sstream> // __str__
#include <string>
#include <string_view>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_fileio_image_io_1(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	// easy3d::io::save_ppm(const std::string &, const class std::vector<unsigned char> &, int, int) file:easy3d/fileio/image_io.h line:138
	M("easy3d::io").def("save_ppm", (bool (*)(const std::string &, const class std::vector<unsigned char> &, int, int)) &easy3d::io::save_ppm, "This function assumes that each pixel has 3 channels in RGB order.\n\nC++: easy3d::io::save_ppm(const std::string &, const class std::vector<unsigned char> &, int, int) --> bool", pybind11::arg("file_name"), pybind11::arg("bits"), pybind11::arg("width"), pybind11::arg("height"));

	// easy3d::io::save_bmp(const std::string &, const class std::vector<unsigned char> &, int, int) file:easy3d/fileio/image_io.h line:143
	M("easy3d::io").def("save_bmp", (bool (*)(const std::string &, const class std::vector<unsigned char> &, int, int)) &easy3d::io::save_bmp, "This function assumes that each pixel has 4 channels in BGRA order.\n\nC++: easy3d::io::save_bmp(const std::string &, const class std::vector<unsigned char> &, int, int) --> bool", pybind11::arg("file_name"), pybind11::arg("bits"), pybind11::arg("width"), pybind11::arg("height"));

	// easy3d::io::save_tga(const std::string &, const class std::vector<unsigned char> &, int, int) file:easy3d/fileio/image_io.h line:148
	M("easy3d::io").def("save_tga", (bool (*)(const std::string &, const class std::vector<unsigned char> &, int, int)) &easy3d::io::save_tga, "This function assumes that each pixel has 4 channels in BGRA order.\n\nC++: easy3d::io::save_tga(const std::string &, const class std::vector<unsigned char> &, int, int) --> bool", pybind11::arg("file_name"), pybind11::arg("bits"), pybind11::arg("width"), pybind11::arg("height"));

	{ // easy3d::io::GenericProperty file:easy3d/fileio/ply_reader_writer.h line:50
		pybind11::class_<easy3d::io::GenericProperty<easy3d::Vec<3, float>>, std::shared_ptr<easy3d::io::GenericProperty<easy3d::Vec<3, float>>>, std::vector<easy3d::Vec<3, float>>> cl(M("easy3d::io"), "GenericProperty_easy3d_Vec_3_float_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::io::GenericProperty<easy3d::Vec<3, float>>(); } ), "doc" );
		cl.def( pybind11::init( [](const std::string & a0){ return new easy3d::io::GenericProperty<easy3d::Vec<3, float>>(a0); } ), "doc" , pybind11::arg("prop_name"));
		cl.def( pybind11::init<const std::string &, const class std::vector<class easy3d::Vec<3, float> > &>(), pybind11::arg("prop_name"), pybind11::arg("values") );

		cl.def( pybind11::init( [](easy3d::io::GenericProperty<easy3d::Vec<3, float>> const &o){ return new easy3d::io::GenericProperty<easy3d::Vec<3, float>>(o); } ) );
		cl.def_readwrite("name", &easy3d::io::GenericProperty<easy3d::Vec<3, float>>::name);
		cl.def("assign", (class easy3d::io::GenericProperty<class easy3d::Vec<3, float> > & (easy3d::io::GenericProperty<easy3d::Vec<3, float>>::*)(const class easy3d::io::GenericProperty<class easy3d::Vec<3, float> > &)) &easy3d::io::GenericProperty<easy3d::Vec<3, float>>::operator=, "C++: easy3d::io::GenericProperty<easy3d::Vec<3, float>>::operator=(const class easy3d::io::GenericProperty<class easy3d::Vec<3, float> > &) --> class easy3d::io::GenericProperty<class easy3d::Vec<3, float> > &", pybind11::return_value_policy::automatic, pybind11::arg(""));
		cl.def("assign", (class std::vector<class easy3d::Vec<3, float> > & (std::vector<easy3d::Vec<3, float>>::*)(const class std::vector<class easy3d::Vec<3, float> > &)) &std::vector<easy3d::Vec<3, float>>::operator=, "C++: std::vector<easy3d::Vec<3, float>>::operator=(const class std::vector<class easy3d::Vec<3, float> > &) --> class std::vector<class easy3d::Vec<3, float> > &", pybind11::return_value_policy::automatic, pybind11::arg("__x"));
		cl.def("assign", (void (std::vector<easy3d::Vec<3, float>>::*)(unsigned long, const class easy3d::Vec<3, float> &)) &std::vector<easy3d::Vec<3, float>>::assign, "C++: std::vector<easy3d::Vec<3, float>>::assign(unsigned long, const class easy3d::Vec<3, float> &) --> void", pybind11::arg("__n"), pybind11::arg("__u"));
		cl.def("get_allocator", (class std::allocator<class easy3d::Vec<3, float> > (std::vector<easy3d::Vec<3, float>>::*)() const) &std::vector<easy3d::Vec<3, float>>::get_allocator, "C++: std::vector<easy3d::Vec<3, float>>::get_allocator() const --> class std::allocator<class easy3d::Vec<3, float> >");
		cl.def("size", (unsigned long (std::vector<easy3d::Vec<3, float>>::*)() const) &std::vector<easy3d::Vec<3, float>>::size, "C++: std::vector<easy3d::Vec<3, float>>::size() const --> unsigned long");
		cl.def("capacity", (unsigned long (std::vector<easy3d::Vec<3, float>>::*)() const) &std::vector<easy3d::Vec<3, float>>::capacity, "C++: std::vector<easy3d::Vec<3, float>>::capacity() const --> unsigned long");
		cl.def("empty", (bool (std::vector<easy3d::Vec<3, float>>::*)() const) &std::vector<easy3d::Vec<3, float>>::empty, "C++: std::vector<easy3d::Vec<3, float>>::empty() const --> bool");
		cl.def("max_size", (unsigned long (std::vector<easy3d::Vec<3, float>>::*)() const) &std::vector<easy3d::Vec<3, float>>::max_size, "C++: std::vector<easy3d::Vec<3, float>>::max_size() const --> unsigned long");
		cl.def("reserve", (void (std::vector<easy3d::Vec<3, float>>::*)(unsigned long)) &std::vector<easy3d::Vec<3, float>>::reserve, "C++: std::vector<easy3d::Vec<3, float>>::reserve(unsigned long) --> void", pybind11::arg("__n"));
		cl.def("shrink_to_fit", (void (std::vector<easy3d::Vec<3, float>>::*)()) &std::vector<easy3d::Vec<3, float>>::shrink_to_fit, "C++: std::vector<easy3d::Vec<3, float>>::shrink_to_fit() --> void");
		cl.def("__getitem__", (class easy3d::Vec<3, float> & (std::vector<easy3d::Vec<3, float>>::*)(unsigned long)) &std::vector<easy3d::Vec<3, float>>::operator[], "C++: std::vector<easy3d::Vec<3, float>>::operator[](unsigned long) --> class easy3d::Vec<3, float> &", pybind11::return_value_policy::automatic, pybind11::arg("__n"));
		cl.def("at", (class easy3d::Vec<3, float> & (std::vector<easy3d::Vec<3, float>>::*)(unsigned long)) &std::vector<easy3d::Vec<3, float>>::at, "C++: std::vector<easy3d::Vec<3, float>>::at(unsigned long) --> class easy3d::Vec<3, float> &", pybind11::return_value_policy::automatic, pybind11::arg("__n"));
		cl.def("front", (class easy3d::Vec<3, float> & (std::vector<easy3d::Vec<3, float>>::*)()) &std::vector<easy3d::Vec<3, float>>::front, "C++: std::vector<easy3d::Vec<3, float>>::front() --> class easy3d::Vec<3, float> &", pybind11::return_value_policy::automatic);
		cl.def("back", (class easy3d::Vec<3, float> & (std::vector<easy3d::Vec<3, float>>::*)()) &std::vector<easy3d::Vec<3, float>>::back, "C++: std::vector<easy3d::Vec<3, float>>::back() --> class easy3d::Vec<3, float> &", pybind11::return_value_policy::automatic);
		cl.def("data", (class easy3d::Vec<3, float> * (std::vector<easy3d::Vec<3, float>>::*)()) &std::vector<easy3d::Vec<3, float>>::data, "C++: std::vector<easy3d::Vec<3, float>>::data() --> class easy3d::Vec<3, float> *", pybind11::return_value_policy::automatic);
		cl.def("push_back", (void (std::vector<easy3d::Vec<3, float>>::*)(const class easy3d::Vec<3, float> &)) &std::vector<easy3d::Vec<3, float>>::push_back, "C++: std::vector<easy3d::Vec<3, float>>::push_back(const class easy3d::Vec<3, float> &) --> void", pybind11::arg("__x"));
		cl.def("pop_back", (void (std::vector<easy3d::Vec<3, float>>::*)()) &std::vector<easy3d::Vec<3, float>>::pop_back, "C++: std::vector<easy3d::Vec<3, float>>::pop_back() --> void");
		cl.def("clear", (void (std::vector<easy3d::Vec<3, float>>::*)()) &std::vector<easy3d::Vec<3, float>>::clear, "C++: std::vector<easy3d::Vec<3, float>>::clear() --> void");
		cl.def("resize", (void (std::vector<easy3d::Vec<3, float>>::*)(unsigned long)) &std::vector<easy3d::Vec<3, float>>::resize, "C++: std::vector<easy3d::Vec<3, float>>::resize(unsigned long) --> void", pybind11::arg("__sz"));
		cl.def("resize", (void (std::vector<easy3d::Vec<3, float>>::*)(unsigned long, const class easy3d::Vec<3, float> &)) &std::vector<easy3d::Vec<3, float>>::resize, "C++: std::vector<easy3d::Vec<3, float>>::resize(unsigned long, const class easy3d::Vec<3, float> &) --> void", pybind11::arg("__sz"), pybind11::arg("__x"));
		cl.def("swap", (void (std::vector<easy3d::Vec<3, float>>::*)(class std::vector<class easy3d::Vec<3, float> > &)) &std::vector<easy3d::Vec<3, float>>::swap, "C++: std::vector<easy3d::Vec<3, float>>::swap(class std::vector<class easy3d::Vec<3, float> > &) --> void", pybind11::arg(""));
		cl.def("__invariants", (bool (std::vector<easy3d::Vec<3, float>>::*)() const) &std::vector<easy3d::Vec<3, float>>::__invariants, "C++: std::vector<easy3d::Vec<3, float>>::__invariants() const --> bool");
	}
	{ // easy3d::io::GenericProperty file:easy3d/fileio/ply_reader_writer.h line:50
		pybind11::class_<easy3d::io::GenericProperty<easy3d::Vec<2, float>>, std::shared_ptr<easy3d::io::GenericProperty<easy3d::Vec<2, float>>>, std::vector<easy3d::Vec<2, float>>> cl(M("easy3d::io"), "GenericProperty_easy3d_Vec_2_float_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::io::GenericProperty<easy3d::Vec<2, float>>(); } ), "doc" );
		cl.def( pybind11::init( [](const std::string & a0){ return new easy3d::io::GenericProperty<easy3d::Vec<2, float>>(a0); } ), "doc" , pybind11::arg("prop_name"));
		cl.def( pybind11::init<const std::string &, const class std::vector<class easy3d::Vec<2, float> > &>(), pybind11::arg("prop_name"), pybind11::arg("values") );

		cl.def( pybind11::init( [](easy3d::io::GenericProperty<easy3d::Vec<2, float>> const &o){ return new easy3d::io::GenericProperty<easy3d::Vec<2, float>>(o); } ) );
		cl.def_readwrite("name", &easy3d::io::GenericProperty<easy3d::Vec<2, float>>::name);
		cl.def("assign", (class easy3d::io::GenericProperty<class easy3d::Vec<2, float> > & (easy3d::io::GenericProperty<easy3d::Vec<2, float>>::*)(const class easy3d::io::GenericProperty<class easy3d::Vec<2, float> > &)) &easy3d::io::GenericProperty<easy3d::Vec<2, float>>::operator=, "C++: easy3d::io::GenericProperty<easy3d::Vec<2, float>>::operator=(const class easy3d::io::GenericProperty<class easy3d::Vec<2, float> > &) --> class easy3d::io::GenericProperty<class easy3d::Vec<2, float> > &", pybind11::return_value_policy::automatic, pybind11::arg(""));
		cl.def("assign", (class std::vector<class easy3d::Vec<2, float> > & (std::vector<easy3d::Vec<2, float>>::*)(const class std::vector<class easy3d::Vec<2, float> > &)) &std::vector<easy3d::Vec<2, float>>::operator=, "C++: std::vector<easy3d::Vec<2, float>>::operator=(const class std::vector<class easy3d::Vec<2, float> > &) --> class std::vector<class easy3d::Vec<2, float> > &", pybind11::return_value_policy::automatic, pybind11::arg("__x"));
		cl.def("assign", (void (std::vector<easy3d::Vec<2, float>>::*)(unsigned long, const class easy3d::Vec<2, float> &)) &std::vector<easy3d::Vec<2, float>>::assign, "C++: std::vector<easy3d::Vec<2, float>>::assign(unsigned long, const class easy3d::Vec<2, float> &) --> void", pybind11::arg("__n"), pybind11::arg("__u"));
		cl.def("get_allocator", (class std::allocator<class easy3d::Vec<2, float> > (std::vector<easy3d::Vec<2, float>>::*)() const) &std::vector<easy3d::Vec<2, float>>::get_allocator, "C++: std::vector<easy3d::Vec<2, float>>::get_allocator() const --> class std::allocator<class easy3d::Vec<2, float> >");
		cl.def("size", (unsigned long (std::vector<easy3d::Vec<2, float>>::*)() const) &std::vector<easy3d::Vec<2, float>>::size, "C++: std::vector<easy3d::Vec<2, float>>::size() const --> unsigned long");
		cl.def("capacity", (unsigned long (std::vector<easy3d::Vec<2, float>>::*)() const) &std::vector<easy3d::Vec<2, float>>::capacity, "C++: std::vector<easy3d::Vec<2, float>>::capacity() const --> unsigned long");
		cl.def("empty", (bool (std::vector<easy3d::Vec<2, float>>::*)() const) &std::vector<easy3d::Vec<2, float>>::empty, "C++: std::vector<easy3d::Vec<2, float>>::empty() const --> bool");
		cl.def("max_size", (unsigned long (std::vector<easy3d::Vec<2, float>>::*)() const) &std::vector<easy3d::Vec<2, float>>::max_size, "C++: std::vector<easy3d::Vec<2, float>>::max_size() const --> unsigned long");
		cl.def("reserve", (void (std::vector<easy3d::Vec<2, float>>::*)(unsigned long)) &std::vector<easy3d::Vec<2, float>>::reserve, "C++: std::vector<easy3d::Vec<2, float>>::reserve(unsigned long) --> void", pybind11::arg("__n"));
		cl.def("shrink_to_fit", (void (std::vector<easy3d::Vec<2, float>>::*)()) &std::vector<easy3d::Vec<2, float>>::shrink_to_fit, "C++: std::vector<easy3d::Vec<2, float>>::shrink_to_fit() --> void");
		cl.def("__getitem__", (class easy3d::Vec<2, float> & (std::vector<easy3d::Vec<2, float>>::*)(unsigned long)) &std::vector<easy3d::Vec<2, float>>::operator[], "C++: std::vector<easy3d::Vec<2, float>>::operator[](unsigned long) --> class easy3d::Vec<2, float> &", pybind11::return_value_policy::automatic, pybind11::arg("__n"));
		cl.def("at", (class easy3d::Vec<2, float> & (std::vector<easy3d::Vec<2, float>>::*)(unsigned long)) &std::vector<easy3d::Vec<2, float>>::at, "C++: std::vector<easy3d::Vec<2, float>>::at(unsigned long) --> class easy3d::Vec<2, float> &", pybind11::return_value_policy::automatic, pybind11::arg("__n"));
		cl.def("front", (class easy3d::Vec<2, float> & (std::vector<easy3d::Vec<2, float>>::*)()) &std::vector<easy3d::Vec<2, float>>::front, "C++: std::vector<easy3d::Vec<2, float>>::front() --> class easy3d::Vec<2, float> &", pybind11::return_value_policy::automatic);
		cl.def("back", (class easy3d::Vec<2, float> & (std::vector<easy3d::Vec<2, float>>::*)()) &std::vector<easy3d::Vec<2, float>>::back, "C++: std::vector<easy3d::Vec<2, float>>::back() --> class easy3d::Vec<2, float> &", pybind11::return_value_policy::automatic);
		cl.def("data", (class easy3d::Vec<2, float> * (std::vector<easy3d::Vec<2, float>>::*)()) &std::vector<easy3d::Vec<2, float>>::data, "C++: std::vector<easy3d::Vec<2, float>>::data() --> class easy3d::Vec<2, float> *", pybind11::return_value_policy::automatic);
		cl.def("push_back", (void (std::vector<easy3d::Vec<2, float>>::*)(const class easy3d::Vec<2, float> &)) &std::vector<easy3d::Vec<2, float>>::push_back, "C++: std::vector<easy3d::Vec<2, float>>::push_back(const class easy3d::Vec<2, float> &) --> void", pybind11::arg("__x"));
		cl.def("pop_back", (void (std::vector<easy3d::Vec<2, float>>::*)()) &std::vector<easy3d::Vec<2, float>>::pop_back, "C++: std::vector<easy3d::Vec<2, float>>::pop_back() --> void");
		cl.def("clear", (void (std::vector<easy3d::Vec<2, float>>::*)()) &std::vector<easy3d::Vec<2, float>>::clear, "C++: std::vector<easy3d::Vec<2, float>>::clear() --> void");
		cl.def("resize", (void (std::vector<easy3d::Vec<2, float>>::*)(unsigned long)) &std::vector<easy3d::Vec<2, float>>::resize, "C++: std::vector<easy3d::Vec<2, float>>::resize(unsigned long) --> void", pybind11::arg("__sz"));
		cl.def("resize", (void (std::vector<easy3d::Vec<2, float>>::*)(unsigned long, const class easy3d::Vec<2, float> &)) &std::vector<easy3d::Vec<2, float>>::resize, "C++: std::vector<easy3d::Vec<2, float>>::resize(unsigned long, const class easy3d::Vec<2, float> &) --> void", pybind11::arg("__sz"), pybind11::arg("__x"));
		cl.def("swap", (void (std::vector<easy3d::Vec<2, float>>::*)(class std::vector<class easy3d::Vec<2, float> > &)) &std::vector<easy3d::Vec<2, float>>::swap, "C++: std::vector<easy3d::Vec<2, float>>::swap(class std::vector<class easy3d::Vec<2, float> > &) --> void", pybind11::arg(""));
		cl.def("__invariants", (bool (std::vector<easy3d::Vec<2, float>>::*)() const) &std::vector<easy3d::Vec<2, float>>::__invariants, "C++: std::vector<easy3d::Vec<2, float>>::__invariants() const --> bool");
	}
	{ // easy3d::io::GenericProperty file:easy3d/fileio/ply_reader_writer.h line:50
		pybind11::class_<easy3d::io::GenericProperty<float>, std::shared_ptr<easy3d::io::GenericProperty<float>>, std::vector<float>> cl(M("easy3d::io"), "GenericProperty_float_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::io::GenericProperty<float>(); } ), "doc" );
		cl.def( pybind11::init( [](const std::string & a0){ return new easy3d::io::GenericProperty<float>(a0); } ), "doc" , pybind11::arg("prop_name"));
		cl.def( pybind11::init<const std::string &, const class std::vector<float> &>(), pybind11::arg("prop_name"), pybind11::arg("values") );

		cl.def( pybind11::init( [](easy3d::io::GenericProperty<float> const &o){ return new easy3d::io::GenericProperty<float>(o); } ) );
		cl.def_readwrite("name", &easy3d::io::GenericProperty<float>::name);
		cl.def("assign", (class easy3d::io::GenericProperty<float> & (easy3d::io::GenericProperty<float>::*)(const class easy3d::io::GenericProperty<float> &)) &easy3d::io::GenericProperty<float>::operator=, "C++: easy3d::io::GenericProperty<float>::operator=(const class easy3d::io::GenericProperty<float> &) --> class easy3d::io::GenericProperty<float> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
		cl.def("assign", (class std::vector<float> & (std::vector<float>::*)(const class std::vector<float> &)) &std::vector<float>::operator=, "C++: std::vector<float>::operator=(const class std::vector<float> &) --> class std::vector<float> &", pybind11::return_value_policy::automatic, pybind11::arg("__x"));
		cl.def("assign", (void (std::vector<float>::*)(unsigned long, const float &)) &std::vector<float>::assign, "C++: std::vector<float>::assign(unsigned long, const float &) --> void", pybind11::arg("__n"), pybind11::arg("__u"));
		cl.def("get_allocator", (class std::allocator<float> (std::vector<float>::*)() const) &std::vector<float>::get_allocator, "C++: std::vector<float>::get_allocator() const --> class std::allocator<float>");
		cl.def("size", (unsigned long (std::vector<float>::*)() const) &std::vector<float>::size, "C++: std::vector<float>::size() const --> unsigned long");
		cl.def("capacity", (unsigned long (std::vector<float>::*)() const) &std::vector<float>::capacity, "C++: std::vector<float>::capacity() const --> unsigned long");
		cl.def("empty", (bool (std::vector<float>::*)() const) &std::vector<float>::empty, "C++: std::vector<float>::empty() const --> bool");
		cl.def("max_size", (unsigned long (std::vector<float>::*)() const) &std::vector<float>::max_size, "C++: std::vector<float>::max_size() const --> unsigned long");
		cl.def("reserve", (void (std::vector<float>::*)(unsigned long)) &std::vector<float>::reserve, "C++: std::vector<float>::reserve(unsigned long) --> void", pybind11::arg("__n"));
		cl.def("shrink_to_fit", (void (std::vector<float>::*)()) &std::vector<float>::shrink_to_fit, "C++: std::vector<float>::shrink_to_fit() --> void");
		cl.def("__getitem__", (float & (std::vector<float>::*)(unsigned long)) &std::vector<float>::operator[], "C++: std::vector<float>::operator[](unsigned long) --> float &", pybind11::return_value_policy::automatic, pybind11::arg("__n"));
		cl.def("at", (float & (std::vector<float>::*)(unsigned long)) &std::vector<float>::at, "C++: std::vector<float>::at(unsigned long) --> float &", pybind11::return_value_policy::automatic, pybind11::arg("__n"));
		cl.def("front", (float & (std::vector<float>::*)()) &std::vector<float>::front, "C++: std::vector<float>::front() --> float &", pybind11::return_value_policy::automatic);
		cl.def("back", (float & (std::vector<float>::*)()) &std::vector<float>::back, "C++: std::vector<float>::back() --> float &", pybind11::return_value_policy::automatic);
		cl.def("data", (float * (std::vector<float>::*)()) &std::vector<float>::data, "C++: std::vector<float>::data() --> float *", pybind11::return_value_policy::automatic);
		cl.def("push_back", (void (std::vector<float>::*)(const float &)) &std::vector<float>::push_back, "C++: std::vector<float>::push_back(const float &) --> void", pybind11::arg("__x"));
		cl.def("pop_back", (void (std::vector<float>::*)()) &std::vector<float>::pop_back, "C++: std::vector<float>::pop_back() --> void");
		cl.def("clear", (void (std::vector<float>::*)()) &std::vector<float>::clear, "C++: std::vector<float>::clear() --> void");
		cl.def("resize", (void (std::vector<float>::*)(unsigned long)) &std::vector<float>::resize, "C++: std::vector<float>::resize(unsigned long) --> void", pybind11::arg("__sz"));
		cl.def("resize", (void (std::vector<float>::*)(unsigned long, const float &)) &std::vector<float>::resize, "C++: std::vector<float>::resize(unsigned long, const float &) --> void", pybind11::arg("__sz"), pybind11::arg("__x"));
		cl.def("swap", (void (std::vector<float>::*)(class std::vector<float> &)) &std::vector<float>::swap, "C++: std::vector<float>::swap(class std::vector<float> &) --> void", pybind11::arg(""));
		cl.def("__invariants", (bool (std::vector<float>::*)() const) &std::vector<float>::__invariants, "C++: std::vector<float>::__invariants() const --> bool");
	}
}
