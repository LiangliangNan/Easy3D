#include <easy3d/core/graph.h>
#include <easy3d/core/vec.h>
#include <easy3d/fileio/graph_io.h>
#include <ios>
#include <memory>
#include <ostream>
#include <streambuf>
#include <string>
#include <string_view>
#include <typeinfo>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_fileio_graph_io(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	// easy3d::io::load_ply(const std::string &, class easy3d::Graph *) file:easy3d/fileio/graph_io.h line:68
	M("easy3d::io").def("load_ply", (bool (*)(const std::string &, class easy3d::Graph *)) &easy3d::io::load_ply, "Loads  from a PLY file \n \n\n The status of the operation\n      \n\n true if succeeded\n      \n\n false if failed\n\nC++: easy3d::io::load_ply(const std::string &, class easy3d::Graph *) --> bool", pybind11::arg("file_name"), pybind11::arg("graph"));

	// easy3d::io::save_ply(const std::string &, const class easy3d::Graph *, bool) file:easy3d/fileio/graph_io.h line:78
	M("easy3d::io").def("save_ply", [](const std::string & a0, const class easy3d::Graph * a1) -> bool { return easy3d::io::save_ply(a0, a1); }, "", pybind11::arg("file_name"), pybind11::arg("graph"));
	M("easy3d::io").def("save_ply", (bool (*)(const std::string &, const class easy3d::Graph *, bool)) &easy3d::io::save_ply, "Saves  into a PLY file \n \n\n The full path of the file.\n \n\n The graph.\n \n\n  for binary format, otherwise ASCII format.\n \n\n The status of the operation\n      \n\n  if succeeded\n      \n\n  if failed\n\nC++: easy3d::io::save_ply(const std::string &, const class easy3d::Graph *, bool) --> bool", pybind11::arg("file_name"), pybind11::arg("graph"), pybind11::arg("binary"));

}
