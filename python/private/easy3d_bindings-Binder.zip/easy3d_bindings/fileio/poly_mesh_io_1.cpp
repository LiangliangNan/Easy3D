#include <__functional/operations.h>
#include <easy3d/core/poly_mesh.h>
#include <easy3d/core/vec.h>
#include <easy3d/fileio/poly_mesh_io.h>
#include <ios>
#include <iterator>
#include <memory>
#include <ostream>
#include <set>
#include <streambuf>
#include <string>
#include <string_view>
#include <typeinfo>
#include <utility>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_fileio_poly_mesh_io_1(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	// easy3d::io::load_pm(const std::string &, class easy3d::PolyMesh *) file:easy3d/fileio/poly_mesh_io.h line:71
	M("easy3d::io").def("load_pm", (bool (*)(const std::string &, class easy3d::PolyMesh *)) &easy3d::io::load_pm, "Reads a polyhedral mesh from a  format file. This is the built-in binary format of Easy3D.\n\nC++: easy3d::io::load_pm(const std::string &, class easy3d::PolyMesh *) --> bool", pybind11::arg("file_name"), pybind11::arg("mesh"));

	// easy3d::io::save_pm(const std::string &, const class easy3d::PolyMesh *) file:easy3d/fileio/poly_mesh_io.h line:73
	M("easy3d::io").def("save_pm", (bool (*)(const std::string &, const class easy3d::PolyMesh *)) &easy3d::io::save_pm, "Saves a polyhedral mesh to a  format file. This is the built-in binary format of Easy3D.\n\nC++: easy3d::io::save_pm(const std::string &, const class easy3d::PolyMesh *) --> bool", pybind11::arg("file_name"), pybind11::arg("mesh"));

	// easy3d::io::load_plm(const std::string &, class easy3d::PolyMesh *) file:easy3d/fileio/poly_mesh_io.h line:76
	M("easy3d::io").def("load_plm", (bool (*)(const std::string &, class easy3d::PolyMesh *)) &easy3d::io::load_plm, "Reads a polyhedral mesh from a  format file. This is the built-in ASCII format of Easy3D.\n\nC++: easy3d::io::load_plm(const std::string &, class easy3d::PolyMesh *) --> bool", pybind11::arg("file_name"), pybind11::arg("mesh"));

	// easy3d::io::save_plm(const std::string &, const class easy3d::PolyMesh *) file:easy3d/fileio/poly_mesh_io.h line:78
	M("easy3d::io").def("save_plm", (bool (*)(const std::string &, const class easy3d::PolyMesh *)) &easy3d::io::save_plm, "Saves a polyhedral mesh to a  format file. This is the built-in ASCII format of Easy3D.\n\nC++: easy3d::io::save_plm(const std::string &, const class easy3d::PolyMesh *) --> bool", pybind11::arg("file_name"), pybind11::arg("mesh"));

	// easy3d::io::load_mesh(const std::string &, class easy3d::PolyMesh *) file:easy3d/fileio/poly_mesh_io.h line:81
	M("easy3d::io").def("load_mesh", (bool (*)(const std::string &, class easy3d::PolyMesh *)) &easy3d::io::load_mesh, "Reads a polyhedral mesh from a  format file. This ASCII format is supported by Tetgen and Medit.\n\nC++: easy3d::io::load_mesh(const std::string &, class easy3d::PolyMesh *) --> bool", pybind11::arg("file_name"), pybind11::arg("mesh"));

	// easy3d::io::save_mesh(const std::string &, const class easy3d::PolyMesh *) file:easy3d/fileio/poly_mesh_io.h line:83
	M("easy3d::io").def("save_mesh", (bool (*)(const std::string &, const class easy3d::PolyMesh *)) &easy3d::io::save_mesh, "Saves a polyhedral mesh to a  format file. This ASCII format is supported by Tetgen and Medit.\n\nC++: easy3d::io::save_mesh(const std::string &, const class easy3d::PolyMesh *) --> bool", pybind11::arg("file_name"), pybind11::arg("mesh"));

}
