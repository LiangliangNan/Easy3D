#include <easy3d/fileio/ply_reader_writer.h>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_fileio_ply_reader_writer_2(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	// easy3d::io::is_big_endian() file:easy3d/fileio/ply_reader_writer.h line:166
	M("easy3d::io").def("is_big_endian", (bool (*)()) &easy3d::io::is_big_endian, "returns endianness of the system.\n\nC++: easy3d::io::is_big_endian() --> bool");

}
