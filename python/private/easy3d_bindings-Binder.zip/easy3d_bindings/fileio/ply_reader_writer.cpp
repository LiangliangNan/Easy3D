#include <easy3d/fileio/ply_reader_writer.h>
#include <memory>
#include <sstream> // __str__
#include <string>
#include <string_view>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_fileio_ply_reader_writer(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	{ // easy3d::io::GenericProperty file:easy3d/fileio/ply_reader_writer.h line:50
		pybind11::class_<easy3d::io::GenericProperty<int>, std::shared_ptr<easy3d::io::GenericProperty<int>>, std::vector<int>> cl(M("easy3d::io"), "GenericProperty_int_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::io::GenericProperty<int>(); } ), "doc" );
		cl.def( pybind11::init( [](const std::string & a0){ return new easy3d::io::GenericProperty<int>(a0); } ), "doc" , pybind11::arg("prop_name"));
		cl.def( pybind11::init<const std::string &, const class std::vector<int> &>(), pybind11::arg("prop_name"), pybind11::arg("values") );

		cl.def( pybind11::init( [](easy3d::io::GenericProperty<int> const &o){ return new easy3d::io::GenericProperty<int>(o); } ) );
		cl.def_readwrite("name", &easy3d::io::GenericProperty<int>::name);
		cl.def("assign", (class easy3d::io::GenericProperty<int> & (easy3d::io::GenericProperty<int>::*)(const class easy3d::io::GenericProperty<int> &)) &easy3d::io::GenericProperty<int>::operator=, "C++: easy3d::io::GenericProperty<int>::operator=(const class easy3d::io::GenericProperty<int> &) --> class easy3d::io::GenericProperty<int> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
		cl.def("assign", (class std::vector<int> & (std::vector<int>::*)(const class std::vector<int> &)) &std::vector<int>::operator=, "C++: std::vector<int>::operator=(const class std::vector<int> &) --> class std::vector<int> &", pybind11::return_value_policy::automatic, pybind11::arg("__x"));
		cl.def("assign", (void (std::vector<int>::*)(unsigned long, const int &)) &std::vector<int>::assign, "C++: std::vector<int>::assign(unsigned long, const int &) --> void", pybind11::arg("__n"), pybind11::arg("__u"));
		cl.def("get_allocator", (class std::allocator<int> (std::vector<int>::*)() const) &std::vector<int>::get_allocator, "C++: std::vector<int>::get_allocator() const --> class std::allocator<int>");
		cl.def("size", (unsigned long (std::vector<int>::*)() const) &std::vector<int>::size, "C++: std::vector<int>::size() const --> unsigned long");
		cl.def("capacity", (unsigned long (std::vector<int>::*)() const) &std::vector<int>::capacity, "C++: std::vector<int>::capacity() const --> unsigned long");
		cl.def("empty", (bool (std::vector<int>::*)() const) &std::vector<int>::empty, "C++: std::vector<int>::empty() const --> bool");
		cl.def("max_size", (unsigned long (std::vector<int>::*)() const) &std::vector<int>::max_size, "C++: std::vector<int>::max_size() const --> unsigned long");
		cl.def("reserve", (void (std::vector<int>::*)(unsigned long)) &std::vector<int>::reserve, "C++: std::vector<int>::reserve(unsigned long) --> void", pybind11::arg("__n"));
		cl.def("shrink_to_fit", (void (std::vector<int>::*)()) &std::vector<int>::shrink_to_fit, "C++: std::vector<int>::shrink_to_fit() --> void");
		cl.def("__getitem__", (int & (std::vector<int>::*)(unsigned long)) &std::vector<int>::operator[], "C++: std::vector<int>::operator[](unsigned long) --> int &", pybind11::return_value_policy::automatic, pybind11::arg("__n"));
		cl.def("at", (int & (std::vector<int>::*)(unsigned long)) &std::vector<int>::at, "C++: std::vector<int>::at(unsigned long) --> int &", pybind11::return_value_policy::automatic, pybind11::arg("__n"));
		cl.def("front", (int & (std::vector<int>::*)()) &std::vector<int>::front, "C++: std::vector<int>::front() --> int &", pybind11::return_value_policy::automatic);
		cl.def("back", (int & (std::vector<int>::*)()) &std::vector<int>::back, "C++: std::vector<int>::back() --> int &", pybind11::return_value_policy::automatic);
		cl.def("data", (int * (std::vector<int>::*)()) &std::vector<int>::data, "C++: std::vector<int>::data() --> int *", pybind11::return_value_policy::automatic);
		cl.def("push_back", (void (std::vector<int>::*)(const int &)) &std::vector<int>::push_back, "C++: std::vector<int>::push_back(const int &) --> void", pybind11::arg("__x"));
		cl.def("pop_back", (void (std::vector<int>::*)()) &std::vector<int>::pop_back, "C++: std::vector<int>::pop_back() --> void");
		cl.def("clear", (void (std::vector<int>::*)()) &std::vector<int>::clear, "C++: std::vector<int>::clear() --> void");
		cl.def("resize", (void (std::vector<int>::*)(unsigned long)) &std::vector<int>::resize, "C++: std::vector<int>::resize(unsigned long) --> void", pybind11::arg("__sz"));
		cl.def("resize", (void (std::vector<int>::*)(unsigned long, const int &)) &std::vector<int>::resize, "C++: std::vector<int>::resize(unsigned long, const int &) --> void", pybind11::arg("__sz"), pybind11::arg("__x"));
		cl.def("swap", (void (std::vector<int>::*)(class std::vector<int> &)) &std::vector<int>::swap, "C++: std::vector<int>::swap(class std::vector<int> &) --> void", pybind11::arg(""));
		cl.def("__invariants", (bool (std::vector<int>::*)() const) &std::vector<int>::__invariants, "C++: std::vector<int>::__invariants() const --> bool");
	}
	{ // easy3d::io::GenericProperty file:easy3d/fileio/ply_reader_writer.h line:50
		pybind11::class_<easy3d::io::GenericProperty<std::vector<float>>, std::shared_ptr<easy3d::io::GenericProperty<std::vector<float>>>, std::vector<std::vector<float>>> cl(M("easy3d::io"), "GenericProperty_std_vector_float_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::io::GenericProperty<std::vector<float>>(); } ), "doc" );
		cl.def( pybind11::init( [](const std::string & a0){ return new easy3d::io::GenericProperty<std::vector<float>>(a0); } ), "doc" , pybind11::arg("prop_name"));
		cl.def( pybind11::init<const std::string &, const class std::vector<class std::vector<float> > &>(), pybind11::arg("prop_name"), pybind11::arg("values") );

		cl.def( pybind11::init( [](easy3d::io::GenericProperty<std::vector<float>> const &o){ return new easy3d::io::GenericProperty<std::vector<float>>(o); } ) );
		cl.def_readwrite("name", &easy3d::io::GenericProperty<std::vector<float>>::name);
		cl.def("assign", (class easy3d::io::GenericProperty<class std::vector<float> > & (easy3d::io::GenericProperty<std::vector<float>>::*)(const class easy3d::io::GenericProperty<class std::vector<float> > &)) &easy3d::io::GenericProperty<std::vector<float>>::operator=, "C++: easy3d::io::GenericProperty<std::vector<float>>::operator=(const class easy3d::io::GenericProperty<class std::vector<float> > &) --> class easy3d::io::GenericProperty<class std::vector<float> > &", pybind11::return_value_policy::automatic, pybind11::arg(""));
		cl.def("assign", (class std::vector<class std::vector<float> > & (std::vector<std::vector<float>>::*)(const class std::vector<class std::vector<float> > &)) &std::vector<std::vector<float>>::operator=, "C++: std::vector<std::vector<float>>::operator=(const class std::vector<class std::vector<float> > &) --> class std::vector<class std::vector<float> > &", pybind11::return_value_policy::automatic, pybind11::arg("__x"));
		cl.def("assign", (void (std::vector<std::vector<float>>::*)(unsigned long, const class std::vector<float> &)) &std::vector<std::vector<float>>::assign, "C++: std::vector<std::vector<float>>::assign(unsigned long, const class std::vector<float> &) --> void", pybind11::arg("__n"), pybind11::arg("__u"));
		cl.def("get_allocator", (class std::allocator<class std::vector<float> > (std::vector<std::vector<float>>::*)() const) &std::vector<std::vector<float>>::get_allocator, "C++: std::vector<std::vector<float>>::get_allocator() const --> class std::allocator<class std::vector<float> >");
		cl.def("size", (unsigned long (std::vector<std::vector<float>>::*)() const) &std::vector<std::vector<float>>::size, "C++: std::vector<std::vector<float>>::size() const --> unsigned long");
		cl.def("capacity", (unsigned long (std::vector<std::vector<float>>::*)() const) &std::vector<std::vector<float>>::capacity, "C++: std::vector<std::vector<float>>::capacity() const --> unsigned long");
		cl.def("empty", (bool (std::vector<std::vector<float>>::*)() const) &std::vector<std::vector<float>>::empty, "C++: std::vector<std::vector<float>>::empty() const --> bool");
		cl.def("max_size", (unsigned long (std::vector<std::vector<float>>::*)() const) &std::vector<std::vector<float>>::max_size, "C++: std::vector<std::vector<float>>::max_size() const --> unsigned long");
		cl.def("reserve", (void (std::vector<std::vector<float>>::*)(unsigned long)) &std::vector<std::vector<float>>::reserve, "C++: std::vector<std::vector<float>>::reserve(unsigned long) --> void", pybind11::arg("__n"));
		cl.def("shrink_to_fit", (void (std::vector<std::vector<float>>::*)()) &std::vector<std::vector<float>>::shrink_to_fit, "C++: std::vector<std::vector<float>>::shrink_to_fit() --> void");
		cl.def("__getitem__", (class std::vector<float> & (std::vector<std::vector<float>>::*)(unsigned long)) &std::vector<std::vector<float>>::operator[], "C++: std::vector<std::vector<float>>::operator[](unsigned long) --> class std::vector<float> &", pybind11::return_value_policy::automatic, pybind11::arg("__n"));
		cl.def("at", (class std::vector<float> & (std::vector<std::vector<float>>::*)(unsigned long)) &std::vector<std::vector<float>>::at, "C++: std::vector<std::vector<float>>::at(unsigned long) --> class std::vector<float> &", pybind11::return_value_policy::automatic, pybind11::arg("__n"));
		cl.def("front", (class std::vector<float> & (std::vector<std::vector<float>>::*)()) &std::vector<std::vector<float>>::front, "C++: std::vector<std::vector<float>>::front() --> class std::vector<float> &", pybind11::return_value_policy::automatic);
		cl.def("back", (class std::vector<float> & (std::vector<std::vector<float>>::*)()) &std::vector<std::vector<float>>::back, "C++: std::vector<std::vector<float>>::back() --> class std::vector<float> &", pybind11::return_value_policy::automatic);
		cl.def("data", (class std::vector<float> * (std::vector<std::vector<float>>::*)()) &std::vector<std::vector<float>>::data, "C++: std::vector<std::vector<float>>::data() --> class std::vector<float> *", pybind11::return_value_policy::automatic);
		cl.def("push_back", (void (std::vector<std::vector<float>>::*)(const class std::vector<float> &)) &std::vector<std::vector<float>>::push_back, "C++: std::vector<std::vector<float>>::push_back(const class std::vector<float> &) --> void", pybind11::arg("__x"));
		cl.def("pop_back", (void (std::vector<std::vector<float>>::*)()) &std::vector<std::vector<float>>::pop_back, "C++: std::vector<std::vector<float>>::pop_back() --> void");
		cl.def("clear", (void (std::vector<std::vector<float>>::*)()) &std::vector<std::vector<float>>::clear, "C++: std::vector<std::vector<float>>::clear() --> void");
		cl.def("resize", (void (std::vector<std::vector<float>>::*)(unsigned long)) &std::vector<std::vector<float>>::resize, "C++: std::vector<std::vector<float>>::resize(unsigned long) --> void", pybind11::arg("__sz"));
		cl.def("resize", (void (std::vector<std::vector<float>>::*)(unsigned long, const class std::vector<float> &)) &std::vector<std::vector<float>>::resize, "C++: std::vector<std::vector<float>>::resize(unsigned long, const class std::vector<float> &) --> void", pybind11::arg("__sz"), pybind11::arg("__x"));
		cl.def("swap", (void (std::vector<std::vector<float>>::*)(class std::vector<class std::vector<float> > &)) &std::vector<std::vector<float>>::swap, "C++: std::vector<std::vector<float>>::swap(class std::vector<class std::vector<float> > &) --> void", pybind11::arg(""));
		cl.def("__invariants", (bool (std::vector<std::vector<float>>::*)() const) &std::vector<std::vector<float>>::__invariants, "C++: std::vector<std::vector<float>>::__invariants() const --> bool");
	}
	{ // easy3d::io::GenericProperty file:easy3d/fileio/ply_reader_writer.h line:50
		pybind11::class_<easy3d::io::GenericProperty<std::vector<int>>, std::shared_ptr<easy3d::io::GenericProperty<std::vector<int>>>, std::vector<std::vector<int>>> cl(M("easy3d::io"), "GenericProperty_std_vector_int_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::io::GenericProperty<std::vector<int>>(); } ), "doc" );
		cl.def( pybind11::init( [](const std::string & a0){ return new easy3d::io::GenericProperty<std::vector<int>>(a0); } ), "doc" , pybind11::arg("prop_name"));
		cl.def( pybind11::init<const std::string &, const class std::vector<class std::vector<int> > &>(), pybind11::arg("prop_name"), pybind11::arg("values") );

		cl.def( pybind11::init( [](easy3d::io::GenericProperty<std::vector<int>> const &o){ return new easy3d::io::GenericProperty<std::vector<int>>(o); } ) );
		cl.def_readwrite("name", &easy3d::io::GenericProperty<std::vector<int>>::name);
		cl.def("assign", (class easy3d::io::GenericProperty<class std::vector<int> > & (easy3d::io::GenericProperty<std::vector<int>>::*)(const class easy3d::io::GenericProperty<class std::vector<int> > &)) &easy3d::io::GenericProperty<std::vector<int>>::operator=, "C++: easy3d::io::GenericProperty<std::vector<int>>::operator=(const class easy3d::io::GenericProperty<class std::vector<int> > &) --> class easy3d::io::GenericProperty<class std::vector<int> > &", pybind11::return_value_policy::automatic, pybind11::arg(""));
		cl.def("assign", (class std::vector<class std::vector<int> > & (std::vector<std::vector<int>>::*)(const class std::vector<class std::vector<int> > &)) &std::vector<std::vector<int>>::operator=, "C++: std::vector<std::vector<int>>::operator=(const class std::vector<class std::vector<int> > &) --> class std::vector<class std::vector<int> > &", pybind11::return_value_policy::automatic, pybind11::arg("__x"));
		cl.def("assign", (void (std::vector<std::vector<int>>::*)(unsigned long, const class std::vector<int> &)) &std::vector<std::vector<int>>::assign, "C++: std::vector<std::vector<int>>::assign(unsigned long, const class std::vector<int> &) --> void", pybind11::arg("__n"), pybind11::arg("__u"));
		cl.def("get_allocator", (class std::allocator<class std::vector<int> > (std::vector<std::vector<int>>::*)() const) &std::vector<std::vector<int>>::get_allocator, "C++: std::vector<std::vector<int>>::get_allocator() const --> class std::allocator<class std::vector<int> >");
		cl.def("size", (unsigned long (std::vector<std::vector<int>>::*)() const) &std::vector<std::vector<int>>::size, "C++: std::vector<std::vector<int>>::size() const --> unsigned long");
		cl.def("capacity", (unsigned long (std::vector<std::vector<int>>::*)() const) &std::vector<std::vector<int>>::capacity, "C++: std::vector<std::vector<int>>::capacity() const --> unsigned long");
		cl.def("empty", (bool (std::vector<std::vector<int>>::*)() const) &std::vector<std::vector<int>>::empty, "C++: std::vector<std::vector<int>>::empty() const --> bool");
		cl.def("max_size", (unsigned long (std::vector<std::vector<int>>::*)() const) &std::vector<std::vector<int>>::max_size, "C++: std::vector<std::vector<int>>::max_size() const --> unsigned long");
		cl.def("reserve", (void (std::vector<std::vector<int>>::*)(unsigned long)) &std::vector<std::vector<int>>::reserve, "C++: std::vector<std::vector<int>>::reserve(unsigned long) --> void", pybind11::arg("__n"));
		cl.def("shrink_to_fit", (void (std::vector<std::vector<int>>::*)()) &std::vector<std::vector<int>>::shrink_to_fit, "C++: std::vector<std::vector<int>>::shrink_to_fit() --> void");
		cl.def("__getitem__", (class std::vector<int> & (std::vector<std::vector<int>>::*)(unsigned long)) &std::vector<std::vector<int>>::operator[], "C++: std::vector<std::vector<int>>::operator[](unsigned long) --> class std::vector<int> &", pybind11::return_value_policy::automatic, pybind11::arg("__n"));
		cl.def("at", (class std::vector<int> & (std::vector<std::vector<int>>::*)(unsigned long)) &std::vector<std::vector<int>>::at, "C++: std::vector<std::vector<int>>::at(unsigned long) --> class std::vector<int> &", pybind11::return_value_policy::automatic, pybind11::arg("__n"));
		cl.def("front", (class std::vector<int> & (std::vector<std::vector<int>>::*)()) &std::vector<std::vector<int>>::front, "C++: std::vector<std::vector<int>>::front() --> class std::vector<int> &", pybind11::return_value_policy::automatic);
		cl.def("back", (class std::vector<int> & (std::vector<std::vector<int>>::*)()) &std::vector<std::vector<int>>::back, "C++: std::vector<std::vector<int>>::back() --> class std::vector<int> &", pybind11::return_value_policy::automatic);
		cl.def("data", (class std::vector<int> * (std::vector<std::vector<int>>::*)()) &std::vector<std::vector<int>>::data, "C++: std::vector<std::vector<int>>::data() --> class std::vector<int> *", pybind11::return_value_policy::automatic);
		cl.def("push_back", (void (std::vector<std::vector<int>>::*)(const class std::vector<int> &)) &std::vector<std::vector<int>>::push_back, "C++: std::vector<std::vector<int>>::push_back(const class std::vector<int> &) --> void", pybind11::arg("__x"));
		cl.def("pop_back", (void (std::vector<std::vector<int>>::*)()) &std::vector<std::vector<int>>::pop_back, "C++: std::vector<std::vector<int>>::pop_back() --> void");
		cl.def("clear", (void (std::vector<std::vector<int>>::*)()) &std::vector<std::vector<int>>::clear, "C++: std::vector<std::vector<int>>::clear() --> void");
		cl.def("resize", (void (std::vector<std::vector<int>>::*)(unsigned long)) &std::vector<std::vector<int>>::resize, "C++: std::vector<std::vector<int>>::resize(unsigned long) --> void", pybind11::arg("__sz"));
		cl.def("resize", (void (std::vector<std::vector<int>>::*)(unsigned long, const class std::vector<int> &)) &std::vector<std::vector<int>>::resize, "C++: std::vector<std::vector<int>>::resize(unsigned long, const class std::vector<int> &) --> void", pybind11::arg("__sz"), pybind11::arg("__x"));
		cl.def("swap", (void (std::vector<std::vector<int>>::*)(class std::vector<class std::vector<int> > &)) &std::vector<std::vector<int>>::swap, "C++: std::vector<std::vector<int>>::swap(class std::vector<class std::vector<int> > &) --> void", pybind11::arg(""));
		cl.def("__invariants", (bool (std::vector<std::vector<int>>::*)() const) &std::vector<std::vector<int>>::__invariants, "C++: std::vector<std::vector<int>>::__invariants() const --> bool");
	}
}
