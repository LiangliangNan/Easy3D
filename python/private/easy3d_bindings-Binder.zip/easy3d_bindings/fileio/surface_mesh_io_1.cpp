#include <easy3d/core/surface_mesh.h>
#include <easy3d/core/vec.h>
#include <easy3d/fileio/surface_mesh_io.h>
#include <ios>
#include <memory>
#include <ostream>
#include <streambuf>
#include <string>
#include <string_view>
#include <typeinfo>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_fileio_surface_mesh_io_1(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	// easy3d::io::load_sm(const std::string &, class easy3d::SurfaceMesh *) file:easy3d/fileio/surface_mesh_io.h line:70
	M("easy3d::io").def("load_sm", (bool (*)(const std::string &, class easy3d::SurfaceMesh *)) &easy3d::io::load_sm, "Reads a surface mesh from a  format file.\n\nC++: easy3d::io::load_sm(const std::string &, class easy3d::SurfaceMesh *) --> bool", pybind11::arg("file_name"), pybind11::arg("mesh"));

	// easy3d::io::save_sm(const std::string &, const class easy3d::SurfaceMesh *) file:easy3d/fileio/surface_mesh_io.h line:72
	M("easy3d::io").def("save_sm", (bool (*)(const std::string &, const class easy3d::SurfaceMesh *)) &easy3d::io::save_sm, "Saves a surface mesh to a  format file.\n\nC++: easy3d::io::save_sm(const std::string &, const class easy3d::SurfaceMesh *) --> bool", pybind11::arg("file_name"), pybind11::arg("mesh"));

	// easy3d::io::load_ply(const std::string &, class easy3d::SurfaceMesh *) file:easy3d/fileio/surface_mesh_io.h line:75
	M("easy3d::io").def("load_ply", (bool (*)(const std::string &, class easy3d::SurfaceMesh *)) &easy3d::io::load_ply, "Reads a surface mesh from a  format file.\n\nC++: easy3d::io::load_ply(const std::string &, class easy3d::SurfaceMesh *) --> bool", pybind11::arg("file_name"), pybind11::arg("mesh"));

	// easy3d::io::save_ply(const std::string &, const class easy3d::SurfaceMesh *, bool) file:easy3d/fileio/surface_mesh_io.h line:77
	M("easy3d::io").def("save_ply", [](const std::string & a0, const class easy3d::SurfaceMesh * a1) -> bool { return easy3d::io::save_ply(a0, a1); }, "", pybind11::arg("file_name"), pybind11::arg("mesh"));
	M("easy3d::io").def("save_ply", (bool (*)(const std::string &, const class easy3d::SurfaceMesh *, bool)) &easy3d::io::save_ply, "Saves a surface mesh to a  format file.\n\nC++: easy3d::io::save_ply(const std::string &, const class easy3d::SurfaceMesh *, bool) --> bool", pybind11::arg("file_name"), pybind11::arg("mesh"), pybind11::arg("binary"));

	// easy3d::io::load_off(const std::string &, class easy3d::SurfaceMesh *) file:easy3d/fileio/surface_mesh_io.h line:80
	M("easy3d::io").def("load_off", (bool (*)(const std::string &, class easy3d::SurfaceMesh *)) &easy3d::io::load_off, "Reads a surface mesh from a  format file.\n\nC++: easy3d::io::load_off(const std::string &, class easy3d::SurfaceMesh *) --> bool", pybind11::arg("file_name"), pybind11::arg("mesh"));

	// easy3d::io::save_off(const std::string &, const class easy3d::SurfaceMesh *) file:easy3d/fileio/surface_mesh_io.h line:82
	M("easy3d::io").def("save_off", (bool (*)(const std::string &, const class easy3d::SurfaceMesh *)) &easy3d::io::save_off, "Saves a surface mesh to a  format file.\n\nC++: easy3d::io::save_off(const std::string &, const class easy3d::SurfaceMesh *) --> bool", pybind11::arg("file_name"), pybind11::arg("mesh"));

	// easy3d::io::load_obj(const std::string &, class easy3d::SurfaceMesh *) file:easy3d/fileio/surface_mesh_io.h line:85
	M("easy3d::io").def("load_obj", (bool (*)(const std::string &, class easy3d::SurfaceMesh *)) &easy3d::io::load_obj, "Reads a surface mesh from a  format file.\n\nC++: easy3d::io::load_obj(const std::string &, class easy3d::SurfaceMesh *) --> bool", pybind11::arg("file_name"), pybind11::arg("mesh"));

	// easy3d::io::save_obj(const std::string &, const class easy3d::SurfaceMesh *) file:easy3d/fileio/surface_mesh_io.h line:87
	M("easy3d::io").def("save_obj", (bool (*)(const std::string &, const class easy3d::SurfaceMesh *)) &easy3d::io::save_obj, "Saves a surface mesh to a  format file.\n\nC++: easy3d::io::save_obj(const std::string &, const class easy3d::SurfaceMesh *) --> bool", pybind11::arg("file_name"), pybind11::arg("mesh"));

	// easy3d::io::load_stl(const std::string &, class easy3d::SurfaceMesh *) file:easy3d/fileio/surface_mesh_io.h line:90
	M("easy3d::io").def("load_stl", (bool (*)(const std::string &, class easy3d::SurfaceMesh *)) &easy3d::io::load_stl, "Reads a surface mesh from a  format file.\n\nC++: easy3d::io::load_stl(const std::string &, class easy3d::SurfaceMesh *) --> bool", pybind11::arg("file_name"), pybind11::arg("mesh"));

	// easy3d::io::save_stl(const std::string &, const class easy3d::SurfaceMesh *) file:easy3d/fileio/surface_mesh_io.h line:92
	M("easy3d::io").def("save_stl", (bool (*)(const std::string &, const class easy3d::SurfaceMesh *)) &easy3d::io::save_stl, "Saves a surface mesh to a  format file.\n\nC++: easy3d::io::save_stl(const std::string &, const class easy3d::SurfaceMesh *) --> bool", pybind11::arg("file_name"), pybind11::arg("mesh"));

	// easy3d::io::load_trilist(const std::string &, class easy3d::SurfaceMesh *) file:easy3d/fileio/surface_mesh_io.h line:96
	M("easy3d::io").def("load_trilist", (bool (*)(const std::string &, class easy3d::SurfaceMesh *)) &easy3d::io::load_trilist, "Reads a set of triangles (each line has coordinates of 3 points)\n Mainly used for easily saving triangles for debugging.\n\nC++: easy3d::io::load_trilist(const std::string &, class easy3d::SurfaceMesh *) --> bool", pybind11::arg("file_name"), pybind11::arg("mesh"));

	// easy3d::io::load_geojson(const std::string &, class easy3d::SurfaceMesh *) file:easy3d/fileio/surface_mesh_io.h line:100
	M("easy3d::io").def("load_geojson", (bool (*)(const std::string &, class easy3d::SurfaceMesh *)) &easy3d::io::load_geojson, "Reads Geojson format files. 2D polygons are stored as faces of a 3D surface mesh\n (all Z-coordinates are set to 0).\n\nC++: easy3d::io::load_geojson(const std::string &, class easy3d::SurfaceMesh *) --> bool", pybind11::arg("file_name"), pybind11::arg("mesh"));

}
