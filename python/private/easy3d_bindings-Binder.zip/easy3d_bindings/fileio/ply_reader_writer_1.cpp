#include <easy3d/fileio/ply_reader_writer.h>
#include <memory>
#include <sstream> // __str__
#include <string>
#include <string_view>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_fileio_ply_reader_writer_1(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	{ // easy3d::io::GenericProperty file:easy3d/fileio/ply_reader_writer.h line:50
		pybind11::class_<easy3d::io::GenericProperty<std::vector<double>>, std::shared_ptr<easy3d::io::GenericProperty<std::vector<double>>>, std::vector<std::vector<double>>> cl(M("easy3d::io"), "GenericProperty_std_vector_double_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::io::GenericProperty<std::vector<double>>(); } ), "doc" );
		cl.def( pybind11::init( [](const std::string & a0){ return new easy3d::io::GenericProperty<std::vector<double>>(a0); } ), "doc" , pybind11::arg("prop_name"));
		cl.def( pybind11::init<const std::string &, const class std::vector<class std::vector<double> > &>(), pybind11::arg("prop_name"), pybind11::arg("values") );

		cl.def( pybind11::init( [](easy3d::io::GenericProperty<std::vector<double>> const &o){ return new easy3d::io::GenericProperty<std::vector<double>>(o); } ) );
		cl.def_readwrite("name", &easy3d::io::GenericProperty<std::vector<double>>::name);
		cl.def("assign", (class easy3d::io::GenericProperty<class std::vector<double> > & (easy3d::io::GenericProperty<std::vector<double>>::*)(const class easy3d::io::GenericProperty<class std::vector<double> > &)) &easy3d::io::GenericProperty<std::vector<double>>::operator=, "C++: easy3d::io::GenericProperty<std::vector<double>>::operator=(const class easy3d::io::GenericProperty<class std::vector<double> > &) --> class easy3d::io::GenericProperty<class std::vector<double> > &", pybind11::return_value_policy::automatic, pybind11::arg(""));
		cl.def("assign", (class std::vector<class std::vector<double> > & (std::vector<std::vector<double>>::*)(const class std::vector<class std::vector<double> > &)) &std::vector<std::vector<double>>::operator=, "C++: std::vector<std::vector<double>>::operator=(const class std::vector<class std::vector<double> > &) --> class std::vector<class std::vector<double> > &", pybind11::return_value_policy::automatic, pybind11::arg("__x"));
		cl.def("assign", (void (std::vector<std::vector<double>>::*)(unsigned long, const class std::vector<double> &)) &std::vector<std::vector<double>>::assign, "C++: std::vector<std::vector<double>>::assign(unsigned long, const class std::vector<double> &) --> void", pybind11::arg("__n"), pybind11::arg("__u"));
		cl.def("get_allocator", (class std::allocator<class std::vector<double> > (std::vector<std::vector<double>>::*)() const) &std::vector<std::vector<double>>::get_allocator, "C++: std::vector<std::vector<double>>::get_allocator() const --> class std::allocator<class std::vector<double> >");
		cl.def("size", (unsigned long (std::vector<std::vector<double>>::*)() const) &std::vector<std::vector<double>>::size, "C++: std::vector<std::vector<double>>::size() const --> unsigned long");
		cl.def("capacity", (unsigned long (std::vector<std::vector<double>>::*)() const) &std::vector<std::vector<double>>::capacity, "C++: std::vector<std::vector<double>>::capacity() const --> unsigned long");
		cl.def("empty", (bool (std::vector<std::vector<double>>::*)() const) &std::vector<std::vector<double>>::empty, "C++: std::vector<std::vector<double>>::empty() const --> bool");
		cl.def("max_size", (unsigned long (std::vector<std::vector<double>>::*)() const) &std::vector<std::vector<double>>::max_size, "C++: std::vector<std::vector<double>>::max_size() const --> unsigned long");
		cl.def("reserve", (void (std::vector<std::vector<double>>::*)(unsigned long)) &std::vector<std::vector<double>>::reserve, "C++: std::vector<std::vector<double>>::reserve(unsigned long) --> void", pybind11::arg("__n"));
		cl.def("shrink_to_fit", (void (std::vector<std::vector<double>>::*)()) &std::vector<std::vector<double>>::shrink_to_fit, "C++: std::vector<std::vector<double>>::shrink_to_fit() --> void");
		cl.def("__getitem__", (class std::vector<double> & (std::vector<std::vector<double>>::*)(unsigned long)) &std::vector<std::vector<double>>::operator[], "C++: std::vector<std::vector<double>>::operator[](unsigned long) --> class std::vector<double> &", pybind11::return_value_policy::automatic, pybind11::arg("__n"));
		cl.def("at", (class std::vector<double> & (std::vector<std::vector<double>>::*)(unsigned long)) &std::vector<std::vector<double>>::at, "C++: std::vector<std::vector<double>>::at(unsigned long) --> class std::vector<double> &", pybind11::return_value_policy::automatic, pybind11::arg("__n"));
		cl.def("front", (class std::vector<double> & (std::vector<std::vector<double>>::*)()) &std::vector<std::vector<double>>::front, "C++: std::vector<std::vector<double>>::front() --> class std::vector<double> &", pybind11::return_value_policy::automatic);
		cl.def("back", (class std::vector<double> & (std::vector<std::vector<double>>::*)()) &std::vector<std::vector<double>>::back, "C++: std::vector<std::vector<double>>::back() --> class std::vector<double> &", pybind11::return_value_policy::automatic);
		cl.def("data", (class std::vector<double> * (std::vector<std::vector<double>>::*)()) &std::vector<std::vector<double>>::data, "C++: std::vector<std::vector<double>>::data() --> class std::vector<double> *", pybind11::return_value_policy::automatic);
		cl.def("push_back", (void (std::vector<std::vector<double>>::*)(const class std::vector<double> &)) &std::vector<std::vector<double>>::push_back, "C++: std::vector<std::vector<double>>::push_back(const class std::vector<double> &) --> void", pybind11::arg("__x"));
		cl.def("pop_back", (void (std::vector<std::vector<double>>::*)()) &std::vector<std::vector<double>>::pop_back, "C++: std::vector<std::vector<double>>::pop_back() --> void");
		cl.def("clear", (void (std::vector<std::vector<double>>::*)()) &std::vector<std::vector<double>>::clear, "C++: std::vector<std::vector<double>>::clear() --> void");
		cl.def("resize", (void (std::vector<std::vector<double>>::*)(unsigned long)) &std::vector<std::vector<double>>::resize, "C++: std::vector<std::vector<double>>::resize(unsigned long) --> void", pybind11::arg("__sz"));
		cl.def("resize", (void (std::vector<std::vector<double>>::*)(unsigned long, const class std::vector<double> &)) &std::vector<std::vector<double>>::resize, "C++: std::vector<std::vector<double>>::resize(unsigned long, const class std::vector<double> &) --> void", pybind11::arg("__sz"), pybind11::arg("__x"));
		cl.def("swap", (void (std::vector<std::vector<double>>::*)(class std::vector<class std::vector<double> > &)) &std::vector<std::vector<double>>::swap, "C++: std::vector<std::vector<double>>::swap(class std::vector<class std::vector<double> > &) --> void", pybind11::arg(""));
		cl.def("__invariants", (bool (std::vector<std::vector<double>>::*)() const) &std::vector<std::vector<double>>::__invariants, "C++: std::vector<std::vector<double>>::__invariants() const --> bool");
	}
	{ // easy3d::io::GenericProperty file:easy3d/fileio/ply_reader_writer.h line:50
		pybind11::class_<easy3d::io::GenericProperty<double>, std::shared_ptr<easy3d::io::GenericProperty<double>>, std::vector<double>> cl(M("easy3d::io"), "GenericProperty_double_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::io::GenericProperty<double>(); } ), "doc" );
		cl.def( pybind11::init( [](const std::string & a0){ return new easy3d::io::GenericProperty<double>(a0); } ), "doc" , pybind11::arg("prop_name"));
		cl.def( pybind11::init<const std::string &, const class std::vector<double> &>(), pybind11::arg("prop_name"), pybind11::arg("values") );

		cl.def( pybind11::init( [](easy3d::io::GenericProperty<double> const &o){ return new easy3d::io::GenericProperty<double>(o); } ) );
		cl.def_readwrite("name", &easy3d::io::GenericProperty<double>::name);
		cl.def("assign", (class easy3d::io::GenericProperty<double> & (easy3d::io::GenericProperty<double>::*)(const class easy3d::io::GenericProperty<double> &)) &easy3d::io::GenericProperty<double>::operator=, "C++: easy3d::io::GenericProperty<double>::operator=(const class easy3d::io::GenericProperty<double> &) --> class easy3d::io::GenericProperty<double> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
		cl.def("assign", (class std::vector<double> & (std::vector<double>::*)(const class std::vector<double> &)) &std::vector<double>::operator=, "C++: std::vector<double>::operator=(const class std::vector<double> &) --> class std::vector<double> &", pybind11::return_value_policy::automatic, pybind11::arg("__x"));
		cl.def("assign", (void (std::vector<double>::*)(unsigned long, const double &)) &std::vector<double>::assign, "C++: std::vector<double>::assign(unsigned long, const double &) --> void", pybind11::arg("__n"), pybind11::arg("__u"));
		cl.def("get_allocator", (class std::allocator<double> (std::vector<double>::*)() const) &std::vector<double>::get_allocator, "C++: std::vector<double>::get_allocator() const --> class std::allocator<double>");
		cl.def("size", (unsigned long (std::vector<double>::*)() const) &std::vector<double>::size, "C++: std::vector<double>::size() const --> unsigned long");
		cl.def("capacity", (unsigned long (std::vector<double>::*)() const) &std::vector<double>::capacity, "C++: std::vector<double>::capacity() const --> unsigned long");
		cl.def("empty", (bool (std::vector<double>::*)() const) &std::vector<double>::empty, "C++: std::vector<double>::empty() const --> bool");
		cl.def("max_size", (unsigned long (std::vector<double>::*)() const) &std::vector<double>::max_size, "C++: std::vector<double>::max_size() const --> unsigned long");
		cl.def("reserve", (void (std::vector<double>::*)(unsigned long)) &std::vector<double>::reserve, "C++: std::vector<double>::reserve(unsigned long) --> void", pybind11::arg("__n"));
		cl.def("shrink_to_fit", (void (std::vector<double>::*)()) &std::vector<double>::shrink_to_fit, "C++: std::vector<double>::shrink_to_fit() --> void");
		cl.def("__getitem__", (double & (std::vector<double>::*)(unsigned long)) &std::vector<double>::operator[], "C++: std::vector<double>::operator[](unsigned long) --> double &", pybind11::return_value_policy::automatic, pybind11::arg("__n"));
		cl.def("at", (double & (std::vector<double>::*)(unsigned long)) &std::vector<double>::at, "C++: std::vector<double>::at(unsigned long) --> double &", pybind11::return_value_policy::automatic, pybind11::arg("__n"));
		cl.def("front", (double & (std::vector<double>::*)()) &std::vector<double>::front, "C++: std::vector<double>::front() --> double &", pybind11::return_value_policy::automatic);
		cl.def("back", (double & (std::vector<double>::*)()) &std::vector<double>::back, "C++: std::vector<double>::back() --> double &", pybind11::return_value_policy::automatic);
		cl.def("data", (double * (std::vector<double>::*)()) &std::vector<double>::data, "C++: std::vector<double>::data() --> double *", pybind11::return_value_policy::automatic);
		cl.def("push_back", (void (std::vector<double>::*)(const double &)) &std::vector<double>::push_back, "C++: std::vector<double>::push_back(const double &) --> void", pybind11::arg("__x"));
		cl.def("pop_back", (void (std::vector<double>::*)()) &std::vector<double>::pop_back, "C++: std::vector<double>::pop_back() --> void");
		cl.def("clear", (void (std::vector<double>::*)()) &std::vector<double>::clear, "C++: std::vector<double>::clear() --> void");
		cl.def("resize", (void (std::vector<double>::*)(unsigned long)) &std::vector<double>::resize, "C++: std::vector<double>::resize(unsigned long) --> void", pybind11::arg("__sz"));
		cl.def("resize", (void (std::vector<double>::*)(unsigned long, const double &)) &std::vector<double>::resize, "C++: std::vector<double>::resize(unsigned long, const double &) --> void", pybind11::arg("__sz"), pybind11::arg("__x"));
		cl.def("swap", (void (std::vector<double>::*)(class std::vector<double> &)) &std::vector<double>::swap, "C++: std::vector<double>::swap(class std::vector<double> &) --> void", pybind11::arg(""));
		cl.def("__invariants", (bool (std::vector<double>::*)() const) &std::vector<double>::__invariants, "C++: std::vector<double>::__invariants() const --> bool");
	}
	{ // easy3d::io::Element file:easy3d/fileio/ply_reader_writer.h line:66
		pybind11::class_<easy3d::io::Element, std::shared_ptr<easy3d::io::Element>> cl(M("easy3d::io"), "Element", "Model element (e.g., faces, vertices, edges) with optional properties\n \n");
		cl.def( pybind11::init( [](const std::string & a0){ return new easy3d::io::Element(a0); } ), "doc" , pybind11::arg("elem_name"));
		cl.def( pybind11::init<const std::string &, std::size_t>(), pybind11::arg("elem_name"), pybind11::arg("n_instances") );

		cl.def( pybind11::init( [](easy3d::io::Element const &o){ return new easy3d::io::Element(o); } ) );
		cl.def_readwrite("name", &easy3d::io::Element::name);
		cl.def_readwrite("num_instances", &easy3d::io::Element::num_instances);
		cl.def_readwrite("vec3_properties", &easy3d::io::Element::vec3_properties);
		cl.def_readwrite("vec2_properties", &easy3d::io::Element::vec2_properties);
		cl.def_readwrite("float_properties", &easy3d::io::Element::float_properties);
		cl.def_readwrite("int_properties", &easy3d::io::Element::int_properties);
		cl.def_readwrite("float_list_properties", &easy3d::io::Element::float_list_properties);
		cl.def_readwrite("int_list_properties", &easy3d::io::Element::int_list_properties);
		cl.def("property_statistics", (std::string (easy3d::io::Element::*)() const) &easy3d::io::Element::property_statistics, "C++: easy3d::io::Element::property_statistics() const --> std::string");
		cl.def("assign", (struct easy3d::io::Element & (easy3d::io::Element::*)(const struct easy3d::io::Element &)) &easy3d::io::Element::operator=, "C++: easy3d::io::Element::operator=(const struct easy3d::io::Element &) --> struct easy3d::io::Element &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::io::PlyReader file:easy3d/fileio/ply_reader_writer.h line:88
		pybind11::class_<easy3d::io::PlyReader, std::shared_ptr<easy3d::io::PlyReader>> cl(M("easy3d::io"), "PlyReader", "A general purpose PLY file reader\n \n\n This class is internally used by PointCloudIO, SurfaceMeshIO, and GraphIO.\n Client code should use PointCloudIO, SurfaceMeshIO, and GraphIO.\n \n");
		cl.def( pybind11::init( [](){ return new easy3d::io::PlyReader(); } ) );
		cl.def( pybind11::init( [](easy3d::io::PlyReader const &o){ return new easy3d::io::PlyReader(o); } ) );
		cl.def("read", (bool (easy3d::io::PlyReader::*)(const std::string &, class std::vector<struct easy3d::io::Element> &)) &easy3d::io::PlyReader::read, "Reads a PLY file and stores the model as a set of \n \n\n The status of the operation\n      -  if succeeded\n      -  if failed\n\nC++: easy3d::io::PlyReader::read(const std::string &, class std::vector<struct easy3d::io::Element> &) --> bool", pybind11::arg("file_name"), pybind11::arg("elements"));
		cl.def_static("num_instances", (std::size_t (*)(const std::string &, const std::string &)) &easy3d::io::PlyReader::num_instances, "A quick check of the number of instances of a type of element. The typical use is to determine if\n 		  a PLY file stores a point cloud, a graph, or a surface mesh. Internally it reads the ply file\n 		  header only (without parsing the entire file).\n \n\n The input file.\n \n\n A string denoting the type of the element to be checked. Typical elements are\n 		  \"vertex\", \"face\", and \"edge\".\n \n\n The number of instances of the element.\n\nC++: easy3d::io::PlyReader::num_instances(const std::string &, const std::string &) --> std::size_t", pybind11::arg("file_name"), pybind11::arg("element_name"));
		cl.def("assign", (class easy3d::io::PlyReader & (easy3d::io::PlyReader::*)(const class easy3d::io::PlyReader &)) &easy3d::io::PlyReader::operator=, "C++: easy3d::io::PlyReader::operator=(const class easy3d::io::PlyReader &) --> class easy3d::io::PlyReader &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::io::PlyWriter file:easy3d/fileio/ply_reader_writer.h line:147
		pybind11::class_<easy3d::io::PlyWriter, std::shared_ptr<easy3d::io::PlyWriter>> cl(M("easy3d::io"), "PlyWriter", "A general purpose PLY file writer.\n \n\n This class is internally used by PointCloudIO, SurfaceMeshIO, and GraphIO.\n Client code should use PointCloudIO, SurfaceMeshIO, and GraphIO.\n \n");
		cl.def( pybind11::init( [](){ return new easy3d::io::PlyWriter(); } ) );
		cl.def_static("write", [](const std::string & a0, const class std::vector<struct easy3d::io::Element> & a1) -> bool { return easy3d::io::PlyWriter::write(a0, a1); }, "", pybind11::arg("file_name"), pybind11::arg("elements"));
		cl.def_static("write", [](const std::string & a0, const class std::vector<struct easy3d::io::Element> & a1, const std::string & a2) -> bool { return easy3d::io::PlyWriter::write(a0, a1, a2); }, "", pybind11::arg("file_name"), pybind11::arg("elements"), pybind11::arg("comment"));
		cl.def_static("write", (bool (*)(const std::string &, const class std::vector<struct easy3d::io::Element> &, const std::string &, bool)) &easy3d::io::PlyWriter::write, "Saves a model stored as a set of  to file \n \n\n true for binary format, otherwise ASCII format.\n \n\n The status of the operation\n      \n\n true if succeeded\n      \n\n false if failed\n\nC++: easy3d::io::PlyWriter::write(const std::string &, const class std::vector<struct easy3d::io::Element> &, const std::string &, bool) --> bool", pybind11::arg("file_name"), pybind11::arg("elements"), pybind11::arg("comment"), pybind11::arg("binary"));
	}
}
