#include <easy3d/core/vec.h>
#include <easy3d/renderer/shape.h>
#include <memory>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_renderer_shape_1(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	// easy3d::shape::create_camera(class std::vector<class easy3d::Vec<3, float> > &, class std::vector<unsigned int> &, float, float, float) file:easy3d/renderer/shape.h line:277
	M("easy3d::shape").def("create_camera", [](class std::vector<class easy3d::Vec<3, float> > & a0, class std::vector<unsigned int> & a1, float const & a2, float const & a3) -> void { return easy3d::shape::create_camera(a0, a1, a2, a3); }, "", pybind11::arg("points"), pybind11::arg("indices"), pybind11::arg("width"), pybind11::arg("fov"));
	M("easy3d::shape").def("create_camera", (void (*)(class std::vector<class easy3d::Vec<3, float> > &, class std::vector<unsigned int> &, float, float, float)) &easy3d::shape::create_camera, "Prepares data (points) for representing a camera in the 3D world as a set of triangles.\n \n\n The width of the camera. A good value can be 5% of the scene radius, or 10% of the\n      character height (in walking mode).\n \n\n The vertical field of view of the camera (in radians).\n \n\n The aspect ratio of the base quad defined as height/width (default 0.6).\n\nC++: easy3d::shape::create_camera(class std::vector<class easy3d::Vec<3, float> > &, class std::vector<unsigned int> &, float, float, float) --> void", pybind11::arg("points"), pybind11::arg("indices"), pybind11::arg("width"), pybind11::arg("fov"), pybind11::arg("hw_ratio"));

}
