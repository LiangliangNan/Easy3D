#include <easy3d/core/mat.h>
#include <easy3d/core/quat.h>
#include <easy3d/core/vec.h>
#include <easy3d/renderer/camera.h>
#include <easy3d/renderer/constraint.h>
#include <easy3d/renderer/frame.h>
#include <easy3d/renderer/key_frame_interpolator.h>
#include <easy3d/renderer/manipulated_camera_frame.h>
#include <easy3d/renderer/manipulated_frame.h>
#include <memory>
#include <sstream> // __str__
#include <string>
#include <string_view>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

// easy3d::Camera file:easy3d/renderer/camera.h line:118
struct PyCallBack_easy3d_Camera : public easy3d::Camera {
	using easy3d::Camera::Camera;

	float zNear() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Camera *>(this), "zNear");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<float>::value) {
				static pybind11::detail::override_caster_t<float> caster;
				return pybind11::detail::cast_ref<float>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<float>(std::move(o));
		}
		return Camera::zNear();
	}
	float zFar() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Camera *>(this), "zFar");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<float>::value) {
				static pybind11::detail::override_caster_t<float> caster;
				return pybind11::detail::cast_ref<float>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<float>(std::move(o));
		}
		return Camera::zFar();
	}
	void getOrthoWidthHeight(float & a0, float & a1) const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Camera *>(this), "getOrthoWidthHeight");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return Camera::getOrthoWidthHeight(a0, a1);
	}
};

void bind_easy3d_renderer_camera(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	{ // easy3d::Camera file:easy3d/renderer/camera.h line:118
		pybind11::class_<easy3d::Camera, std::shared_ptr<easy3d::Camera>, PyCallBack_easy3d_Camera> cl(M("easy3d"), "Camera", "A perspective or orthographic camera.\n      \n\n\n      \n A Camera defines some intrinsic parameters (fieldOfView(), position(), viewDirection(), upVector()...)\n      and useful positioning tools that ease its placement (showEntireScene(), fitSphere(), lookAt()...). It exports\n      its associated OpenGL projection and modelview matrices and can interactively be modified using the mouse.\n\n      Mouse manipulation\n\n      The position() and orientation() of the Camera are defined by a ManipulatedFrame (retrieved using frame()).\n      These methods are just convenient wrappers to the equivalent Frame methods. This also means that the Camera\n      frame() can be attached to a Frame::referenceFrame() which enables complex Camera setups.\n\n      If a pivotPoint() has been set, the Camera observes a scene and rotates around its pivotPoint().\n\n      Other functionalities\n\n      The type() of the Camera can be Camera::ORTHOGRAPHIC or Camera::PERSPECTIVE (see Type()). fieldOfView() is\n      meaningless with Camera::ORTHOGRAPHIC.\n\n      The near and far planes of the Camera are fitted to the scene and determined from scene radius, scene center,\n      and zClippingCoefficient() by the zNear() and zFar() methods. Reasonable values on the scene extends hence have\n      to be provided to the Camera to correctly display the scene. High level positioning methods also use this\n      information (showEntireScene(), centerScene()...).\n\n      A Camera holds KeyFrameInterpolator that can be used to save Camera positions and paths. You can interactively\n      addKeyFrameToPath() to a given path. Use playPath() to make the Camera follow the path.\n\n      Use cameraCoordinatesOf() and worldCoordinatesOf() to convert to and from the Camera frame() coordinate system.\n      projectedCoordinatesOf() and unprojectedCoordinatesOf() will convert from screen to 3D coordinates.\n      convertClickToLine() is very useful for analytical object selection.\n\n      A Camera can also be used outside of a viewer or even without OpenGL for its coordinate system conversion\n      capabilities. Note however that some of them explicitly rely on the presence of a Z-buffer.\n\n To use the camera, you need to do the following:\n  - Create and (if necessary) setup camera in the constructor of your viewer.\n      \n\n\n\n\n\n\n\n\n  - Call  camera_->setScreenWidthAndHeight()  at both\n      - creation or initialization (i.e., before the viewer appears) of the application;\n      - change of the window size.\n  - Call  camera_->frame()->action_start()  on mouse down and\n          camera_->frame()->action_end()  on mouse up.\n  - Call  camera_->frame()->action_rotate()  on mouse move for rotation and\n          camera_->frame()->action_translate()  on mouse move for translation and\n          camera_->frame()->action_zoom()  on mouse move for zoom\n\n To make the entire scene visible, call  camera_->setSceneBoundingBox()  and\n  camera_->showEntireScene()  ;\n\n To retrieve the model view projection matrix, call  camera_->modelViewProjectionMatrix() ");
		cl.def( pybind11::init( [](){ return new easy3d::Camera(); }, [](){ return new PyCallBack_easy3d_Camera(); } ) );
		cl.def( pybind11::init( [](PyCallBack_easy3d_Camera const &o){ return new PyCallBack_easy3d_Camera(o); } ) );
		cl.def( pybind11::init( [](easy3d::Camera const &o){ return new easy3d::Camera(o); } ) );

		pybind11::enum_<easy3d::Camera::Type>(cl, "Type", pybind11::arithmetic(), "Enumerates the two possible types of Camera.\n \n\n See type() and setType(). This type mainly defines different Camera projection matrix (see\n loadProjectionMatrix()). Many other methods (convertClickToLine(), projectedCoordinatesOf(),\n pixelGLRatio()...) are affected by this Type.")
			.value("PERSPECTIVE", easy3d::Camera::PERSPECTIVE)
			.value("ORTHOGRAPHIC", easy3d::Camera::ORTHOGRAPHIC)
			.export_values();

		cl.def_readwrite("frame_modified", &easy3d::Camera::frame_modified);
		cl.def("assign", (class easy3d::Camera & (easy3d::Camera::*)(const class easy3d::Camera &)) &easy3d::Camera::operator=, "C++: easy3d::Camera::operator=(const class easy3d::Camera &) --> class easy3d::Camera &", pybind11::return_value_policy::automatic, pybind11::arg("camera"));
		cl.def("position", (class easy3d::Vec<3, float> (easy3d::Camera::*)() const) &easy3d::Camera::position, "C++: easy3d::Camera::position() const --> class easy3d::Vec<3, float>");
		cl.def("upVector", (class easy3d::Vec<3, float> (easy3d::Camera::*)() const) &easy3d::Camera::upVector, "C++: easy3d::Camera::upVector() const --> class easy3d::Vec<3, float>");
		cl.def("viewDirection", (class easy3d::Vec<3, float> (easy3d::Camera::*)() const) &easy3d::Camera::viewDirection, "C++: easy3d::Camera::viewDirection() const --> class easy3d::Vec<3, float>");
		cl.def("rightVector", (class easy3d::Vec<3, float> (easy3d::Camera::*)() const) &easy3d::Camera::rightVector, "C++: easy3d::Camera::rightVector() const --> class easy3d::Vec<3, float>");
		cl.def("orientation", (class easy3d::Quat<float> (easy3d::Camera::*)() const) &easy3d::Camera::orientation, "C++: easy3d::Camera::orientation() const --> class easy3d::Quat<float>");
		cl.def("set_from_model_view_matrix", (void (easy3d::Camera::*)(const class easy3d::Mat4<float> &) const) &easy3d::Camera::set_from_model_view_matrix, "Sets the Camera's position() and orientation() from an OpenGL ModelView matrix.\n \n\n This enables a Camera initialisation from another OpenGL application. After this method has been\n called, getModelViewMatrix() returns a matrix equivalent to \n Only the orientation() and position() of the Camera are modified.\n\nC++: easy3d::Camera::set_from_model_view_matrix(const class easy3d::Mat4<float> &) const --> void", pybind11::arg("mv"));
		cl.def("set_from_calibration", [](easy3d::Camera &o, float const & a0, float const & a1, float const & a2, float const & a3, float const & a4, const class easy3d::Mat3<float> & a5, const class easy3d::Vec<3, float> & a6) -> void { return o.set_from_calibration(a0, a1, a2, a3, a4, a5, a6); }, "", pybind11::arg("fx"), pybind11::arg("fy"), pybind11::arg("skew"), pybind11::arg("cx"), pybind11::arg("cy"), pybind11::arg("R"), pybind11::arg("t"));
		cl.def("set_from_calibration", (void (easy3d::Camera::*)(float, float, float, float, float, const class easy3d::Mat3<float> &, const class easy3d::Vec<3, float> &, bool)) &easy3d::Camera::set_from_calibration, "Defines the position(), orientation() and fieldOfView() of the camera from calibrated camera\n      intrinsic and extrinsic parameters. This is an overload of set_from_calibration().\n  \n\n fy: the focal length\n  \n\n cy: the principal point\n  \n\n distortion\n  \n\n the rotation matrix. It denotes the coordinate system transformation from 3D world coordinates\n      to 3D camera coordinates.\n  \n\n the camera translation. It is the position of the origin of the world coordinate system expressed\n      in the camera coordinate system. \n\n t is often mistakenly considered the position of the camera. The\n      position C of the camera expressed in world coordinates is C = -inverse(rot) * t = -transpose(rot) * t.\n  \n\n  to convert from vision convention to OpenGL convention (i.e., invert Y and Z axes).\n                  This is because the camera coordinates of computer vision goes X right, Y down, Z forward,\n                  while the camera coordinates of OpenGL goes X right, Y up, Z inward.\n  \n\n This function assumes the camera parameters were obtained by standard camera calibration, in\n      which image coordinates are denoted in pixels, with the origin point (0, 0) corresponding to the\n      top-left corner of the image. The X axis starts at the left edge of an image and goes towards the right\n      edge. The Y axis starts at the top of the image towards image bottom. All image pixels have non-negative\n      coordinates.\n  \n\n set_from_calibration.\n\nC++: easy3d::Camera::set_from_calibration(float, float, float, float, float, const class easy3d::Mat3<float> &, const class easy3d::Vec<3, float> &, bool) --> void", pybind11::arg("fx"), pybind11::arg("fy"), pybind11::arg("skew"), pybind11::arg("cx"), pybind11::arg("cy"), pybind11::arg("R"), pybind11::arg("t"), pybind11::arg("convert"));
		cl.def("set_projection_matrix", (void (easy3d::Camera::*)(const class easy3d::Mat4<float> &)) &easy3d::Camera::set_projection_matrix, "Temporally change the projection matrix.\n \n\n The projection matrix.\n \n\n This function directly changes the projection matrix. It actually doesn't change any of the camera\n      parameters (i.e., position, orientation, fov, zFar, zNear, etc.). This is only useful if you want to\n      temporally use a different projection matrix for rendering (e.g., grabbing a snapshot from the\n      framebuffer).\n\nC++: easy3d::Camera::set_projection_matrix(const class easy3d::Mat4<float> &) --> void", pybind11::arg("proj"));
		cl.def("set_modelview_matrix", (void (easy3d::Camera::*)(const class easy3d::Mat4<float> &)) &easy3d::Camera::set_modelview_matrix, "Temporally change the modelview matrix.\n \n\n The modelview matrix.\n \n\n This function directly changes the modelview matrix. It actually doesn't change any of the camera\n      parameters (i.e., position, orientation, fov, zFar, zNear, etc.). This is only useful if you want to\n      temporally use a different modelview matrix for rendering (e.g., grabbing a snapshot from the\n      framebuffer).\n\nC++: easy3d::Camera::set_modelview_matrix(const class easy3d::Mat4<float> &) --> void", pybind11::arg("mv"));
		cl.def("setPosition", (void (easy3d::Camera::*)(const class easy3d::Vec<3, float> &) const) &easy3d::Camera::setPosition, "C++: easy3d::Camera::setPosition(const class easy3d::Vec<3, float> &) const --> void", pybind11::arg("pos"));
		cl.def("setOrientation", (void (easy3d::Camera::*)(const class easy3d::Quat<float> &) const) &easy3d::Camera::setOrientation, "C++: easy3d::Camera::setOrientation(const class easy3d::Quat<float> &) const --> void", pybind11::arg("q"));
		cl.def("setOrientation", (void (easy3d::Camera::*)(float, float) const) &easy3d::Camera::setOrientation, "C++: easy3d::Camera::setOrientation(float, float) const --> void", pybind11::arg("theta"), pybind11::arg("phi"));
		cl.def("setUpVector", [](easy3d::Camera const &o, const class easy3d::Vec<3, float> & a0) -> void { return o.setUpVector(a0); }, "", pybind11::arg("up"));
		cl.def("setUpVector", (void (easy3d::Camera::*)(const class easy3d::Vec<3, float> &, bool) const) &easy3d::Camera::setUpVector, "C++: easy3d::Camera::setUpVector(const class easy3d::Vec<3, float> &, bool) const --> void", pybind11::arg("up"), pybind11::arg("noMove"));
		cl.def("setViewDirection", (void (easy3d::Camera::*)(const class easy3d::Vec<3, float> &) const) &easy3d::Camera::setViewDirection, "C++: easy3d::Camera::setViewDirection(const class easy3d::Vec<3, float> &) const --> void", pybind11::arg("direction"));
		cl.def("lookAt", (void (easy3d::Camera::*)(const class easy3d::Vec<3, float> &) const) &easy3d::Camera::lookAt, "C++: easy3d::Camera::lookAt(const class easy3d::Vec<3, float> &) const --> void", pybind11::arg("target"));
		cl.def("showEntireScene", (void (easy3d::Camera::*)() const) &easy3d::Camera::showEntireScene, "C++: easy3d::Camera::showEntireScene() const --> void");
		cl.def("fitSphere", (void (easy3d::Camera::*)(const class easy3d::Vec<3, float> &, float) const) &easy3d::Camera::fitSphere, "C++: easy3d::Camera::fitSphere(const class easy3d::Vec<3, float> &, float) const --> void", pybind11::arg("center"), pybind11::arg("radius"));
		cl.def("fitBoundingBox", (void (easy3d::Camera::*)(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &) const) &easy3d::Camera::fitBoundingBox, "C++: easy3d::Camera::fitBoundingBox(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &) const --> void", pybind11::arg("min"), pybind11::arg("max"));
		cl.def("fitScreenRegion", (void (easy3d::Camera::*)(int, int, int, int) const) &easy3d::Camera::fitScreenRegion, "Moves the Camera so that the rectangular screen region fits the screen.\n \n\n The rectangular screen region is defined in pixel units, with origin in the upper left corner.\n The Camera is translated (its orientation() is unchanged) so that  is entirely visible.\n Since the pixel coordinates only define a  in 3D, it's the intersection of this frustum with\n a plane (orthogonal to the viewDirection() and passing through the sceneCenter()) that is used to define\n the 3D rectangle that is eventually fitted.\n\nC++: easy3d::Camera::fitScreenRegion(int, int, int, int) const --> void", pybind11::arg("xmin"), pybind11::arg("ymin"), pybind11::arg("xmax"), pybind11::arg("ymax"));
		cl.def("centerScene", (void (easy3d::Camera::*)() const) &easy3d::Camera::centerScene, "C++: easy3d::Camera::centerScene() const --> void");
		cl.def("keyframe_interpolator", (class easy3d::KeyFrameInterpolator * (easy3d::Camera::*)() const) &easy3d::Camera::keyframe_interpolator, "Return the keyframe interpolator.\n\nC++: easy3d::Camera::keyframe_interpolator() const --> class easy3d::KeyFrameInterpolator *", pybind11::return_value_policy::automatic);
		cl.def("interpolateToLookAt", (void (easy3d::Camera::*)(const class easy3d::Vec<3, float> &)) &easy3d::Camera::interpolateToLookAt, "Perform keyframe interpolation to look at \n\nC++: easy3d::Camera::interpolateToLookAt(const class easy3d::Vec<3, float> &) --> void", pybind11::arg("point"));
		cl.def("interpolateToFitScene", (void (easy3d::Camera::*)()) &easy3d::Camera::interpolateToFitScene, "Perform keyframe interpolation to fit the scene bounding box.\n\nC++: easy3d::Camera::interpolateToFitScene() --> void");
		cl.def("interpolateTo", (void (easy3d::Camera::*)(const class easy3d::Frame &, float)) &easy3d::Camera::interpolateTo, "Perform keyframe interpolation to  done in  second.\n\nC++: easy3d::Camera::interpolateTo(const class easy3d::Frame &, float) --> void", pybind11::arg("frame"), pybind11::arg("duration"));
		cl.def("type", (enum easy3d::Camera::Type (easy3d::Camera::*)() const) &easy3d::Camera::type, "Returns the Camera::Type of the Camera. Set by setType(). Mainly used by loadProjectionMatrix().\n \n\n A Camera::PERSPECTIVE Camera uses a classical projection mainly defined by its fieldOfView().\n With a Camera::ORTHOGRAPHIC type(), the fieldOfView() is meaningless and the width and height of the Camera\n frustum are inferred from the distance to the pivotPoint() using getOrthoWidthHeight(). Both types use\n zNear() and zFar() (to define their clipping planes) and aspectRatio() (for frustum shape).\n\nC++: easy3d::Camera::type() const --> enum easy3d::Camera::Type");
		cl.def("fieldOfView", (float (easy3d::Camera::*)() const) &easy3d::Camera::fieldOfView, "Returns the vertical field of view of the Camera (in radians).\n \n\n Value is set using setFieldOfView(). Default value is pi/4 radians. This value is meaningless if\n the Camera type() is Camera::ORTHOGRAPHIC.\n The field of view corresponds the one used in  (see manual). It sets the Y (vertical)\n aperture of the Camera. The X (horizontal) angle is inferred from the window aspect ratio (see aspectRatio()\n and horizontalFieldOfView()).\n Use setFOVToFitScene() to adapt the fieldOfView() to a given scene.\n\nC++: easy3d::Camera::fieldOfView() const --> float");
		cl.def("horizontalFieldOfView", (float (easy3d::Camera::*)() const) &easy3d::Camera::horizontalFieldOfView, "Returns the horizontal field of view of the Camera (in radians).\n \n\n Value is set using setHorizontalFieldOfView() or setFieldOfView(). These values are always linked\n by:\n      \n\n\n\n         \n\nC++: easy3d::Camera::horizontalFieldOfView() const --> float");
		cl.def("aspectRatio", (float (easy3d::Camera::*)() const) &easy3d::Camera::aspectRatio, "Returns the Camera aspect ratio defined by screenWidth() / screenHeight().\n \n\n When the Camera is attached to a Viewer, these values and hence the aspectRatio() are automatically\n fitted to the viewer's window aspect ratio using setScreenWidthAndHeight().\n\nC++: easy3d::Camera::aspectRatio() const --> float");
		cl.def("screenWidth", (int (easy3d::Camera::*)() const) &easy3d::Camera::screenWidth, "Returns the width (in pixels) of the Camera screen.\n \n\n Set using setScreenWidthAndHeight(). This value is automatically fitted to the Viewer's window\n dimensions when the Camera is attached to a viewer.\n\nC++: easy3d::Camera::screenWidth() const --> int");
		cl.def("screenHeight", (int (easy3d::Camera::*)() const) &easy3d::Camera::screenHeight, "Returns the height (in pixels) of the Camera screen.\n \n\n Set using setScreenWidthAndHeight(). This value is automatically fitted to the viewer's window\n dimensions when the Camera is attached to a Viewer.\n\nC++: easy3d::Camera::screenHeight() const --> int");
		cl.def("pixelGLRatio", (float (easy3d::Camera::*)(const class easy3d::Vec<3, float> &) const) &easy3d::Camera::pixelGLRatio, "C++: easy3d::Camera::pixelGLRatio(const class easy3d::Vec<3, float> &) const --> float", pybind11::arg("position"));
		cl.def("zNearCoefficient", (float (easy3d::Camera::*)() const) &easy3d::Camera::zNearCoefficient, "Returns the coefficient which is used to set zNear() when the Camera is inside the sphere defined by\n sceneCenter() and zClippingCoefficient() * sceneRadius().\n \n\n In that case, the zNear() value is set to zNearCoefficient() * zClippingCoefficient() * sceneRadius().\n See the zNear() documentation for details.\n Default value is 0.001, which is appropriate for most applications. In case you need a high dynamic ZBuffer\n precision, you can increase this value (~0.1).\n A lower value will prevent clipping of very close objects at the expense of a worst Z precision.\n Only meaningful when Camera type is Camera::PERSPECTIVE.\n\nC++: easy3d::Camera::zNearCoefficient() const --> float");
		cl.def("zClippingCoefficient", (float (easy3d::Camera::*)() const) &easy3d::Camera::zClippingCoefficient, "Returns the coefficient used to position the near and far clipping planes.\n \n\n The near (resp. far) clipping plane is positioned at a distance equal to\n zClippingCoefficient() * sceneRadius() in front of (resp. behind) the sceneCenter(). This guarantees an\n optimal use of the z-buffer range and minimizes aliasing. See the zNear() and zFar() documentations.\n Default value is square root of 3.0 (so that a cube of size sceneRadius() is not clipped).\n However, since the sceneRadius() is used for other purposes (see showEntireScene(), flySpeed(), ...)\n and you may want to change this value to define more precisely the location of the clipping planes.\n See also zNearCoefficient().\n For a total control on clipping planes' positions, an other option is to overload the zNear() and zFar()\n methods.\n \n\n When you visualize the Camera paths, set a larger value (suggested value is 5.0) so that the\n Camera paths are not clipped. Don't forget to restore the previous zClippingCoefficient() value back when\n you leave this mode. \n\nC++: easy3d::Camera::zClippingCoefficient() const --> float");
		cl.def("zNear", (float (easy3d::Camera::*)() const) &easy3d::Camera::zNear, "C++: easy3d::Camera::zNear() const --> float");
		cl.def("zFar", (float (easy3d::Camera::*)() const) &easy3d::Camera::zFar, "C++: easy3d::Camera::zFar() const --> float");
		cl.def("getOrthoWidthHeight", (void (easy3d::Camera::*)(float &, float &) const) &easy3d::Camera::getOrthoWidthHeight, "C++: easy3d::Camera::getOrthoWidthHeight(float &, float &) const --> void", pybind11::arg("halfWidth"), pybind11::arg("halfHeight"));
		cl.def("setType", (void (easy3d::Camera::*)(enum easy3d::Camera::Type)) &easy3d::Camera::setType, "C++: easy3d::Camera::setType(enum easy3d::Camera::Type) --> void", pybind11::arg("type"));
		cl.def("setFieldOfView", (void (easy3d::Camera::*)(float)) &easy3d::Camera::setFieldOfView, "C++: easy3d::Camera::setFieldOfView(float) --> void", pybind11::arg("fov"));
		cl.def("setHorizontalFieldOfView", (void (easy3d::Camera::*)(float)) &easy3d::Camera::setHorizontalFieldOfView, "Sets the horizontalFieldOfView() of the Camera (in radians).\n \n\n horizontalFieldOfView() and fieldOfView() are linked by the aspectRatio().\n This method actually calls setFieldOfView(( 2.0 * std::atan (std::tan(hfov / 2.0) / aspectRatio()) )) so that a call\n to horizontalFieldOfView() returns the expected value. \n\nC++: easy3d::Camera::setHorizontalFieldOfView(float) --> void", pybind11::arg("hfov"));
		cl.def("setFOVToFitScene", (void (easy3d::Camera::*)()) &easy3d::Camera::setFOVToFitScene, "C++: easy3d::Camera::setFOVToFitScene() --> void");
		cl.def("setAspectRatio", (void (easy3d::Camera::*)(float)) &easy3d::Camera::setAspectRatio, "Defines the Camera aspectRatio().\n \n\n This value is actually inferred from the screenWidth() / screenHeight() ratio.\n You should use setScreenWidthAndHeight() instead.\n This method might however be convenient when the Camera is not associated with a Viewer. It actually sets\n the screenHeight() to 100 and the screenWidth() accordingly. See also setFOVToFitScene().\n \n\n If you absolutely need an aspectRatio() that does not correspond to your viewer's window dimensions,\n overload loadProjectionMatrix() or multiply the created OpenGL projection matrix by a scaled diagonal matrix\n in your viewer's draw() method. \n\nC++: easy3d::Camera::setAspectRatio(float) --> void", pybind11::arg("aspect"));
		cl.def("setScreenWidthAndHeight", (void (easy3d::Camera::*)(int, int)) &easy3d::Camera::setScreenWidthAndHeight, "C++: easy3d::Camera::setScreenWidthAndHeight(int, int) --> void", pybind11::arg("width"), pybind11::arg("height"));
		cl.def("setZNearCoefficient", (void (easy3d::Camera::*)(float)) &easy3d::Camera::setZNearCoefficient, "Sets the zNearCoefficient() value.\n\nC++: easy3d::Camera::setZNearCoefficient(float) --> void", pybind11::arg("coef"));
		cl.def("setZClippingCoefficient", (void (easy3d::Camera::*)(float)) &easy3d::Camera::setZClippingCoefficient, "Sets the zClippingCoefficient() value.\n\nC++: easy3d::Camera::setZClippingCoefficient(float) --> void", pybind11::arg("coef"));
		cl.def("sceneRadius", (float (easy3d::Camera::*)() const) &easy3d::Camera::sceneRadius, "Returns the radius of the scene observed by the Camera.\n \n\n You need to provide such an approximation of the scene dimensions so that the Camera can adapt\n its zNear() and zFar() values. See the sceneCenter() documentation.\n \n\n setSceneBoundingBox().\n\nC++: easy3d::Camera::sceneRadius() const --> float");
		cl.def("sceneCenter", (class easy3d::Vec<3, float> (easy3d::Camera::*)() const) &easy3d::Camera::sceneCenter, "Returns the position of the scene center, defined in the world coordinate system.\n \n\n The scene observed by the Camera should be roughly centered on this position, and included in a\n sceneRadius() sphere. This approximate description of the scene permits a zNear() and zFar() clipping planes\n definition, and allows convenient positioning methods such as showEntireScene().\n Default value is (0,0,0) (world origin). Use setSceneCenter() to change it.\n \n\n setSceneBoundingBox().\n\nC++: easy3d::Camera::sceneCenter() const --> class easy3d::Vec<3, float>");
		cl.def("distanceToSceneCenter", (float (easy3d::Camera::*)() const) &easy3d::Camera::distanceToSceneCenter, "C++: easy3d::Camera::distanceToSceneCenter() const --> float");
		cl.def("setSceneRadius", (void (easy3d::Camera::*)(float)) &easy3d::Camera::setSceneRadius, "C++: easy3d::Camera::setSceneRadius(float) --> void", pybind11::arg("radius"));
		cl.def("setSceneCenter", (void (easy3d::Camera::*)(const class easy3d::Vec<3, float> &)) &easy3d::Camera::setSceneCenter, "C++: easy3d::Camera::setSceneCenter(const class easy3d::Vec<3, float> &) --> void", pybind11::arg("center"));
		cl.def("setSceneBoundingBox", (void (easy3d::Camera::*)(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &)) &easy3d::Camera::setSceneBoundingBox, "C++: easy3d::Camera::setSceneBoundingBox(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &) --> void", pybind11::arg("min"), pybind11::arg("max"));
		cl.def("setPivotPoint", (void (easy3d::Camera::*)(const class easy3d::Vec<3, float> &)) &easy3d::Camera::setPivotPoint, "C++: easy3d::Camera::setPivotPoint(const class easy3d::Vec<3, float> &) --> void", pybind11::arg("point"));
		cl.def("pivotPoint", (class easy3d::Vec<3, float> (easy3d::Camera::*)() const) &easy3d::Camera::pivotPoint, "C++: easy3d::Camera::pivotPoint() const --> class easy3d::Vec<3, float>");
		cl.def("frame", (class easy3d::ManipulatedCameraFrame * (easy3d::Camera::*)() const) &easy3d::Camera::frame, "Returns the ManipulatedFrame attached to the Camera.\n \n\n This ManipulatedFrame defines its position() and orientation() and can translate mouse events into\n Camera displacement. Set using setFrame().\n\nC++: easy3d::Camera::frame() const --> class easy3d::ManipulatedCameraFrame *", pybind11::return_value_policy::automatic);
		cl.def("setFrame", (void (easy3d::Camera::*)(class easy3d::ManipulatedCameraFrame *const)) &easy3d::Camera::setFrame, "C++: easy3d::Camera::setFrame(class easy3d::ManipulatedCameraFrame *const) --> void", pybind11::arg("mcf"));
		cl.def("computeProjectionMatrix", (void (easy3d::Camera::*)()) &easy3d::Camera::computeProjectionMatrix, "C++: easy3d::Camera::computeProjectionMatrix() --> void");
		cl.def("computeModelViewMatrix", (void (easy3d::Camera::*)()) &easy3d::Camera::computeModelViewMatrix, "C++: easy3d::Camera::computeModelViewMatrix() --> void");
		cl.def("projectionMatrix", (const class easy3d::Mat4<float> & (easy3d::Camera::*)() const) &easy3d::Camera::projectionMatrix, "C++: easy3d::Camera::projectionMatrix() const --> const class easy3d::Mat4<float> &", pybind11::return_value_policy::automatic);
		cl.def("modelViewMatrix", (const class easy3d::Mat4<float> & (easy3d::Camera::*)() const) &easy3d::Camera::modelViewMatrix, "C++: easy3d::Camera::modelViewMatrix() const --> const class easy3d::Mat4<float> &", pybind11::return_value_policy::automatic);
		cl.def("modelViewProjectionMatrix", (class easy3d::Mat4<float> (easy3d::Camera::*)() const) &easy3d::Camera::modelViewProjectionMatrix, "C++: easy3d::Camera::modelViewProjectionMatrix() const --> class easy3d::Mat4<float>");
		cl.def("cameraCoordinatesOf", (class easy3d::Vec<3, float> (easy3d::Camera::*)(const class easy3d::Vec<3, float> &) const) &easy3d::Camera::cameraCoordinatesOf, "C++: easy3d::Camera::cameraCoordinatesOf(const class easy3d::Vec<3, float> &) const --> class easy3d::Vec<3, float>", pybind11::arg("src"));
		cl.def("worldCoordinatesOf", (class easy3d::Vec<3, float> (easy3d::Camera::*)(const class easy3d::Vec<3, float> &) const) &easy3d::Camera::worldCoordinatesOf, "C++: easy3d::Camera::worldCoordinatesOf(const class easy3d::Vec<3, float> &) const --> class easy3d::Vec<3, float>", pybind11::arg("src"));
		cl.def("projectedCoordinatesOf", [](easy3d::Camera const &o, const class easy3d::Vec<3, float> & a0) -> easy3d::Vec<3, float> { return o.projectedCoordinatesOf(a0); }, "", pybind11::arg("src"));
		cl.def("projectedCoordinatesOf", (class easy3d::Vec<3, float> (easy3d::Camera::*)(const class easy3d::Vec<3, float> &, const class easy3d::Frame *) const) &easy3d::Camera::projectedCoordinatesOf, "C++: easy3d::Camera::projectedCoordinatesOf(const class easy3d::Vec<3, float> &, const class easy3d::Frame *) const --> class easy3d::Vec<3, float>", pybind11::arg("src"), pybind11::arg("frame"));
		cl.def("unprojectedCoordinatesOf", [](easy3d::Camera const &o, const class easy3d::Vec<3, float> & a0) -> easy3d::Vec<3, float> { return o.unprojectedCoordinatesOf(a0); }, "", pybind11::arg("src"));
		cl.def("unprojectedCoordinatesOf", (class easy3d::Vec<3, float> (easy3d::Camera::*)(const class easy3d::Vec<3, float> &, const class easy3d::Frame *) const) &easy3d::Camera::unprojectedCoordinatesOf, "C++: easy3d::Camera::unprojectedCoordinatesOf(const class easy3d::Vec<3, float> &, const class easy3d::Frame *) const --> class easy3d::Vec<3, float>", pybind11::arg("src"), pybind11::arg("frame"));
		cl.def("convertClickToLine", (void (easy3d::Camera::*)(int, int, class easy3d::Vec<3, float> &, class easy3d::Vec<3, float> &) const) &easy3d::Camera::convertClickToLine, "C++: easy3d::Camera::convertClickToLine(int, int, class easy3d::Vec<3, float> &, class easy3d::Vec<3, float> &) const --> void", pybind11::arg("x"), pybind11::arg("y"), pybind11::arg("orig"), pybind11::arg("dir"));
	}
}
