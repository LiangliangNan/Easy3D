#include <easy3d/algo/surface_mesh_simplification.h>
#include <easy3d/core/property.h>
#include <easy3d/core/surface_mesh.h>
#include <easy3d/core/vec.h>
#include <memory>
#include <ostream>
#include <sstream> // __str__
#include <string>
#include <string_view>
#include <typeinfo>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

// easy3d::Property file:easy3d/core/property.h line:253
struct PyCallBack_easy3d_Property_float_t : public easy3d::Property<float> {
	using easy3d::Property<float>::Property;

	float & operator[](unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Property<float> *>(this), "__getitem__");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<float &>::value) {
				static pybind11::detail::override_caster_t<float &> caster;
				return pybind11::detail::cast_ref<float &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<float &>(std::move(o));
		}
		return Property::operator[](a0);
	}
};

// easy3d::Property file:easy3d/core/property.h line:253
struct PyCallBack_easy3d_Property_double_t : public easy3d::Property<double> {
	using easy3d::Property<double>::Property;

	double & operator[](unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Property<double> *>(this), "__getitem__");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<double &>::value) {
				static pybind11::detail::override_caster_t<double &> caster;
				return pybind11::detail::cast_ref<double &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<double &>(std::move(o));
		}
		return Property::operator[](a0);
	}
};

// easy3d::Property file:easy3d/core/property.h line:253
struct PyCallBack_easy3d_Property_int_t : public easy3d::Property<int> {
	using easy3d::Property<int>::Property;

	int & operator[](unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Property<int> *>(this), "__getitem__");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<int &>::value) {
				static pybind11::detail::override_caster_t<int &> caster;
				return pybind11::detail::cast_ref<int &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<int &>(std::move(o));
		}
		return Property::operator[](a0);
	}
};

// easy3d::Property file:easy3d/core/property.h line:253
struct PyCallBack_easy3d_Property_easy3d_SurfaceMesh_Halfedge_t : public easy3d::Property<easy3d::SurfaceMesh::Halfedge> {
	using easy3d::Property<easy3d::SurfaceMesh::Halfedge>::Property;

	struct easy3d::SurfaceMesh::Halfedge & operator[](unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Property<easy3d::SurfaceMesh::Halfedge> *>(this), "__getitem__");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<struct easy3d::SurfaceMesh::Halfedge &>::value) {
				static pybind11::detail::override_caster_t<struct easy3d::SurfaceMesh::Halfedge &> caster;
				return pybind11::detail::cast_ref<struct easy3d::SurfaceMesh::Halfedge &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<struct easy3d::SurfaceMesh::Halfedge &>(std::move(o));
		}
		return Property::operator[](a0);
	}
};

// easy3d::Property file:easy3d/core/property.h line:253
struct PyCallBack_easy3d_Property_easy3d_Quadric_t : public easy3d::Property<easy3d::Quadric> {
	using easy3d::Property<easy3d::Quadric>::Property;

	class easy3d::Quadric & operator[](unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Property<easy3d::Quadric> *>(this), "__getitem__");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<class easy3d::Quadric &>::value) {
				static pybind11::detail::override_caster_t<class easy3d::Quadric &> caster;
				return pybind11::detail::cast_ref<class easy3d::Quadric &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<class easy3d::Quadric &>(std::move(o));
		}
		return Property::operator[](a0);
	}
};

// easy3d::Property file:easy3d/core/property.h line:253
struct PyCallBack_easy3d_Property_easy3d_NormalCone_t : public easy3d::Property<easy3d::NormalCone> {
	using easy3d::Property<easy3d::NormalCone>::Property;

	class easy3d::NormalCone & operator[](unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Property<easy3d::NormalCone> *>(this), "__getitem__");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<class easy3d::NormalCone &>::value) {
				static pybind11::detail::override_caster_t<class easy3d::NormalCone &> caster;
				return pybind11::detail::cast_ref<class easy3d::NormalCone &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<class easy3d::NormalCone &>(std::move(o));
		}
		return Property::operator[](a0);
	}
};

void bind_easy3d_core_property_10(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<float>, std::shared_ptr<easy3d::Property<float>>, PyCallBack_easy3d_Property_float_t> cl(M("easy3d"), "Property_float_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<float>(); }, [](){ return new PyCallBack_easy3d_Property_float_t(); } ), "doc");
		cl.def( pybind11::init<class easy3d::PropertyArray<float> *>(), pybind11::arg("p") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_Property_float_t const &o){ return new PyCallBack_easy3d_Property_float_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::Property<float> const &o){ return new easy3d::Property<float>(o); } ) );
		cl.def("reset", (void (easy3d::Property<float>::*)()) &easy3d::Property<float>::reset, "C++: easy3d::Property<float>::reset() --> void");
		cl.def("__getitem__", (float & (easy3d::Property<float>::*)(unsigned long)) &easy3d::Property<float>::operator[], "C++: easy3d::Property<float>::operator[](unsigned long) --> float &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("data", (const float * (easy3d::Property<float>::*)() const) &easy3d::Property<float>::data, "C++: easy3d::Property<float>::data() const --> const float *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<float> & (easy3d::Property<float>::*)()) &easy3d::Property<float>::vector, "C++: easy3d::Property<float>::vector() --> class std::vector<float> &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<float> & (easy3d::Property<float>::*)()) &easy3d::Property<float>::array, "C++: easy3d::Property<float>::array() --> class easy3d::PropertyArray<float> &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<float>::*)() const) &easy3d::Property<float>::name, "C++: easy3d::Property<float>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<float>::*)(const std::string &)) &easy3d::Property<float>::set_name, "C++: easy3d::Property<float>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<float> & (easy3d::Property<float>::*)(const class easy3d::Property<float> &)) &easy3d::Property<float>::operator=, "C++: easy3d::Property<float>::operator=(const class easy3d::Property<float> &) --> class easy3d::Property<float> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<double>, std::shared_ptr<easy3d::Property<double>>, PyCallBack_easy3d_Property_double_t> cl(M("easy3d"), "Property_double_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<double>(); }, [](){ return new PyCallBack_easy3d_Property_double_t(); } ), "doc");
		cl.def( pybind11::init<class easy3d::PropertyArray<double> *>(), pybind11::arg("p") );

		cl.def("reset", (void (easy3d::Property<double>::*)()) &easy3d::Property<double>::reset, "C++: easy3d::Property<double>::reset() --> void");
		cl.def("__getitem__", (double & (easy3d::Property<double>::*)(unsigned long)) &easy3d::Property<double>::operator[], "C++: easy3d::Property<double>::operator[](unsigned long) --> double &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("data", (const double * (easy3d::Property<double>::*)() const) &easy3d::Property<double>::data, "C++: easy3d::Property<double>::data() const --> const double *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<double> & (easy3d::Property<double>::*)()) &easy3d::Property<double>::vector, "C++: easy3d::Property<double>::vector() --> class std::vector<double> &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<double> & (easy3d::Property<double>::*)()) &easy3d::Property<double>::array, "C++: easy3d::Property<double>::array() --> class easy3d::PropertyArray<double> &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<double>::*)() const) &easy3d::Property<double>::name, "C++: easy3d::Property<double>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<double>::*)(const std::string &)) &easy3d::Property<double>::set_name, "C++: easy3d::Property<double>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<double> & (easy3d::Property<double>::*)(const class easy3d::Property<double> &)) &easy3d::Property<double>::operator=, "C++: easy3d::Property<double>::operator=(const class easy3d::Property<double> &) --> class easy3d::Property<double> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<int>, std::shared_ptr<easy3d::Property<int>>, PyCallBack_easy3d_Property_int_t> cl(M("easy3d"), "Property_int_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<int>(); }, [](){ return new PyCallBack_easy3d_Property_int_t(); } ), "doc");
		cl.def( pybind11::init<class easy3d::PropertyArray<int> *>(), pybind11::arg("p") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_Property_int_t const &o){ return new PyCallBack_easy3d_Property_int_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::Property<int> const &o){ return new easy3d::Property<int>(o); } ) );
		cl.def("reset", (void (easy3d::Property<int>::*)()) &easy3d::Property<int>::reset, "C++: easy3d::Property<int>::reset() --> void");
		cl.def("__getitem__", (int & (easy3d::Property<int>::*)(unsigned long)) &easy3d::Property<int>::operator[], "C++: easy3d::Property<int>::operator[](unsigned long) --> int &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("data", (const int * (easy3d::Property<int>::*)() const) &easy3d::Property<int>::data, "C++: easy3d::Property<int>::data() const --> const int *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<int> & (easy3d::Property<int>::*)()) &easy3d::Property<int>::vector, "C++: easy3d::Property<int>::vector() --> class std::vector<int> &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<int> & (easy3d::Property<int>::*)()) &easy3d::Property<int>::array, "C++: easy3d::Property<int>::array() --> class easy3d::PropertyArray<int> &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<int>::*)() const) &easy3d::Property<int>::name, "C++: easy3d::Property<int>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<int>::*)(const std::string &)) &easy3d::Property<int>::set_name, "C++: easy3d::Property<int>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<int> & (easy3d::Property<int>::*)(const class easy3d::Property<int> &)) &easy3d::Property<int>::operator=, "C++: easy3d::Property<int>::operator=(const class easy3d::Property<int> &) --> class easy3d::Property<int> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<easy3d::SurfaceMesh::Halfedge>, std::shared_ptr<easy3d::Property<easy3d::SurfaceMesh::Halfedge>>, PyCallBack_easy3d_Property_easy3d_SurfaceMesh_Halfedge_t> cl(M("easy3d"), "Property_easy3d_SurfaceMesh_Halfedge_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<easy3d::SurfaceMesh::Halfedge>(); }, [](){ return new PyCallBack_easy3d_Property_easy3d_SurfaceMesh_Halfedge_t(); } ), "doc");
		cl.def( pybind11::init<class easy3d::PropertyArray<struct easy3d::SurfaceMesh::Halfedge> *>(), pybind11::arg("p") );

		cl.def("reset", (void (easy3d::Property<easy3d::SurfaceMesh::Halfedge>::*)()) &easy3d::Property<easy3d::SurfaceMesh::Halfedge>::reset, "C++: easy3d::Property<easy3d::SurfaceMesh::Halfedge>::reset() --> void");
		cl.def("__getitem__", (struct easy3d::SurfaceMesh::Halfedge & (easy3d::Property<easy3d::SurfaceMesh::Halfedge>::*)(unsigned long)) &easy3d::Property<easy3d::SurfaceMesh::Halfedge>::operator[], "C++: easy3d::Property<easy3d::SurfaceMesh::Halfedge>::operator[](unsigned long) --> struct easy3d::SurfaceMesh::Halfedge &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("data", (const struct easy3d::SurfaceMesh::Halfedge * (easy3d::Property<easy3d::SurfaceMesh::Halfedge>::*)() const) &easy3d::Property<easy3d::SurfaceMesh::Halfedge>::data, "C++: easy3d::Property<easy3d::SurfaceMesh::Halfedge>::data() const --> const struct easy3d::SurfaceMesh::Halfedge *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<struct easy3d::SurfaceMesh::Halfedge> & (easy3d::Property<easy3d::SurfaceMesh::Halfedge>::*)()) &easy3d::Property<easy3d::SurfaceMesh::Halfedge>::vector, "C++: easy3d::Property<easy3d::SurfaceMesh::Halfedge>::vector() --> class std::vector<struct easy3d::SurfaceMesh::Halfedge> &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<struct easy3d::SurfaceMesh::Halfedge> & (easy3d::Property<easy3d::SurfaceMesh::Halfedge>::*)()) &easy3d::Property<easy3d::SurfaceMesh::Halfedge>::array, "C++: easy3d::Property<easy3d::SurfaceMesh::Halfedge>::array() --> class easy3d::PropertyArray<struct easy3d::SurfaceMesh::Halfedge> &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<easy3d::SurfaceMesh::Halfedge>::*)() const) &easy3d::Property<easy3d::SurfaceMesh::Halfedge>::name, "C++: easy3d::Property<easy3d::SurfaceMesh::Halfedge>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<easy3d::SurfaceMesh::Halfedge>::*)(const std::string &)) &easy3d::Property<easy3d::SurfaceMesh::Halfedge>::set_name, "C++: easy3d::Property<easy3d::SurfaceMesh::Halfedge>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<struct easy3d::SurfaceMesh::Halfedge> & (easy3d::Property<easy3d::SurfaceMesh::Halfedge>::*)(const class easy3d::Property<struct easy3d::SurfaceMesh::Halfedge> &)) &easy3d::Property<easy3d::SurfaceMesh::Halfedge>::operator=, "C++: easy3d::Property<easy3d::SurfaceMesh::Halfedge>::operator=(const class easy3d::Property<struct easy3d::SurfaceMesh::Halfedge> &) --> class easy3d::Property<struct easy3d::SurfaceMesh::Halfedge> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<easy3d::Quadric>, std::shared_ptr<easy3d::Property<easy3d::Quadric>>, PyCallBack_easy3d_Property_easy3d_Quadric_t> cl(M("easy3d"), "Property_easy3d_Quadric_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<easy3d::Quadric>(); }, [](){ return new PyCallBack_easy3d_Property_easy3d_Quadric_t(); } ), "doc");
		cl.def( pybind11::init<class easy3d::PropertyArray<class easy3d::Quadric> *>(), pybind11::arg("p") );

		cl.def("reset", (void (easy3d::Property<easy3d::Quadric>::*)()) &easy3d::Property<easy3d::Quadric>::reset, "C++: easy3d::Property<easy3d::Quadric>::reset() --> void");
		cl.def("__getitem__", (class easy3d::Quadric & (easy3d::Property<easy3d::Quadric>::*)(unsigned long)) &easy3d::Property<easy3d::Quadric>::operator[], "C++: easy3d::Property<easy3d::Quadric>::operator[](unsigned long) --> class easy3d::Quadric &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("data", (const class easy3d::Quadric * (easy3d::Property<easy3d::Quadric>::*)() const) &easy3d::Property<easy3d::Quadric>::data, "C++: easy3d::Property<easy3d::Quadric>::data() const --> const class easy3d::Quadric *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<class easy3d::Quadric> & (easy3d::Property<easy3d::Quadric>::*)()) &easy3d::Property<easy3d::Quadric>::vector, "C++: easy3d::Property<easy3d::Quadric>::vector() --> class std::vector<class easy3d::Quadric> &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<class easy3d::Quadric> & (easy3d::Property<easy3d::Quadric>::*)()) &easy3d::Property<easy3d::Quadric>::array, "C++: easy3d::Property<easy3d::Quadric>::array() --> class easy3d::PropertyArray<class easy3d::Quadric> &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<easy3d::Quadric>::*)() const) &easy3d::Property<easy3d::Quadric>::name, "C++: easy3d::Property<easy3d::Quadric>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<easy3d::Quadric>::*)(const std::string &)) &easy3d::Property<easy3d::Quadric>::set_name, "C++: easy3d::Property<easy3d::Quadric>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<class easy3d::Quadric> & (easy3d::Property<easy3d::Quadric>::*)(const class easy3d::Property<class easy3d::Quadric> &)) &easy3d::Property<easy3d::Quadric>::operator=, "C++: easy3d::Property<easy3d::Quadric>::operator=(const class easy3d::Property<class easy3d::Quadric> &) --> class easy3d::Property<class easy3d::Quadric> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<easy3d::NormalCone>, std::shared_ptr<easy3d::Property<easy3d::NormalCone>>, PyCallBack_easy3d_Property_easy3d_NormalCone_t> cl(M("easy3d"), "Property_easy3d_NormalCone_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<easy3d::NormalCone>(); }, [](){ return new PyCallBack_easy3d_Property_easy3d_NormalCone_t(); } ), "doc");
		cl.def( pybind11::init<class easy3d::PropertyArray<class easy3d::NormalCone> *>(), pybind11::arg("p") );

		cl.def("reset", (void (easy3d::Property<easy3d::NormalCone>::*)()) &easy3d::Property<easy3d::NormalCone>::reset, "C++: easy3d::Property<easy3d::NormalCone>::reset() --> void");
		cl.def("__getitem__", (class easy3d::NormalCone & (easy3d::Property<easy3d::NormalCone>::*)(unsigned long)) &easy3d::Property<easy3d::NormalCone>::operator[], "C++: easy3d::Property<easy3d::NormalCone>::operator[](unsigned long) --> class easy3d::NormalCone &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("data", (const class easy3d::NormalCone * (easy3d::Property<easy3d::NormalCone>::*)() const) &easy3d::Property<easy3d::NormalCone>::data, "C++: easy3d::Property<easy3d::NormalCone>::data() const --> const class easy3d::NormalCone *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<class easy3d::NormalCone> & (easy3d::Property<easy3d::NormalCone>::*)()) &easy3d::Property<easy3d::NormalCone>::vector, "C++: easy3d::Property<easy3d::NormalCone>::vector() --> class std::vector<class easy3d::NormalCone> &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<class easy3d::NormalCone> & (easy3d::Property<easy3d::NormalCone>::*)()) &easy3d::Property<easy3d::NormalCone>::array, "C++: easy3d::Property<easy3d::NormalCone>::array() --> class easy3d::PropertyArray<class easy3d::NormalCone> &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<easy3d::NormalCone>::*)() const) &easy3d::Property<easy3d::NormalCone>::name, "C++: easy3d::Property<easy3d::NormalCone>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<easy3d::NormalCone>::*)(const std::string &)) &easy3d::Property<easy3d::NormalCone>::set_name, "C++: easy3d::Property<easy3d::NormalCone>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<class easy3d::NormalCone> & (easy3d::Property<easy3d::NormalCone>::*)(const class easy3d::Property<class easy3d::NormalCone> &)) &easy3d::Property<easy3d::NormalCone>::operator=, "C++: easy3d::Property<easy3d::NormalCone>::operator=(const class easy3d::Property<class easy3d::NormalCone> &) --> class easy3d::Property<class easy3d::NormalCone> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
}
