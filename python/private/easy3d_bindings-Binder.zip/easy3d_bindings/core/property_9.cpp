#include <easy3d/core/property.h>
#include <easy3d/core/surface_mesh.h>
#include <easy3d/core/vec.h>
#include <memory>
#include <sstream> // __str__
#include <string>
#include <string_view>
#include <typeinfo>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

// easy3d::Property file:easy3d/core/property.h line:253
struct PyCallBack_easy3d_Property_easy3d_SurfaceMesh_VertexConnectivity_t : public easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity> {
	using easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::Property;

	struct easy3d::SurfaceMesh::VertexConnectivity & operator[](unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity> *>(this), "__getitem__");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<struct easy3d::SurfaceMesh::VertexConnectivity &>::value) {
				static pybind11::detail::override_caster_t<struct easy3d::SurfaceMesh::VertexConnectivity &> caster;
				return pybind11::detail::cast_ref<struct easy3d::SurfaceMesh::VertexConnectivity &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<struct easy3d::SurfaceMesh::VertexConnectivity &>(std::move(o));
		}
		return Property::operator[](a0);
	}
};

// easy3d::Property file:easy3d/core/property.h line:253
struct PyCallBack_easy3d_Property_easy3d_SurfaceMesh_HalfedgeConnectivity_t : public easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity> {
	using easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::Property;

	struct easy3d::SurfaceMesh::HalfedgeConnectivity & operator[](unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity> *>(this), "__getitem__");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<struct easy3d::SurfaceMesh::HalfedgeConnectivity &>::value) {
				static pybind11::detail::override_caster_t<struct easy3d::SurfaceMesh::HalfedgeConnectivity &> caster;
				return pybind11::detail::cast_ref<struct easy3d::SurfaceMesh::HalfedgeConnectivity &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<struct easy3d::SurfaceMesh::HalfedgeConnectivity &>(std::move(o));
		}
		return Property::operator[](a0);
	}
};

// easy3d::Property file:easy3d/core/property.h line:253
struct PyCallBack_easy3d_Property_easy3d_SurfaceMesh_FaceConnectivity_t : public easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity> {
	using easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::Property;

	struct easy3d::SurfaceMesh::FaceConnectivity & operator[](unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity> *>(this), "__getitem__");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<struct easy3d::SurfaceMesh::FaceConnectivity &>::value) {
				static pybind11::detail::override_caster_t<struct easy3d::SurfaceMesh::FaceConnectivity &> caster;
				return pybind11::detail::cast_ref<struct easy3d::SurfaceMesh::FaceConnectivity &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<struct easy3d::SurfaceMesh::FaceConnectivity &>(std::move(o));
		}
		return Property::operator[](a0);
	}
};

// easy3d::Property file:easy3d/core/property.h line:253
struct PyCallBack_easy3d_Property_easy3d_Vec_3_float_t : public easy3d::Property<easy3d::Vec<3, float>> {
	using easy3d::Property<easy3d::Vec<3, float>>::Property;

	using _binder_ret_0 = easy3d::Vec<3, float> &;
	_binder_ret_0 operator[](unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Property<easy3d::Vec<3, float>> *>(this), "__getitem__");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<_binder_ret_0>::value) {
				static pybind11::detail::override_caster_t<_binder_ret_0> caster;
				return pybind11::detail::cast_ref<_binder_ret_0>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<_binder_ret_0>(std::move(o));
		}
		return Property::operator[](a0);
	}
};

void bind_easy3d_core_property_9(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>, std::shared_ptr<easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>>, PyCallBack_easy3d_Property_easy3d_SurfaceMesh_VertexConnectivity_t> cl(M("easy3d"), "Property_easy3d_SurfaceMesh_VertexConnectivity_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>(); }, [](){ return new PyCallBack_easy3d_Property_easy3d_SurfaceMesh_VertexConnectivity_t(); } ), "doc");
		cl.def( pybind11::init<class easy3d::PropertyArray<struct easy3d::SurfaceMesh::VertexConnectivity> *>(), pybind11::arg("p") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_Property_easy3d_SurfaceMesh_VertexConnectivity_t const &o){ return new PyCallBack_easy3d_Property_easy3d_SurfaceMesh_VertexConnectivity_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity> const &o){ return new easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>(o); } ) );
		cl.def("reset", (void (easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::*)()) &easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::reset, "C++: easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::reset() --> void");
		cl.def("__getitem__", (struct easy3d::SurfaceMesh::VertexConnectivity & (easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::*)(unsigned long)) &easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::operator[], "C++: easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::operator[](unsigned long) --> struct easy3d::SurfaceMesh::VertexConnectivity &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("data", (const struct easy3d::SurfaceMesh::VertexConnectivity * (easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::*)() const) &easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::data, "C++: easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::data() const --> const struct easy3d::SurfaceMesh::VertexConnectivity *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<struct easy3d::SurfaceMesh::VertexConnectivity> & (easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::*)()) &easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::vector, "C++: easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::vector() --> class std::vector<struct easy3d::SurfaceMesh::VertexConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<struct easy3d::SurfaceMesh::VertexConnectivity> & (easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::*)()) &easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::array, "C++: easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::array() --> class easy3d::PropertyArray<struct easy3d::SurfaceMesh::VertexConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::*)() const) &easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::name, "C++: easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::*)(const std::string &)) &easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::set_name, "C++: easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<struct easy3d::SurfaceMesh::VertexConnectivity> & (easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::*)(const class easy3d::Property<struct easy3d::SurfaceMesh::VertexConnectivity> &)) &easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::operator=, "C++: easy3d::Property<easy3d::SurfaceMesh::VertexConnectivity>::operator=(const class easy3d::Property<struct easy3d::SurfaceMesh::VertexConnectivity> &) --> class easy3d::Property<struct easy3d::SurfaceMesh::VertexConnectivity> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>, std::shared_ptr<easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>>, PyCallBack_easy3d_Property_easy3d_SurfaceMesh_HalfedgeConnectivity_t> cl(M("easy3d"), "Property_easy3d_SurfaceMesh_HalfedgeConnectivity_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>(); }, [](){ return new PyCallBack_easy3d_Property_easy3d_SurfaceMesh_HalfedgeConnectivity_t(); } ), "doc");
		cl.def( pybind11::init<class easy3d::PropertyArray<struct easy3d::SurfaceMesh::HalfedgeConnectivity> *>(), pybind11::arg("p") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_Property_easy3d_SurfaceMesh_HalfedgeConnectivity_t const &o){ return new PyCallBack_easy3d_Property_easy3d_SurfaceMesh_HalfedgeConnectivity_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity> const &o){ return new easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>(o); } ) );
		cl.def("reset", (void (easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::*)()) &easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::reset, "C++: easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::reset() --> void");
		cl.def("__getitem__", (struct easy3d::SurfaceMesh::HalfedgeConnectivity & (easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::*)(unsigned long)) &easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::operator[], "C++: easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::operator[](unsigned long) --> struct easy3d::SurfaceMesh::HalfedgeConnectivity &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("data", (const struct easy3d::SurfaceMesh::HalfedgeConnectivity * (easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::*)() const) &easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::data, "C++: easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::data() const --> const struct easy3d::SurfaceMesh::HalfedgeConnectivity *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<struct easy3d::SurfaceMesh::HalfedgeConnectivity> & (easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::*)()) &easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::vector, "C++: easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::vector() --> class std::vector<struct easy3d::SurfaceMesh::HalfedgeConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<struct easy3d::SurfaceMesh::HalfedgeConnectivity> & (easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::*)()) &easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::array, "C++: easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::array() --> class easy3d::PropertyArray<struct easy3d::SurfaceMesh::HalfedgeConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::*)() const) &easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::name, "C++: easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::*)(const std::string &)) &easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::set_name, "C++: easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<struct easy3d::SurfaceMesh::HalfedgeConnectivity> & (easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::*)(const class easy3d::Property<struct easy3d::SurfaceMesh::HalfedgeConnectivity> &)) &easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::operator=, "C++: easy3d::Property<easy3d::SurfaceMesh::HalfedgeConnectivity>::operator=(const class easy3d::Property<struct easy3d::SurfaceMesh::HalfedgeConnectivity> &) --> class easy3d::Property<struct easy3d::SurfaceMesh::HalfedgeConnectivity> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>, std::shared_ptr<easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>>, PyCallBack_easy3d_Property_easy3d_SurfaceMesh_FaceConnectivity_t> cl(M("easy3d"), "Property_easy3d_SurfaceMesh_FaceConnectivity_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>(); }, [](){ return new PyCallBack_easy3d_Property_easy3d_SurfaceMesh_FaceConnectivity_t(); } ), "doc");
		cl.def( pybind11::init<class easy3d::PropertyArray<struct easy3d::SurfaceMesh::FaceConnectivity> *>(), pybind11::arg("p") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_Property_easy3d_SurfaceMesh_FaceConnectivity_t const &o){ return new PyCallBack_easy3d_Property_easy3d_SurfaceMesh_FaceConnectivity_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity> const &o){ return new easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>(o); } ) );
		cl.def("reset", (void (easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::*)()) &easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::reset, "C++: easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::reset() --> void");
		cl.def("__getitem__", (struct easy3d::SurfaceMesh::FaceConnectivity & (easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::*)(unsigned long)) &easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::operator[], "C++: easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::operator[](unsigned long) --> struct easy3d::SurfaceMesh::FaceConnectivity &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("data", (const struct easy3d::SurfaceMesh::FaceConnectivity * (easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::*)() const) &easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::data, "C++: easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::data() const --> const struct easy3d::SurfaceMesh::FaceConnectivity *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<struct easy3d::SurfaceMesh::FaceConnectivity> & (easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::*)()) &easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::vector, "C++: easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::vector() --> class std::vector<struct easy3d::SurfaceMesh::FaceConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<struct easy3d::SurfaceMesh::FaceConnectivity> & (easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::*)()) &easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::array, "C++: easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::array() --> class easy3d::PropertyArray<struct easy3d::SurfaceMesh::FaceConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::*)() const) &easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::name, "C++: easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::*)(const std::string &)) &easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::set_name, "C++: easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<struct easy3d::SurfaceMesh::FaceConnectivity> & (easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::*)(const class easy3d::Property<struct easy3d::SurfaceMesh::FaceConnectivity> &)) &easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::operator=, "C++: easy3d::Property<easy3d::SurfaceMesh::FaceConnectivity>::operator=(const class easy3d::Property<struct easy3d::SurfaceMesh::FaceConnectivity> &) --> class easy3d::Property<struct easy3d::SurfaceMesh::FaceConnectivity> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<bool>, std::shared_ptr<easy3d::Property<bool>>> cl(M("easy3d"), "Property_bool_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<bool>(); } ), "doc" );
		cl.def( pybind11::init<class easy3d::PropertyArray<bool> *>(), pybind11::arg("p") );

		cl.def( pybind11::init( [](easy3d::Property<bool> const &o){ return new easy3d::Property<bool>(o); } ) );
		cl.def("reset", (void (easy3d::Property<bool>::*)()) &easy3d::Property<bool>::reset, "C++: easy3d::Property<bool>::reset() --> void");
		cl.def("data", (const bool * (easy3d::Property<bool>::*)() const) &easy3d::Property<bool>::data, "C++: easy3d::Property<bool>::data() const --> const bool *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<bool> & (easy3d::Property<bool>::*)()) &easy3d::Property<bool>::vector, "C++: easy3d::Property<bool>::vector() --> class std::vector<bool> &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<bool> & (easy3d::Property<bool>::*)()) &easy3d::Property<bool>::array, "C++: easy3d::Property<bool>::array() --> class easy3d::PropertyArray<bool> &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<bool>::*)() const) &easy3d::Property<bool>::name, "C++: easy3d::Property<bool>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<bool>::*)(const std::string &)) &easy3d::Property<bool>::set_name, "C++: easy3d::Property<bool>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<bool> & (easy3d::Property<bool>::*)(const class easy3d::Property<bool> &)) &easy3d::Property<bool>::operator=, "C++: easy3d::Property<bool>::operator=(const class easy3d::Property<bool> &) --> class easy3d::Property<bool> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<easy3d::Vec<3, float>>, std::shared_ptr<easy3d::Property<easy3d::Vec<3, float>>>, PyCallBack_easy3d_Property_easy3d_Vec_3_float_t> cl(M("easy3d"), "Property_easy3d_Vec_3_float_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<easy3d::Vec<3, float>>(); }, [](){ return new PyCallBack_easy3d_Property_easy3d_Vec_3_float_t(); } ), "doc");
		cl.def( pybind11::init<class easy3d::PropertyArray<class easy3d::Vec<3, float> > *>(), pybind11::arg("p") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_Property_easy3d_Vec_3_float_t const &o){ return new PyCallBack_easy3d_Property_easy3d_Vec_3_float_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::Property<easy3d::Vec<3, float>> const &o){ return new easy3d::Property<easy3d::Vec<3, float>>(o); } ) );
		cl.def("reset", (void (easy3d::Property<easy3d::Vec<3, float>>::*)()) &easy3d::Property<easy3d::Vec<3, float>>::reset, "C++: easy3d::Property<easy3d::Vec<3, float>>::reset() --> void");
		cl.def("__getitem__", (class easy3d::Vec<3, float> & (easy3d::Property<easy3d::Vec<3, float>>::*)(unsigned long)) &easy3d::Property<easy3d::Vec<3, float>>::operator[], "C++: easy3d::Property<easy3d::Vec<3, float>>::operator[](unsigned long) --> class easy3d::Vec<3, float> &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("data", (const class easy3d::Vec<3, float> * (easy3d::Property<easy3d::Vec<3, float>>::*)() const) &easy3d::Property<easy3d::Vec<3, float>>::data, "C++: easy3d::Property<easy3d::Vec<3, float>>::data() const --> const class easy3d::Vec<3, float> *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<class easy3d::Vec<3, float> > & (easy3d::Property<easy3d::Vec<3, float>>::*)()) &easy3d::Property<easy3d::Vec<3, float>>::vector, "C++: easy3d::Property<easy3d::Vec<3, float>>::vector() --> class std::vector<class easy3d::Vec<3, float> > &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<class easy3d::Vec<3, float> > & (easy3d::Property<easy3d::Vec<3, float>>::*)()) &easy3d::Property<easy3d::Vec<3, float>>::array, "C++: easy3d::Property<easy3d::Vec<3, float>>::array() --> class easy3d::PropertyArray<class easy3d::Vec<3, float> > &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<easy3d::Vec<3, float>>::*)() const) &easy3d::Property<easy3d::Vec<3, float>>::name, "C++: easy3d::Property<easy3d::Vec<3, float>>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<easy3d::Vec<3, float>>::*)(const std::string &)) &easy3d::Property<easy3d::Vec<3, float>>::set_name, "C++: easy3d::Property<easy3d::Vec<3, float>>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<class easy3d::Vec<3, float> > & (easy3d::Property<easy3d::Vec<3, float>>::*)(const class easy3d::Property<class easy3d::Vec<3, float> > &)) &easy3d::Property<easy3d::Vec<3, float>>::operator=, "C++: easy3d::Property<easy3d::Vec<3, float>>::operator=(const class easy3d::Property<class easy3d::Vec<3, float> > &) --> class easy3d::Property<class easy3d::Vec<3, float> > &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
}
