#include <easy3d/core/types.h>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_core_types(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	// easy3d::next_pow2(int) file:easy3d/core/types.h line:143
	M("easy3d").def("next_pow2", (int (*)(int)) &easy3d::next_pow2, "Calculates the next larger power of 2. If the input is already a power of 2, it will return itself.\n \n\n The starting point for finding the next power of 2.\n \n\n value^2.\n Example:\n      next_pow2(50);  // returns 64\n      next_pow2(64);  // returns 64\n      next_pow2(401); // returns 512\n\nC++: easy3d::next_pow2(int) --> int", pybind11::arg("a"));

}
