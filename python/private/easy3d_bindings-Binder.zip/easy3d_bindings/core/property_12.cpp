#include <easy3d/core/poly_mesh.h>
#include <easy3d/core/property.h>
#include <easy3d/core/surface_mesh.h>
#include <istream>
#include <memory>
#include <ostream>
#include <sstream> // __str__
#include <string>
#include <string_view>
#include <typeinfo>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

// easy3d::Property file:easy3d/core/property.h line:253
struct PyCallBack_easy3d_Property_easy3d_PolyMesh_HalfFaceConnectivity_t : public easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity> {
	using easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::Property;

	struct easy3d::PolyMesh::HalfFaceConnectivity & operator[](unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity> *>(this), "__getitem__");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<struct easy3d::PolyMesh::HalfFaceConnectivity &>::value) {
				static pybind11::detail::override_caster_t<struct easy3d::PolyMesh::HalfFaceConnectivity &> caster;
				return pybind11::detail::cast_ref<struct easy3d::PolyMesh::HalfFaceConnectivity &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<struct easy3d::PolyMesh::HalfFaceConnectivity &>(std::move(o));
		}
		return Property::operator[](a0);
	}
};

// easy3d::Property file:easy3d/core/property.h line:253
struct PyCallBack_easy3d_Property_easy3d_PolyMesh_CellConnectivity_t : public easy3d::Property<easy3d::PolyMesh::CellConnectivity> {
	using easy3d::Property<easy3d::PolyMesh::CellConnectivity>::Property;

	struct easy3d::PolyMesh::CellConnectivity & operator[](unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Property<easy3d::PolyMesh::CellConnectivity> *>(this), "__getitem__");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<struct easy3d::PolyMesh::CellConnectivity &>::value) {
				static pybind11::detail::override_caster_t<struct easy3d::PolyMesh::CellConnectivity &> caster;
				return pybind11::detail::cast_ref<struct easy3d::PolyMesh::CellConnectivity &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<struct easy3d::PolyMesh::CellConnectivity &>(std::move(o));
		}
		return Property::operator[](a0);
	}
};

// easy3d::Property file:easy3d/core/property.h line:253
struct PyCallBack_easy3d_Property_easy3d_SurfaceMesh_Vertex_t : public easy3d::Property<easy3d::SurfaceMesh::Vertex> {
	using easy3d::Property<easy3d::SurfaceMesh::Vertex>::Property;

	struct easy3d::SurfaceMesh::Vertex & operator[](unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Property<easy3d::SurfaceMesh::Vertex> *>(this), "__getitem__");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<struct easy3d::SurfaceMesh::Vertex &>::value) {
				static pybind11::detail::override_caster_t<struct easy3d::SurfaceMesh::Vertex &> caster;
				return pybind11::detail::cast_ref<struct easy3d::SurfaceMesh::Vertex &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<struct easy3d::SurfaceMesh::Vertex &>(std::move(o));
		}
		return Property::operator[](a0);
	}
};

void bind_easy3d_core_property_12(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>, std::shared_ptr<easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>>, PyCallBack_easy3d_Property_easy3d_PolyMesh_HalfFaceConnectivity_t> cl(M("easy3d"), "Property_easy3d_PolyMesh_HalfFaceConnectivity_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>(); }, [](){ return new PyCallBack_easy3d_Property_easy3d_PolyMesh_HalfFaceConnectivity_t(); } ), "doc");
		cl.def( pybind11::init<class easy3d::PropertyArray<struct easy3d::PolyMesh::HalfFaceConnectivity> *>(), pybind11::arg("p") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_Property_easy3d_PolyMesh_HalfFaceConnectivity_t const &o){ return new PyCallBack_easy3d_Property_easy3d_PolyMesh_HalfFaceConnectivity_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity> const &o){ return new easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>(o); } ) );
		cl.def("reset", (void (easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::*)()) &easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::reset, "C++: easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::reset() --> void");
		cl.def("__getitem__", (struct easy3d::PolyMesh::HalfFaceConnectivity & (easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::*)(unsigned long)) &easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::operator[], "C++: easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::operator[](unsigned long) --> struct easy3d::PolyMesh::HalfFaceConnectivity &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("data", (const struct easy3d::PolyMesh::HalfFaceConnectivity * (easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::*)() const) &easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::data, "C++: easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::data() const --> const struct easy3d::PolyMesh::HalfFaceConnectivity *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<struct easy3d::PolyMesh::HalfFaceConnectivity> & (easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::*)()) &easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::vector, "C++: easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::vector() --> class std::vector<struct easy3d::PolyMesh::HalfFaceConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<struct easy3d::PolyMesh::HalfFaceConnectivity> & (easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::*)()) &easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::array, "C++: easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::array() --> class easy3d::PropertyArray<struct easy3d::PolyMesh::HalfFaceConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::*)() const) &easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::name, "C++: easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::*)(const std::string &)) &easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::set_name, "C++: easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<struct easy3d::PolyMesh::HalfFaceConnectivity> & (easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::*)(const class easy3d::Property<struct easy3d::PolyMesh::HalfFaceConnectivity> &)) &easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::operator=, "C++: easy3d::Property<easy3d::PolyMesh::HalfFaceConnectivity>::operator=(const class easy3d::Property<struct easy3d::PolyMesh::HalfFaceConnectivity> &) --> class easy3d::Property<struct easy3d::PolyMesh::HalfFaceConnectivity> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<easy3d::PolyMesh::CellConnectivity>, std::shared_ptr<easy3d::Property<easy3d::PolyMesh::CellConnectivity>>, PyCallBack_easy3d_Property_easy3d_PolyMesh_CellConnectivity_t> cl(M("easy3d"), "Property_easy3d_PolyMesh_CellConnectivity_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<easy3d::PolyMesh::CellConnectivity>(); }, [](){ return new PyCallBack_easy3d_Property_easy3d_PolyMesh_CellConnectivity_t(); } ), "doc");
		cl.def( pybind11::init<class easy3d::PropertyArray<struct easy3d::PolyMesh::CellConnectivity> *>(), pybind11::arg("p") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_Property_easy3d_PolyMesh_CellConnectivity_t const &o){ return new PyCallBack_easy3d_Property_easy3d_PolyMesh_CellConnectivity_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::Property<easy3d::PolyMesh::CellConnectivity> const &o){ return new easy3d::Property<easy3d::PolyMesh::CellConnectivity>(o); } ) );
		cl.def("reset", (void (easy3d::Property<easy3d::PolyMesh::CellConnectivity>::*)()) &easy3d::Property<easy3d::PolyMesh::CellConnectivity>::reset, "C++: easy3d::Property<easy3d::PolyMesh::CellConnectivity>::reset() --> void");
		cl.def("__getitem__", (struct easy3d::PolyMesh::CellConnectivity & (easy3d::Property<easy3d::PolyMesh::CellConnectivity>::*)(unsigned long)) &easy3d::Property<easy3d::PolyMesh::CellConnectivity>::operator[], "C++: easy3d::Property<easy3d::PolyMesh::CellConnectivity>::operator[](unsigned long) --> struct easy3d::PolyMesh::CellConnectivity &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("data", (const struct easy3d::PolyMesh::CellConnectivity * (easy3d::Property<easy3d::PolyMesh::CellConnectivity>::*)() const) &easy3d::Property<easy3d::PolyMesh::CellConnectivity>::data, "C++: easy3d::Property<easy3d::PolyMesh::CellConnectivity>::data() const --> const struct easy3d::PolyMesh::CellConnectivity *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<struct easy3d::PolyMesh::CellConnectivity> & (easy3d::Property<easy3d::PolyMesh::CellConnectivity>::*)()) &easy3d::Property<easy3d::PolyMesh::CellConnectivity>::vector, "C++: easy3d::Property<easy3d::PolyMesh::CellConnectivity>::vector() --> class std::vector<struct easy3d::PolyMesh::CellConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<struct easy3d::PolyMesh::CellConnectivity> & (easy3d::Property<easy3d::PolyMesh::CellConnectivity>::*)()) &easy3d::Property<easy3d::PolyMesh::CellConnectivity>::array, "C++: easy3d::Property<easy3d::PolyMesh::CellConnectivity>::array() --> class easy3d::PropertyArray<struct easy3d::PolyMesh::CellConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<easy3d::PolyMesh::CellConnectivity>::*)() const) &easy3d::Property<easy3d::PolyMesh::CellConnectivity>::name, "C++: easy3d::Property<easy3d::PolyMesh::CellConnectivity>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<easy3d::PolyMesh::CellConnectivity>::*)(const std::string &)) &easy3d::Property<easy3d::PolyMesh::CellConnectivity>::set_name, "C++: easy3d::Property<easy3d::PolyMesh::CellConnectivity>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<struct easy3d::PolyMesh::CellConnectivity> & (easy3d::Property<easy3d::PolyMesh::CellConnectivity>::*)(const class easy3d::Property<struct easy3d::PolyMesh::CellConnectivity> &)) &easy3d::Property<easy3d::PolyMesh::CellConnectivity>::operator=, "C++: easy3d::Property<easy3d::PolyMesh::CellConnectivity>::operator=(const class easy3d::Property<struct easy3d::PolyMesh::CellConnectivity> &) --> class easy3d::Property<struct easy3d::PolyMesh::CellConnectivity> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<easy3d::SurfaceMesh::Vertex>, std::shared_ptr<easy3d::Property<easy3d::SurfaceMesh::Vertex>>, PyCallBack_easy3d_Property_easy3d_SurfaceMesh_Vertex_t> cl(M("easy3d"), "Property_easy3d_SurfaceMesh_Vertex_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<easy3d::SurfaceMesh::Vertex>(); }, [](){ return new PyCallBack_easy3d_Property_easy3d_SurfaceMesh_Vertex_t(); } ), "doc");
		cl.def( pybind11::init<class easy3d::PropertyArray<struct easy3d::SurfaceMesh::Vertex> *>(), pybind11::arg("p") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_Property_easy3d_SurfaceMesh_Vertex_t const &o){ return new PyCallBack_easy3d_Property_easy3d_SurfaceMesh_Vertex_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::Property<easy3d::SurfaceMesh::Vertex> const &o){ return new easy3d::Property<easy3d::SurfaceMesh::Vertex>(o); } ) );
		cl.def("reset", (void (easy3d::Property<easy3d::SurfaceMesh::Vertex>::*)()) &easy3d::Property<easy3d::SurfaceMesh::Vertex>::reset, "C++: easy3d::Property<easy3d::SurfaceMesh::Vertex>::reset() --> void");
		cl.def("__getitem__", (struct easy3d::SurfaceMesh::Vertex & (easy3d::Property<easy3d::SurfaceMesh::Vertex>::*)(unsigned long)) &easy3d::Property<easy3d::SurfaceMesh::Vertex>::operator[], "C++: easy3d::Property<easy3d::SurfaceMesh::Vertex>::operator[](unsigned long) --> struct easy3d::SurfaceMesh::Vertex &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("data", (const struct easy3d::SurfaceMesh::Vertex * (easy3d::Property<easy3d::SurfaceMesh::Vertex>::*)() const) &easy3d::Property<easy3d::SurfaceMesh::Vertex>::data, "C++: easy3d::Property<easy3d::SurfaceMesh::Vertex>::data() const --> const struct easy3d::SurfaceMesh::Vertex *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<struct easy3d::SurfaceMesh::Vertex> & (easy3d::Property<easy3d::SurfaceMesh::Vertex>::*)()) &easy3d::Property<easy3d::SurfaceMesh::Vertex>::vector, "C++: easy3d::Property<easy3d::SurfaceMesh::Vertex>::vector() --> class std::vector<struct easy3d::SurfaceMesh::Vertex> &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<struct easy3d::SurfaceMesh::Vertex> & (easy3d::Property<easy3d::SurfaceMesh::Vertex>::*)()) &easy3d::Property<easy3d::SurfaceMesh::Vertex>::array, "C++: easy3d::Property<easy3d::SurfaceMesh::Vertex>::array() --> class easy3d::PropertyArray<struct easy3d::SurfaceMesh::Vertex> &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<easy3d::SurfaceMesh::Vertex>::*)() const) &easy3d::Property<easy3d::SurfaceMesh::Vertex>::name, "C++: easy3d::Property<easy3d::SurfaceMesh::Vertex>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<easy3d::SurfaceMesh::Vertex>::*)(const std::string &)) &easy3d::Property<easy3d::SurfaceMesh::Vertex>::set_name, "C++: easy3d::Property<easy3d::SurfaceMesh::Vertex>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<struct easy3d::SurfaceMesh::Vertex> & (easy3d::Property<easy3d::SurfaceMesh::Vertex>::*)(const class easy3d::Property<struct easy3d::SurfaceMesh::Vertex> &)) &easy3d::Property<easy3d::SurfaceMesh::Vertex>::operator=, "C++: easy3d::Property<easy3d::SurfaceMesh::Vertex>::operator=(const class easy3d::Property<struct easy3d::SurfaceMesh::Vertex> &) --> class easy3d::Property<struct easy3d::SurfaceMesh::Vertex> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::PropertyContainer file:easy3d/core/property.h line:341
		pybind11::class_<easy3d::PropertyContainer, std::shared_ptr<easy3d::PropertyContainer>> cl(M("easy3d"), "PropertyContainer", "Implementation of generic property container.\n \n");
		cl.def( pybind11::init( [](){ return new easy3d::PropertyContainer(); } ) );
		cl.def( pybind11::init( [](easy3d::PropertyContainer const &o){ return new easy3d::PropertyContainer(o); } ) );
		cl.def("assign", (class easy3d::PropertyContainer & (easy3d::PropertyContainer::*)(const class easy3d::PropertyContainer &)) &easy3d::PropertyContainer::operator=, "C++: easy3d::PropertyContainer::operator=(const class easy3d::PropertyContainer &) --> class easy3d::PropertyContainer &", pybind11::return_value_policy::automatic, pybind11::arg("_rhs"));
		cl.def("transfer", (void (easy3d::PropertyContainer::*)(const class easy3d::PropertyContainer &)) &easy3d::PropertyContainer::transfer, "C++: easy3d::PropertyContainer::transfer(const class easy3d::PropertyContainer &) --> void", pybind11::arg("_rhs"));
		cl.def("copy_properties", (void (easy3d::PropertyContainer::*)(const class easy3d::PropertyContainer &)) &easy3d::PropertyContainer::copy_properties, "C++: easy3d::PropertyContainer::copy_properties(const class easy3d::PropertyContainer &) --> void", pybind11::arg("_rhs"));
		cl.def("transfer", (bool (easy3d::PropertyContainer::*)(const class easy3d::PropertyContainer &, std::size_t, std::size_t)) &easy3d::PropertyContainer::transfer, "C++: easy3d::PropertyContainer::transfer(const class easy3d::PropertyContainer &, std::size_t, std::size_t) --> bool", pybind11::arg("_rhs"), pybind11::arg("from"), pybind11::arg("to"));
		cl.def("size", (unsigned long (easy3d::PropertyContainer::*)() const) &easy3d::PropertyContainer::size, "C++: easy3d::PropertyContainer::size() const --> unsigned long");
		cl.def("n_properties", (unsigned long (easy3d::PropertyContainer::*)() const) &easy3d::PropertyContainer::n_properties, "C++: easy3d::PropertyContainer::n_properties() const --> unsigned long");
		cl.def("properties", (class std::vector<std::string> (easy3d::PropertyContainer::*)() const) &easy3d::PropertyContainer::properties, "C++: easy3d::PropertyContainer::properties() const --> class std::vector<std::string>");
		cl.def("get_type", (const class std::type_info & (easy3d::PropertyContainer::*)(const std::string &) const) &easy3d::PropertyContainer::get_type, "C++: easy3d::PropertyContainer::get_type(const std::string &) const --> const class std::type_info &", pybind11::return_value_policy::automatic, pybind11::arg("name"));
		cl.def("remove", (bool (easy3d::PropertyContainer::*)(const std::string &)) &easy3d::PropertyContainer::remove, "C++: easy3d::PropertyContainer::remove(const std::string &) --> bool", pybind11::arg("name"));
		cl.def("rename", (bool (easy3d::PropertyContainer::*)(const std::string &, const std::string &)) &easy3d::PropertyContainer::rename, "C++: easy3d::PropertyContainer::rename(const std::string &, const std::string &) --> bool", pybind11::arg("old_name"), pybind11::arg("new_name"));
		cl.def("clear", (void (easy3d::PropertyContainer::*)()) &easy3d::PropertyContainer::clear, "C++: easy3d::PropertyContainer::clear() --> void");
		cl.def("reserve", (void (easy3d::PropertyContainer::*)(unsigned long) const) &easy3d::PropertyContainer::reserve, "C++: easy3d::PropertyContainer::reserve(unsigned long) const --> void", pybind11::arg("n"));
		cl.def("resize", (void (easy3d::PropertyContainer::*)(unsigned long)) &easy3d::PropertyContainer::resize, "C++: easy3d::PropertyContainer::resize(unsigned long) --> void", pybind11::arg("n"));
		cl.def("resize_property_array", (void (easy3d::PropertyContainer::*)(unsigned long)) &easy3d::PropertyContainer::resize_property_array, "C++: easy3d::PropertyContainer::resize_property_array(unsigned long) --> void", pybind11::arg("n"));
		cl.def("shrink_to_fit", (void (easy3d::PropertyContainer::*)() const) &easy3d::PropertyContainer::shrink_to_fit, "C++: easy3d::PropertyContainer::shrink_to_fit() const --> void");
		cl.def("push_back", (void (easy3d::PropertyContainer::*)()) &easy3d::PropertyContainer::push_back, "C++: easy3d::PropertyContainer::push_back() --> void");
		cl.def("reset", (void (easy3d::PropertyContainer::*)(unsigned long)) &easy3d::PropertyContainer::reset, "C++: easy3d::PropertyContainer::reset(unsigned long) --> void", pybind11::arg("idx"));
		cl.def("swap", (void (easy3d::PropertyContainer::*)(unsigned long, unsigned long) const) &easy3d::PropertyContainer::swap, "C++: easy3d::PropertyContainer::swap(unsigned long, unsigned long) const --> void", pybind11::arg("i0"), pybind11::arg("i1"));
		cl.def("swap", (void (easy3d::PropertyContainer::*)(class easy3d::PropertyContainer &)) &easy3d::PropertyContainer::swap, "C++: easy3d::PropertyContainer::swap(class easy3d::PropertyContainer &) --> void", pybind11::arg("other"));
		cl.def("copy", (void (easy3d::PropertyContainer::*)(unsigned long, unsigned long) const) &easy3d::PropertyContainer::copy, "C++: easy3d::PropertyContainer::copy(unsigned long, unsigned long) const --> void", pybind11::arg("from"), pybind11::arg("to"));
		cl.def("arrays", (class std::vector<class easy3d::BasePropertyArray *> & (easy3d::PropertyContainer::*)()) &easy3d::PropertyContainer::arrays, "C++: easy3d::PropertyContainer::arrays() --> class std::vector<class easy3d::BasePropertyArray *> &", pybind11::return_value_policy::automatic);
	}
}
