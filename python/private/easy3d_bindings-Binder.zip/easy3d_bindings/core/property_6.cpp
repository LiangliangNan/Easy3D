#include <easy3d/core/graph.h>
#include <easy3d/core/poly_mesh.h>
#include <easy3d/core/property.h>
#include <istream>
#include <memory>
#include <ostream>
#include <sstream> // __str__
#include <string>
#include <string_view>
#include <typeinfo>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

// easy3d::PropertyArray file:easy3d/core/property.h line:111
struct PyCallBack_easy3d_PropertyArray_easy3d_Graph_EdgeConnectivity_t : public easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity> {
	using easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::PropertyArray;

	void reserve(unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity> *>(this), "reserve");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::reserve(a0);
	}
	void resize(unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity> *>(this), "resize");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::resize(a0);
	}
	void push_back() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity> *>(this), "push_back");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::push_back();
	}
	void reset(unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity> *>(this), "reset");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::reset(a0);
	}
	bool transfer(const class easy3d::BasePropertyArray & a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity> *>(this), "transfer");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return PropertyArray::transfer(a0);
	}
	bool transfer(const class easy3d::BasePropertyArray & a0, std::size_t a1, std::size_t a2) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity> *>(this), "transfer");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return PropertyArray::transfer(a0, a1, a2);
	}
	void shrink_to_fit() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity> *>(this), "shrink_to_fit");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::shrink_to_fit();
	}
	void swap(unsigned long a0, unsigned long a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity> *>(this), "swap");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::swap(a0, a1);
	}
	void copy(unsigned long a0, unsigned long a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity> *>(this), "copy");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::copy(a0, a1);
	}
	class easy3d::BasePropertyArray * clone() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity> *>(this), "clone");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<class easy3d::BasePropertyArray *>::value) {
				static pybind11::detail::override_caster_t<class easy3d::BasePropertyArray *> caster;
				return pybind11::detail::cast_ref<class easy3d::BasePropertyArray *>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<class easy3d::BasePropertyArray *>(std::move(o));
		}
		return PropertyArray::clone();
	}
	class easy3d::BasePropertyArray * empty_clone() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity> *>(this), "empty_clone");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<class easy3d::BasePropertyArray *>::value) {
				static pybind11::detail::override_caster_t<class easy3d::BasePropertyArray *> caster;
				return pybind11::detail::cast_ref<class easy3d::BasePropertyArray *>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<class easy3d::BasePropertyArray *>(std::move(o));
		}
		return PropertyArray::empty_clone();
	}
	const class std::type_info & type() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity> *>(this), "type");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<const class std::type_info &>::value) {
				static pybind11::detail::override_caster_t<const class std::type_info &> caster;
				return pybind11::detail::cast_ref<const class std::type_info &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<const class std::type_info &>(std::move(o));
		}
		return PropertyArray::type();
	}
};

// easy3d::PropertyArray file:easy3d/core/property.h line:111
struct PyCallBack_easy3d_PropertyArray_easy3d_PolyMesh_VertexConnectivity_t : public easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity> {
	using easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::PropertyArray;

	void reserve(unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity> *>(this), "reserve");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::reserve(a0);
	}
	void resize(unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity> *>(this), "resize");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::resize(a0);
	}
	void push_back() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity> *>(this), "push_back");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::push_back();
	}
	void reset(unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity> *>(this), "reset");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::reset(a0);
	}
	bool transfer(const class easy3d::BasePropertyArray & a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity> *>(this), "transfer");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return PropertyArray::transfer(a0);
	}
	bool transfer(const class easy3d::BasePropertyArray & a0, std::size_t a1, std::size_t a2) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity> *>(this), "transfer");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return PropertyArray::transfer(a0, a1, a2);
	}
	void shrink_to_fit() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity> *>(this), "shrink_to_fit");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::shrink_to_fit();
	}
	void swap(unsigned long a0, unsigned long a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity> *>(this), "swap");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::swap(a0, a1);
	}
	void copy(unsigned long a0, unsigned long a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity> *>(this), "copy");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::copy(a0, a1);
	}
	class easy3d::BasePropertyArray * clone() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity> *>(this), "clone");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<class easy3d::BasePropertyArray *>::value) {
				static pybind11::detail::override_caster_t<class easy3d::BasePropertyArray *> caster;
				return pybind11::detail::cast_ref<class easy3d::BasePropertyArray *>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<class easy3d::BasePropertyArray *>(std::move(o));
		}
		return PropertyArray::clone();
	}
	class easy3d::BasePropertyArray * empty_clone() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity> *>(this), "empty_clone");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<class easy3d::BasePropertyArray *>::value) {
				static pybind11::detail::override_caster_t<class easy3d::BasePropertyArray *> caster;
				return pybind11::detail::cast_ref<class easy3d::BasePropertyArray *>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<class easy3d::BasePropertyArray *>(std::move(o));
		}
		return PropertyArray::empty_clone();
	}
	const class std::type_info & type() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity> *>(this), "type");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<const class std::type_info &>::value) {
				static pybind11::detail::override_caster_t<const class std::type_info &> caster;
				return pybind11::detail::cast_ref<const class std::type_info &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<const class std::type_info &>(std::move(o));
		}
		return PropertyArray::type();
	}
};

void bind_easy3d_core_property_6(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	{ // easy3d::PropertyArray file:easy3d/core/property.h line:111
		pybind11::class_<easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>, std::shared_ptr<easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>>, PyCallBack_easy3d_PropertyArray_easy3d_Graph_EdgeConnectivity_t, easy3d::BasePropertyArray> cl(M("easy3d"), "PropertyArray_easy3d_Graph_EdgeConnectivity_t", "");
		cl.def( pybind11::init( [](const std::string & a0){ return new easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>(a0); }, [](const std::string & a0){ return new PyCallBack_easy3d_PropertyArray_easy3d_Graph_EdgeConnectivity_t(a0); } ), "doc");
		cl.def( pybind11::init<const std::string &, struct easy3d::Graph::EdgeConnectivity>(), pybind11::arg("name"), pybind11::arg("t") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_PropertyArray_easy3d_Graph_EdgeConnectivity_t const &o){ return new PyCallBack_easy3d_PropertyArray_easy3d_Graph_EdgeConnectivity_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity> const &o){ return new easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>(o); } ) );
		cl.def("reserve", (void (easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::reserve, "C++: easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::reserve(unsigned long) --> void", pybind11::arg("n"));
		cl.def("resize", (void (easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::resize, "C++: easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::resize(unsigned long) --> void", pybind11::arg("n"));
		cl.def("push_back", (void (easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::*)()) &easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::push_back, "C++: easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::push_back() --> void");
		cl.def("reset", (void (easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::reset, "C++: easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::reset(unsigned long) --> void", pybind11::arg("idx"));
		cl.def("transfer", (bool (easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::*)(const class easy3d::BasePropertyArray &)) &easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::transfer, "C++: easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::transfer(const class easy3d::BasePropertyArray &) --> bool", pybind11::arg("other"));
		cl.def("transfer", (bool (easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::*)(const class easy3d::BasePropertyArray &, std::size_t, std::size_t)) &easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::transfer, "C++: easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::transfer(const class easy3d::BasePropertyArray &, std::size_t, std::size_t) --> bool", pybind11::arg("other"), pybind11::arg("from"), pybind11::arg("to"));
		cl.def("shrink_to_fit", (void (easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::*)()) &easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::shrink_to_fit, "C++: easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::shrink_to_fit() --> void");
		cl.def("swap", (void (easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::*)(unsigned long, unsigned long)) &easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::swap, "C++: easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::swap(unsigned long, unsigned long) --> void", pybind11::arg("i0"), pybind11::arg("i1"));
		cl.def("copy", (void (easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::*)(unsigned long, unsigned long)) &easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::copy, "C++: easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::copy(unsigned long, unsigned long) --> void", pybind11::arg("from"), pybind11::arg("to"));
		cl.def("clone", (class easy3d::BasePropertyArray * (easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::*)() const) &easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::clone, "C++: easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("empty_clone", (class easy3d::BasePropertyArray * (easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::*)() const) &easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::empty_clone, "C++: easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::empty_clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("type", (const class std::type_info & (easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::*)() const) &easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::type, "C++: easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::type() const --> const class std::type_info &", pybind11::return_value_policy::automatic);
		cl.def("data", (const struct easy3d::Graph::EdgeConnectivity * (easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::*)() const) &easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::data, "C++: easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::data() const --> const struct easy3d::Graph::EdgeConnectivity *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<struct easy3d::Graph::EdgeConnectivity> & (easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::*)()) &easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::vector, "C++: easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::vector() --> class std::vector<struct easy3d::Graph::EdgeConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("__getitem__", (struct easy3d::Graph::EdgeConnectivity & (easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::operator[], "C++: easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::operator[](unsigned long) --> struct easy3d::Graph::EdgeConnectivity &", pybind11::return_value_policy::automatic, pybind11::arg("_idx"));
		cl.def("assign", (class easy3d::PropertyArray<struct easy3d::Graph::EdgeConnectivity> & (easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::*)(const class easy3d::PropertyArray<struct easy3d::Graph::EdgeConnectivity> &)) &easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::operator=, "C++: easy3d::PropertyArray<easy3d::Graph::EdgeConnectivity>::operator=(const class easy3d::PropertyArray<struct easy3d::Graph::EdgeConnectivity> &) --> class easy3d::PropertyArray<struct easy3d::Graph::EdgeConnectivity> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
		cl.def("reserve", (void (easy3d::BasePropertyArray::*)(unsigned long)) &easy3d::BasePropertyArray::reserve, "Reserve memory for n elements.\n\nC++: easy3d::BasePropertyArray::reserve(unsigned long) --> void", pybind11::arg("n"));
		cl.def("resize", (void (easy3d::BasePropertyArray::*)(unsigned long)) &easy3d::BasePropertyArray::resize, "Resize storage to hold n elements.\n\nC++: easy3d::BasePropertyArray::resize(unsigned long) --> void", pybind11::arg("n"));
		cl.def("shrink_to_fit", (void (easy3d::BasePropertyArray::*)()) &easy3d::BasePropertyArray::shrink_to_fit, "Free unused memory.\n\nC++: easy3d::BasePropertyArray::shrink_to_fit() --> void");
		cl.def("push_back", (void (easy3d::BasePropertyArray::*)()) &easy3d::BasePropertyArray::push_back, "Extend the number of elements by one.\n\nC++: easy3d::BasePropertyArray::push_back() --> void");
		cl.def("reset", (void (easy3d::BasePropertyArray::*)(unsigned long)) &easy3d::BasePropertyArray::reset, "Reset element to default value\n\nC++: easy3d::BasePropertyArray::reset(unsigned long) --> void", pybind11::arg("idx"));
		cl.def("transfer", (bool (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &)) &easy3d::BasePropertyArray::transfer, "Copy the entire properties from \n\nC++: easy3d::BasePropertyArray::transfer(const class easy3d::BasePropertyArray &) --> bool", pybind11::arg("other"));
		cl.def("transfer", (bool (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &, std::size_t, std::size_t)) &easy3d::BasePropertyArray::transfer, "Copy the property[from] of  to this->property[to].\n\nC++: easy3d::BasePropertyArray::transfer(const class easy3d::BasePropertyArray &, std::size_t, std::size_t) --> bool", pybind11::arg("other"), pybind11::arg("from"), pybind11::arg("to"));
		cl.def("swap", (void (easy3d::BasePropertyArray::*)(unsigned long, unsigned long)) &easy3d::BasePropertyArray::swap, "Let two elements swap their storage place.\n\nC++: easy3d::BasePropertyArray::swap(unsigned long, unsigned long) --> void", pybind11::arg("i0"), pybind11::arg("i1"));
		cl.def("copy", (void (easy3d::BasePropertyArray::*)(unsigned long, unsigned long)) &easy3d::BasePropertyArray::copy, "Let copy 'from' -> 'to'.\n\nC++: easy3d::BasePropertyArray::copy(unsigned long, unsigned long) --> void", pybind11::arg("from"), pybind11::arg("to"));
		cl.def("clone", (class easy3d::BasePropertyArray * (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::clone, "Return a deep copy of self.\n\nC++: easy3d::BasePropertyArray::clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("empty_clone", (class easy3d::BasePropertyArray * (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::empty_clone, "Return a empty copy of self.\n\nC++: easy3d::BasePropertyArray::empty_clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("type", (const class std::type_info & (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::type, "Return the type_info of the property\n\nC++: easy3d::BasePropertyArray::type() const --> const class std::type_info &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::name, "Return the name of the property\n\nC++: easy3d::BasePropertyArray::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::BasePropertyArray::*)(const std::string &)) &easy3d::BasePropertyArray::set_name, "Set the name of the property\n\nC++: easy3d::BasePropertyArray::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("is_same", (bool (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &) const) &easy3d::BasePropertyArray::is_same, "Test if two properties are the same.\n \n\n true only if their names and types are both identical.\n\nC++: easy3d::BasePropertyArray::is_same(const class easy3d::BasePropertyArray &) const --> bool", pybind11::arg("other"));
		cl.def("assign", (class easy3d::BasePropertyArray & (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &)) &easy3d::BasePropertyArray::operator=, "C++: easy3d::BasePropertyArray::operator=(const class easy3d::BasePropertyArray &) --> class easy3d::BasePropertyArray &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::PropertyArray file:easy3d/core/property.h line:111
		pybind11::class_<easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>, std::shared_ptr<easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>>, PyCallBack_easy3d_PropertyArray_easy3d_PolyMesh_VertexConnectivity_t, easy3d::BasePropertyArray> cl(M("easy3d"), "PropertyArray_easy3d_PolyMesh_VertexConnectivity_t", "");
		cl.def( pybind11::init( [](const std::string & a0){ return new easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>(a0); }, [](const std::string & a0){ return new PyCallBack_easy3d_PropertyArray_easy3d_PolyMesh_VertexConnectivity_t(a0); } ), "doc");
		cl.def( pybind11::init<const std::string &, struct easy3d::PolyMesh::VertexConnectivity>(), pybind11::arg("name"), pybind11::arg("t") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_PropertyArray_easy3d_PolyMesh_VertexConnectivity_t const &o){ return new PyCallBack_easy3d_PropertyArray_easy3d_PolyMesh_VertexConnectivity_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity> const &o){ return new easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>(o); } ) );
		cl.def("reserve", (void (easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::reserve, "C++: easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::reserve(unsigned long) --> void", pybind11::arg("n"));
		cl.def("resize", (void (easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::resize, "C++: easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::resize(unsigned long) --> void", pybind11::arg("n"));
		cl.def("push_back", (void (easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::*)()) &easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::push_back, "C++: easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::push_back() --> void");
		cl.def("reset", (void (easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::reset, "C++: easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::reset(unsigned long) --> void", pybind11::arg("idx"));
		cl.def("transfer", (bool (easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::*)(const class easy3d::BasePropertyArray &)) &easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::transfer, "C++: easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::transfer(const class easy3d::BasePropertyArray &) --> bool", pybind11::arg("other"));
		cl.def("transfer", (bool (easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::*)(const class easy3d::BasePropertyArray &, std::size_t, std::size_t)) &easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::transfer, "C++: easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::transfer(const class easy3d::BasePropertyArray &, std::size_t, std::size_t) --> bool", pybind11::arg("other"), pybind11::arg("from"), pybind11::arg("to"));
		cl.def("shrink_to_fit", (void (easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::*)()) &easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::shrink_to_fit, "C++: easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::shrink_to_fit() --> void");
		cl.def("swap", (void (easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::*)(unsigned long, unsigned long)) &easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::swap, "C++: easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::swap(unsigned long, unsigned long) --> void", pybind11::arg("i0"), pybind11::arg("i1"));
		cl.def("copy", (void (easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::*)(unsigned long, unsigned long)) &easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::copy, "C++: easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::copy(unsigned long, unsigned long) --> void", pybind11::arg("from"), pybind11::arg("to"));
		cl.def("clone", (class easy3d::BasePropertyArray * (easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::*)() const) &easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::clone, "C++: easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("empty_clone", (class easy3d::BasePropertyArray * (easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::*)() const) &easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::empty_clone, "C++: easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::empty_clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("type", (const class std::type_info & (easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::*)() const) &easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::type, "C++: easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::type() const --> const class std::type_info &", pybind11::return_value_policy::automatic);
		cl.def("data", (const struct easy3d::PolyMesh::VertexConnectivity * (easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::*)() const) &easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::data, "C++: easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::data() const --> const struct easy3d::PolyMesh::VertexConnectivity *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<struct easy3d::PolyMesh::VertexConnectivity> & (easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::*)()) &easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::vector, "C++: easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::vector() --> class std::vector<struct easy3d::PolyMesh::VertexConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("__getitem__", (struct easy3d::PolyMesh::VertexConnectivity & (easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::operator[], "C++: easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::operator[](unsigned long) --> struct easy3d::PolyMesh::VertexConnectivity &", pybind11::return_value_policy::automatic, pybind11::arg("_idx"));
		cl.def("assign", (class easy3d::PropertyArray<struct easy3d::PolyMesh::VertexConnectivity> & (easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::*)(const class easy3d::PropertyArray<struct easy3d::PolyMesh::VertexConnectivity> &)) &easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::operator=, "C++: easy3d::PropertyArray<easy3d::PolyMesh::VertexConnectivity>::operator=(const class easy3d::PropertyArray<struct easy3d::PolyMesh::VertexConnectivity> &) --> class easy3d::PropertyArray<struct easy3d::PolyMesh::VertexConnectivity> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
		cl.def("reserve", (void (easy3d::BasePropertyArray::*)(unsigned long)) &easy3d::BasePropertyArray::reserve, "Reserve memory for n elements.\n\nC++: easy3d::BasePropertyArray::reserve(unsigned long) --> void", pybind11::arg("n"));
		cl.def("resize", (void (easy3d::BasePropertyArray::*)(unsigned long)) &easy3d::BasePropertyArray::resize, "Resize storage to hold n elements.\n\nC++: easy3d::BasePropertyArray::resize(unsigned long) --> void", pybind11::arg("n"));
		cl.def("shrink_to_fit", (void (easy3d::BasePropertyArray::*)()) &easy3d::BasePropertyArray::shrink_to_fit, "Free unused memory.\n\nC++: easy3d::BasePropertyArray::shrink_to_fit() --> void");
		cl.def("push_back", (void (easy3d::BasePropertyArray::*)()) &easy3d::BasePropertyArray::push_back, "Extend the number of elements by one.\n\nC++: easy3d::BasePropertyArray::push_back() --> void");
		cl.def("reset", (void (easy3d::BasePropertyArray::*)(unsigned long)) &easy3d::BasePropertyArray::reset, "Reset element to default value\n\nC++: easy3d::BasePropertyArray::reset(unsigned long) --> void", pybind11::arg("idx"));
		cl.def("transfer", (bool (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &)) &easy3d::BasePropertyArray::transfer, "Copy the entire properties from \n\nC++: easy3d::BasePropertyArray::transfer(const class easy3d::BasePropertyArray &) --> bool", pybind11::arg("other"));
		cl.def("transfer", (bool (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &, std::size_t, std::size_t)) &easy3d::BasePropertyArray::transfer, "Copy the property[from] of  to this->property[to].\n\nC++: easy3d::BasePropertyArray::transfer(const class easy3d::BasePropertyArray &, std::size_t, std::size_t) --> bool", pybind11::arg("other"), pybind11::arg("from"), pybind11::arg("to"));
		cl.def("swap", (void (easy3d::BasePropertyArray::*)(unsigned long, unsigned long)) &easy3d::BasePropertyArray::swap, "Let two elements swap their storage place.\n\nC++: easy3d::BasePropertyArray::swap(unsigned long, unsigned long) --> void", pybind11::arg("i0"), pybind11::arg("i1"));
		cl.def("copy", (void (easy3d::BasePropertyArray::*)(unsigned long, unsigned long)) &easy3d::BasePropertyArray::copy, "Let copy 'from' -> 'to'.\n\nC++: easy3d::BasePropertyArray::copy(unsigned long, unsigned long) --> void", pybind11::arg("from"), pybind11::arg("to"));
		cl.def("clone", (class easy3d::BasePropertyArray * (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::clone, "Return a deep copy of self.\n\nC++: easy3d::BasePropertyArray::clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("empty_clone", (class easy3d::BasePropertyArray * (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::empty_clone, "Return a empty copy of self.\n\nC++: easy3d::BasePropertyArray::empty_clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("type", (const class std::type_info & (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::type, "Return the type_info of the property\n\nC++: easy3d::BasePropertyArray::type() const --> const class std::type_info &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::name, "Return the name of the property\n\nC++: easy3d::BasePropertyArray::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::BasePropertyArray::*)(const std::string &)) &easy3d::BasePropertyArray::set_name, "Set the name of the property\n\nC++: easy3d::BasePropertyArray::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("is_same", (bool (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &) const) &easy3d::BasePropertyArray::is_same, "Test if two properties are the same.\n \n\n true only if their names and types are both identical.\n\nC++: easy3d::BasePropertyArray::is_same(const class easy3d::BasePropertyArray &) const --> bool", pybind11::arg("other"));
		cl.def("assign", (class easy3d::BasePropertyArray & (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &)) &easy3d::BasePropertyArray::operator=, "C++: easy3d::BasePropertyArray::operator=(const class easy3d::BasePropertyArray &) --> class easy3d::BasePropertyArray &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
}
