#include <easy3d/core/box.h>
#include <easy3d/core/line.h>
#include <easy3d/core/oriented_line.h>
#include <easy3d/core/plane.h>
#include <easy3d/core/vec.h>
#include <ios>
#include <locale>
#include <ostream>
#include <sstream> // __str__
#include <streambuf>
#include <string>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_core_line(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	{ // easy3d::GenericLine file:easy3d/core/line.h line:42
		pybind11::class_<easy3d::GenericLine<3,float>, std::shared_ptr<easy3d::GenericLine<3,float>>> cl(M("easy3d"), "GenericLine_3_float_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::GenericLine<3,float>(); } ) );
		cl.def( pybind11::init( [](easy3d::GenericLine<3,float> const &o){ return new easy3d::GenericLine<3,float>(o); } ) );
		cl.def_static("from_point_and_direction", (class easy3d::GenericLine<3, float> (*)(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &)) &easy3d::GenericLine<3, float>::from_point_and_direction, "C++: easy3d::GenericLine<3, float>::from_point_and_direction(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &) --> class easy3d::GenericLine<3, float>", pybind11::arg("p"), pybind11::arg("dir"));
		cl.def_static("from_two_points", (class easy3d::GenericLine<3, float> (*)(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &)) &easy3d::GenericLine<3, float>::from_two_points, "C++: easy3d::GenericLine<3, float>::from_two_points(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &) --> class easy3d::GenericLine<3, float>", pybind11::arg("p"), pybind11::arg("q"));
		cl.def("set", (void (easy3d::GenericLine<3,float>::*)(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &)) &easy3d::GenericLine<3, float>::set, "C++: easy3d::GenericLine<3, float>::set(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &) --> void", pybind11::arg("p"), pybind11::arg("dir"));
		cl.def("direction", (const class easy3d::Vec<3, float> & (easy3d::GenericLine<3,float>::*)() const) &easy3d::GenericLine<3, float>::direction, "C++: easy3d::GenericLine<3, float>::direction() const --> const class easy3d::Vec<3, float> &", pybind11::return_value_policy::automatic);
		cl.def("point", (const class easy3d::Vec<3, float> & (easy3d::GenericLine<3,float>::*)() const) &easy3d::GenericLine<3, float>::point, "C++: easy3d::GenericLine<3, float>::point() const --> const class easy3d::Vec<3, float> &", pybind11::return_value_policy::automatic);
		cl.def("projection", (class easy3d::Vec<3, float> (easy3d::GenericLine<3,float>::*)(const class easy3d::Vec<3, float> &) const) &easy3d::GenericLine<3, float>::projection, "C++: easy3d::GenericLine<3, float>::projection(const class easy3d::Vec<3, float> &) const --> class easy3d::Vec<3, float>", pybind11::arg("p"));
		cl.def("squared_distance", (float (easy3d::GenericLine<3,float>::*)(const class easy3d::Vec<3, float> &) const) &easy3d::GenericLine<3, float>::squared_distance, "C++: easy3d::GenericLine<3, float>::squared_distance(const class easy3d::Vec<3, float> &) const --> float", pybind11::arg("p"));
		cl.def("feet", (bool (easy3d::GenericLine<3,float>::*)(const class easy3d::GenericLine<3, float> &, class easy3d::Vec<3, float> &, class easy3d::Vec<3, float> &) const) &easy3d::GenericLine<3, float>::feet, "C++: easy3d::GenericLine<3, float>::feet(const class easy3d::GenericLine<3, float> &, class easy3d::Vec<3, float> &, class easy3d::Vec<3, float> &) const --> bool", pybind11::arg("other"), pybind11::arg("p1"), pybind11::arg("p2"));
	}
	// easy3d::Sign file:easy3d/core/oriented_line.h line:20
	pybind11::enum_<easy3d::Sign>(M("easy3d"), "Sign", pybind11::arithmetic(), "The sign.")
		.value("NEGATIVE", easy3d::NEGATIVE)
		.value("ZERO", easy3d::ZERO)
		.value("POSITIVE", easy3d::POSITIVE)
		.export_values();

;

	// easy3d::sign(float) file:easy3d/core/oriented_line.h line:28
	M("easy3d").def("sign", (enum easy3d::Sign (*)(float)) &easy3d::sign<float>, "C++: easy3d::sign(float) --> enum easy3d::Sign", pybind11::arg("x"));

	{ // easy3d::GenericOrientedLine file:easy3d/core/oriented_line.h line:43
		pybind11::class_<easy3d::GenericOrientedLine<float>, std::shared_ptr<easy3d::GenericOrientedLine<float>>> cl(M("easy3d"), "GenericOrientedLine_float_t", "");
		cl.def( pybind11::init<const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &>(), pybind11::arg("p"), pybind11::arg("q") );

		cl.def( pybind11::init( [](){ return new easy3d::GenericOrientedLine<float>(); } ) );
		cl.def( pybind11::init( [](easy3d::GenericOrientedLine<float> const &o){ return new easy3d::GenericOrientedLine<float>(o); } ) );
		cl.def_static("side", (enum easy3d::Sign (*)(const class easy3d::GenericOrientedLine<float> &, const class easy3d::GenericOrientedLine<float> &)) &easy3d::GenericOrientedLine<float>::side, "C++: easy3d::GenericOrientedLine<float>::side(const class easy3d::GenericOrientedLine<float> &, const class easy3d::GenericOrientedLine<float> &) --> enum easy3d::Sign", pybind11::arg("a"), pybind11::arg("b"));
	}
	{ // easy3d::GenericPlane file:easy3d/core/plane.h line:41
		pybind11::class_<easy3d::GenericPlane<float>, std::shared_ptr<easy3d::GenericPlane<float>>> cl(M("easy3d"), "GenericPlane_float_t", "");
		cl.def( pybind11::init<const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &>(), pybind11::arg("p1"), pybind11::arg("p2"), pybind11::arg("p3") );

		cl.def( pybind11::init<const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &>(), pybind11::arg("p"), pybind11::arg("n") );

		cl.def( pybind11::init<float, float, float, float>(), pybind11::arg("a"), pybind11::arg("b"), pybind11::arg("c"), pybind11::arg("d") );

		cl.def( pybind11::init( [](){ return new easy3d::GenericPlane<float>(); } ) );
		cl.def( pybind11::init( [](easy3d::GenericPlane<float> const &o){ return new easy3d::GenericPlane<float>(o); } ) );
		cl.def("a", (float (easy3d::GenericPlane<float>::*)() const) &easy3d::GenericPlane<float>::a, "C++: easy3d::GenericPlane<float>::a() const --> float");
		cl.def("b", (float (easy3d::GenericPlane<float>::*)() const) &easy3d::GenericPlane<float>::b, "C++: easy3d::GenericPlane<float>::b() const --> float");
		cl.def("c", (float (easy3d::GenericPlane<float>::*)() const) &easy3d::GenericPlane<float>::c, "C++: easy3d::GenericPlane<float>::c() const --> float");
		cl.def("d", (float (easy3d::GenericPlane<float>::*)() const) &easy3d::GenericPlane<float>::d, "C++: easy3d::GenericPlane<float>::d() const --> float");
		cl.def("__getitem__", (float & (easy3d::GenericPlane<float>::*)(unsigned long)) &easy3d::GenericPlane<float>::operator[], "C++: easy3d::GenericPlane<float>::operator[](unsigned long) --> float &", pybind11::return_value_policy::automatic, pybind11::arg("idx"));
		cl.def("normal", (class easy3d::Vec<3, float> (easy3d::GenericPlane<float>::*)() const) &easy3d::GenericPlane<float>::normal, "C++: easy3d::GenericPlane<float>::normal() const --> class easy3d::Vec<3, float>");
		cl.def("point", (class easy3d::Vec<3, float> (easy3d::GenericPlane<float>::*)() const) &easy3d::GenericPlane<float>::point, "C++: easy3d::GenericPlane<float>::point() const --> class easy3d::Vec<3, float>");
		cl.def("base1", (class easy3d::Vec<3, float> (easy3d::GenericPlane<float>::*)() const) &easy3d::GenericPlane<float>::base1, "C++: easy3d::GenericPlane<float>::base1() const --> class easy3d::Vec<3, float>");
		cl.def("base2", (class easy3d::Vec<3, float> (easy3d::GenericPlane<float>::*)() const) &easy3d::GenericPlane<float>::base2, "C++: easy3d::GenericPlane<float>::base2() const --> class easy3d::Vec<3, float>");
		cl.def("to_2d", (class easy3d::Vec<2, float> (easy3d::GenericPlane<float>::*)(const class easy3d::Vec<3, float> &) const) &easy3d::GenericPlane<float>::to_2d, "C++: easy3d::GenericPlane<float>::to_2d(const class easy3d::Vec<3, float> &) const --> class easy3d::Vec<2, float>", pybind11::arg("p"));
		cl.def("to_3d", (class easy3d::Vec<3, float> (easy3d::GenericPlane<float>::*)(const class easy3d::Vec<2, float> &) const) &easy3d::GenericPlane<float>::to_3d, "C++: easy3d::GenericPlane<float>::to_3d(const class easy3d::Vec<2, float> &) const --> class easy3d::Vec<3, float>", pybind11::arg("p"));
		cl.def("projection", (class easy3d::Vec<3, float> (easy3d::GenericPlane<float>::*)(const class easy3d::Vec<3, float> &) const) &easy3d::GenericPlane<float>::projection, "C++: easy3d::GenericPlane<float>::projection(const class easy3d::Vec<3, float> &) const --> class easy3d::Vec<3, float>", pybind11::arg("p"));
		cl.def("value", (float (easy3d::GenericPlane<float>::*)(const class easy3d::Vec<3, float> &) const) &easy3d::GenericPlane<float>::value, "C++: easy3d::GenericPlane<float>::value(const class easy3d::Vec<3, float> &) const --> float", pybind11::arg("p"));
		cl.def("squared_distance", (float (easy3d::GenericPlane<float>::*)(const class easy3d::Vec<3, float> &) const) &easy3d::GenericPlane<float>::squared_distance, "C++: easy3d::GenericPlane<float>::squared_distance(const class easy3d::Vec<3, float> &) const --> float", pybind11::arg("p"));
		cl.def("intersect", (bool (easy3d::GenericPlane<float>::*)(const class easy3d::GenericLine<3, float> &, class easy3d::Vec<3, float> &) const) &easy3d::GenericPlane<float>::intersect, "C++: easy3d::GenericPlane<float>::intersect(const class easy3d::GenericLine<3, float> &, class easy3d::Vec<3, float> &) const --> bool", pybind11::arg("line"), pybind11::arg("p"));
		cl.def("intersect", (bool (easy3d::GenericPlane<float>::*)(const class easy3d::GenericLine<3, float> &) const) &easy3d::GenericPlane<float>::intersect, "C++: easy3d::GenericPlane<float>::intersect(const class easy3d::GenericLine<3, float> &) const --> bool", pybind11::arg("line"));
		cl.def("intersect", (bool (easy3d::GenericPlane<float>::*)(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &, class easy3d::Vec<3, float> &) const) &easy3d::GenericPlane<float>::intersect, "C++: easy3d::GenericPlane<float>::intersect(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &, class easy3d::Vec<3, float> &) const --> bool", pybind11::arg("s"), pybind11::arg("t"), pybind11::arg("p"));
		cl.def("intersect", (bool (easy3d::GenericPlane<float>::*)(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &) const) &easy3d::GenericPlane<float>::intersect, "C++: easy3d::GenericPlane<float>::intersect(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &) const --> bool", pybind11::arg("s"), pybind11::arg("t"));
		cl.def("intersect", (bool (easy3d::GenericPlane<float>::*)(const class easy3d::GenericPlane<float> &, class easy3d::GenericLine<3, float> &) const) &easy3d::GenericPlane<float>::intersect, "C++: easy3d::GenericPlane<float>::intersect(const class easy3d::GenericPlane<float> &, class easy3d::GenericLine<3, float> &) const --> bool", pybind11::arg("another"), pybind11::arg("line"));
		cl.def("intersect", (bool (easy3d::GenericPlane<float>::*)(const class easy3d::GenericPlane<float> &) const) &easy3d::GenericPlane<float>::intersect, "C++: easy3d::GenericPlane<float>::intersect(const class easy3d::GenericPlane<float> &) const --> bool", pybind11::arg("another"));
		cl.def("orient", (int (easy3d::GenericPlane<float>::*)(const class easy3d::Vec<3, float> &) const) &easy3d::GenericPlane<float>::orient, "C++: easy3d::GenericPlane<float>::orient(const class easy3d::Vec<3, float> &) const --> int", pybind11::arg("p"));
		cl.def("data", (float * (easy3d::GenericPlane<float>::*)()) &easy3d::GenericPlane<float>::data, "C++: easy3d::GenericPlane<float>::data() --> float *", pybind11::return_value_policy::automatic);
		cl.def("assign", (class easy3d::GenericPlane<float> & (easy3d::GenericPlane<float>::*)(const class easy3d::GenericPlane<float> &)) &easy3d::GenericPlane<float>::operator=, "C++: easy3d::GenericPlane<float>::operator=(const class easy3d::GenericPlane<float> &) --> class easy3d::GenericPlane<float> &", pybind11::return_value_policy::automatic, pybind11::arg(""));

		cl.def("__str__", [](easy3d::GenericPlane<float> const &o) -> std::string { std::ostringstream s; using namespace easy3d; s << o; return s.str(); } );
	}
	{ // easy3d::GenericBox file:easy3d/core/box.h line:47
		pybind11::class_<easy3d::GenericBox<3,float>, std::shared_ptr<easy3d::GenericBox<3,float>>> cl(M("easy3d"), "GenericBox_3_float_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::GenericBox<3,float>(); } ) );
		cl.def( pybind11::init<const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &>(), pybind11::arg("pmin"), pybind11::arg("pmax") );

		cl.def( pybind11::init<const class easy3d::Vec<3, float> &, float>(), pybind11::arg("c"), pybind11::arg("r") );

		cl.def( pybind11::init( [](easy3d::GenericBox<3,float> const &o){ return new easy3d::GenericBox<3,float>(o); } ) );
		cl.def("is_valid", (bool (easy3d::GenericBox<3,float>::*)() const) &easy3d::GenericBox<3, float>::is_valid, "C++: easy3d::GenericBox<3, float>::is_valid() const --> bool");
		cl.def("clear", (void (easy3d::GenericBox<3,float>::*)()) &easy3d::GenericBox<3, float>::clear, "C++: easy3d::GenericBox<3, float>::clear() --> void");
		cl.def("min_point", (class easy3d::Vec<3, float> & (easy3d::GenericBox<3,float>::*)()) &easy3d::GenericBox<3, float>::min_point, "C++: easy3d::GenericBox<3, float>::min_point() --> class easy3d::Vec<3, float> &", pybind11::return_value_policy::automatic);
		cl.def("max_point", (class easy3d::Vec<3, float> & (easy3d::GenericBox<3,float>::*)()) &easy3d::GenericBox<3, float>::max_point, "C++: easy3d::GenericBox<3, float>::max_point() --> class easy3d::Vec<3, float> &", pybind11::return_value_policy::automatic);
		cl.def("min_coord", (float (easy3d::GenericBox<3,float>::*)(unsigned int) const) &easy3d::GenericBox<3, float>::min_coord, "C++: easy3d::GenericBox<3, float>::min_coord(unsigned int) const --> float", pybind11::arg("axis"));
		cl.def("max_coord", (float (easy3d::GenericBox<3,float>::*)(unsigned int) const) &easy3d::GenericBox<3, float>::max_coord, "C++: easy3d::GenericBox<3, float>::max_coord(unsigned int) const --> float", pybind11::arg("axis"));
		cl.def("range", (float (easy3d::GenericBox<3,float>::*)(unsigned int) const) &easy3d::GenericBox<3, float>::range, "C++: easy3d::GenericBox<3, float>::range(unsigned int) const --> float", pybind11::arg("axis"));
		cl.def("max_range", (float (easy3d::GenericBox<3,float>::*)() const) &easy3d::GenericBox<3, float>::max_range, "C++: easy3d::GenericBox<3, float>::max_range() const --> float");
		cl.def("min_range", (float (easy3d::GenericBox<3,float>::*)() const) &easy3d::GenericBox<3, float>::min_range, "C++: easy3d::GenericBox<3, float>::min_range() const --> float");
		cl.def("max_range_axis", (unsigned int (easy3d::GenericBox<3,float>::*)() const) &easy3d::GenericBox<3, float>::max_range_axis, "C++: easy3d::GenericBox<3, float>::max_range_axis() const --> unsigned int");
		cl.def("min_range_axis", (unsigned int (easy3d::GenericBox<3,float>::*)() const) &easy3d::GenericBox<3, float>::min_range_axis, "C++: easy3d::GenericBox<3, float>::min_range_axis() const --> unsigned int");
		cl.def("center", (class easy3d::Vec<3, float> (easy3d::GenericBox<3,float>::*)() const) &easy3d::GenericBox<3, float>::center, "C++: easy3d::GenericBox<3, float>::center() const --> class easy3d::Vec<3, float>");
		cl.def("diagonal_vector", (class easy3d::Vec<3, float> (easy3d::GenericBox<3,float>::*)() const) &easy3d::GenericBox<3, float>::diagonal_vector, "C++: easy3d::GenericBox<3, float>::diagonal_vector() const --> class easy3d::Vec<3, float>");
		cl.def("diagonal_length", (float (easy3d::GenericBox<3,float>::*)() const) &easy3d::GenericBox<3, float>::diagonal_length, "C++: easy3d::GenericBox<3, float>::diagonal_length() const --> float");
		cl.def("radius", (float (easy3d::GenericBox<3,float>::*)() const) &easy3d::GenericBox<3, float>::radius, "C++: easy3d::GenericBox<3, float>::radius() const --> float");
		cl.def("surface_area", (float (easy3d::GenericBox<3,float>::*)() const) &easy3d::GenericBox<3, float>::surface_area, "C++: easy3d::GenericBox<3, float>::surface_area() const --> float");
		cl.def("grow", (void (easy3d::GenericBox<3,float>::*)(const class easy3d::Vec<3, float> &)) &easy3d::GenericBox<3, float>::grow, "C++: easy3d::GenericBox<3, float>::grow(const class easy3d::Vec<3, float> &) --> void", pybind11::arg("p"));
		cl.def("grow", (void (easy3d::GenericBox<3,float>::*)(const class easy3d::GenericBox<3, float> &)) &easy3d::GenericBox<3, float>::grow, "C++: easy3d::GenericBox<3, float>::grow(const class easy3d::GenericBox<3, float> &) --> void", pybind11::arg("b"));
		cl.def("__add__", (class easy3d::GenericBox<3, float> (easy3d::GenericBox<3,float>::*)(const class easy3d::GenericBox<3, float> &) const) &easy3d::GenericBox<3, float>::operator+, "C++: easy3d::GenericBox<3, float>::operator+(const class easy3d::GenericBox<3, float> &) const --> class easy3d::GenericBox<3, float>", pybind11::arg("b"));
		cl.def("__iadd__", (class easy3d::GenericBox<3, float> & (easy3d::GenericBox<3,float>::*)(const class easy3d::GenericBox<3, float> &)) &easy3d::GenericBox<3, float>::operator+=, "C++: easy3d::GenericBox<3, float>::operator+=(const class easy3d::GenericBox<3, float> &) --> class easy3d::GenericBox<3, float> &", pybind11::return_value_policy::automatic, pybind11::arg("b"));
		cl.def("contains", (bool (easy3d::GenericBox<3,float>::*)(const class easy3d::Vec<3, float> &) const) &easy3d::GenericBox<3, float>::contains, "C++: easy3d::GenericBox<3, float>::contains(const class easy3d::Vec<3, float> &) const --> bool", pybind11::arg("p"));
		cl.def("contains", (bool (easy3d::GenericBox<3,float>::*)(const class easy3d::GenericBox<3, float> &) const) &easy3d::GenericBox<3, float>::contains, "C++: easy3d::GenericBox<3, float>::contains(const class easy3d::GenericBox<3, float> &) const --> bool", pybind11::arg("b"));
		cl.def("intersects", (bool (easy3d::GenericBox<3,float>::*)(const class easy3d::GenericBox<3, float> &) const) &easy3d::GenericBox<3, float>::intersects, "C++: easy3d::GenericBox<3, float>::intersects(const class easy3d::GenericBox<3, float> &) const --> bool", pybind11::arg("b"));
		cl.def("assign", (class easy3d::GenericBox<3, float> & (easy3d::GenericBox<3,float>::*)(const class easy3d::GenericBox<3, float> &)) &easy3d::GenericBox<3, float>::operator=, "C++: easy3d::GenericBox<3, float>::operator=(const class easy3d::GenericBox<3, float> &) --> class easy3d::GenericBox<3, float> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
}
