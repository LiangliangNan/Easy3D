#include <easy3d/core/types.h>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_core_types_2(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	// easy3d::color::encode(int, int, int) file:easy3d/core/types.h line:311
	M("easy3d::color").def("encode", (int (*)(int, int, int)) &easy3d::color::encode, "Encodes an RGB (each component in the range [0, 255]) color in an integer value.\n\nC++: easy3d::color::encode(int, int, int) --> int", pybind11::arg("r"), pybind11::arg("g"), pybind11::arg("b"));

	// easy3d::color::encode(int, int, int, int) file:easy3d/core/types.h line:316
	M("easy3d::color").def("encode", (int (*)(int, int, int, int)) &easy3d::color::encode, "Encodes an RGBA (each component in the range [0, 255]) color in an integer value.\n\nC++: easy3d::color::encode(int, int, int, int) --> int", pybind11::arg("r"), pybind11::arg("g"), pybind11::arg("b"), pybind11::arg("a"));

	// easy3d::color::decode(int, int &, int &, int &) file:easy3d/core/types.h line:323
	M("easy3d::color").def("decode", (void (*)(int, int &, int &, int &)) &easy3d::color::decode, "Decodes an integer value as RGB color (each component in the range [0, 255]).\n\nC++: easy3d::color::decode(int, int &, int &, int &) --> void", pybind11::arg("value"), pybind11::arg("r"), pybind11::arg("g"), pybind11::arg("b"));

	// easy3d::color::decode(int, int &, int &, int &, int &) file:easy3d/core/types.h line:330
	M("easy3d::color").def("decode", (void (*)(int, int &, int &, int &, int &)) &easy3d::color::decode, "Decodes an integer value as RGBA color (each component in the range [0, 255]).\n\nC++: easy3d::color::decode(int, int &, int &, int &, int &) --> void", pybind11::arg("value"), pybind11::arg("r"), pybind11::arg("g"), pybind11::arg("b"), pybind11::arg("a"));

	// easy3d::color::red(int) file:easy3d/core/types.h line:341
	M("easy3d::color").def("red", (int (*)(int)) &easy3d::color::red, "Gets the red component of RGB. [0, 255]\n\nC++: easy3d::color::red(int) --> int", pybind11::arg("color"));

	// easy3d::color::green(int) file:easy3d/core/types.h line:344
	M("easy3d::color").def("green", (int (*)(int)) &easy3d::color::green, "Gets the green component of RGB. [0, 255]\n\nC++: easy3d::color::green(int) --> int", pybind11::arg("color"));

	// easy3d::color::blue(int) file:easy3d/core/types.h line:347
	M("easy3d::color").def("blue", (int (*)(int)) &easy3d::color::blue, "Gets the blue component of RGB. [0, 255]\n\nC++: easy3d::color::blue(int) --> int", pybind11::arg("color"));

	// easy3d::color::alpha(int) file:easy3d/core/types.h line:350
	M("easy3d::color").def("alpha", (int (*)(int)) &easy3d::color::alpha, "Gets the alpha component of RGBA. [0, 255]\n\nC++: easy3d::color::alpha(int) --> int", pybind11::arg("color"));

}
