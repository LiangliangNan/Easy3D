#include <easy3d/core/vec.h>
#include <sstream> // __str__

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_core_vec(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	{ // easy3d::Vec file:easy3d/core/vec.h line:319
		pybind11::class_<easy3d::Vec<2UL,float>, std::shared_ptr<easy3d::Vec<2UL,float>>> cl(M("easy3d"), "Vec_2UL_float_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Vec<2UL,float>(); } ) );
		cl.def( pybind11::init<float, float>(), pybind11::arg("x_in"), pybind11::arg("y_in") );

		cl.def( pybind11::init<const class easy3d::Vec<3, float> &>(), pybind11::arg("v") );

		cl.def( pybind11::init<const float &>(), pybind11::arg("s") );

		cl.def( pybind11::init( [](easy3d::Vec<2UL,float> const &o){ return new easy3d::Vec<2UL,float>(o); } ) );
		cl.def("length2", (float (easy3d::Vec<2UL,float>::*)() const) &easy3d::Vec<2, float>::length2, "C++: easy3d::Vec<2, float>::length2() const --> float");
		cl.def("length", (float (easy3d::Vec<2UL,float>::*)() const) &easy3d::Vec<2, float>::length, "C++: easy3d::Vec<2, float>::length() const --> float");
		cl.def("norm", (float (easy3d::Vec<2UL,float>::*)() const) &easy3d::Vec<2, float>::norm, "C++: easy3d::Vec<2, float>::norm() const --> float");
		cl.def("distance2", (float (easy3d::Vec<2UL,float>::*)(const class easy3d::Vec<2, float> &) const) &easy3d::Vec<2, float>::distance2, "C++: easy3d::Vec<2, float>::distance2(const class easy3d::Vec<2, float> &) const --> float", pybind11::arg("rhs"));
		cl.def("normalize", (class easy3d::Vec<2, float> & (easy3d::Vec<2UL,float>::*)()) &easy3d::Vec<2, float>::normalize, "C++: easy3d::Vec<2, float>::normalize() --> class easy3d::Vec<2, float> &", pybind11::return_value_policy::automatic);
		cl.def("__iadd__", (class easy3d::Vec<2, float> & (easy3d::Vec<2UL,float>::*)(const class easy3d::Vec<2, float> &)) &easy3d::Vec<2, float>::operator+=, "C++: easy3d::Vec<2, float>::operator+=(const class easy3d::Vec<2, float> &) --> class easy3d::Vec<2, float> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__isub__", (class easy3d::Vec<2, float> & (easy3d::Vec<2UL,float>::*)(const class easy3d::Vec<2, float> &)) &easy3d::Vec<2, float>::operator-=, "C++: easy3d::Vec<2, float>::operator-=(const class easy3d::Vec<2, float> &) --> class easy3d::Vec<2, float> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__imul__", (class easy3d::Vec<2, float> & (easy3d::Vec<2UL,float>::*)(const class easy3d::Vec<2, float> &)) &easy3d::Vec<2, float>::operator*=, "C++: easy3d::Vec<2, float>::operator*=(const class easy3d::Vec<2, float> &) --> class easy3d::Vec<2, float> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__itruediv__", (class easy3d::Vec<2, float> & (easy3d::Vec<2UL,float>::*)(const class easy3d::Vec<2, float> &)) &easy3d::Vec<2, float>::operator/=, "C++: easy3d::Vec<2, float>::operator/=(const class easy3d::Vec<2, float> &) --> class easy3d::Vec<2, float> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__add__", (class easy3d::Vec<2, float> (easy3d::Vec<2UL,float>::*)(const class easy3d::Vec<2, float> &) const) &easy3d::Vec<2, float>::operator+, "C++: easy3d::Vec<2, float>::operator+(const class easy3d::Vec<2, float> &) const --> class easy3d::Vec<2, float>", pybind11::arg("v"));
		cl.def("__sub__", (class easy3d::Vec<2, float> (easy3d::Vec<2UL,float>::*)(const class easy3d::Vec<2, float> &) const) &easy3d::Vec<2, float>::operator-, "C++: easy3d::Vec<2, float>::operator-(const class easy3d::Vec<2, float> &) const --> class easy3d::Vec<2, float>", pybind11::arg("v"));
		cl.def("__neg__", (class easy3d::Vec<2, float> (easy3d::Vec<2UL,float>::*)() const) &easy3d::Vec<2, float>::operator-, "C++: easy3d::Vec<2, float>::operator-() const --> class easy3d::Vec<2, float>");
		cl.def("dimension", (unsigned long (easy3d::Vec<2UL,float>::*)() const) &easy3d::Vec<2, float>::dimension, "C++: easy3d::Vec<2, float>::dimension() const --> unsigned long");
		cl.def("size", (unsigned long (easy3d::Vec<2UL,float>::*)() const) &easy3d::Vec<2, float>::size, "C++: easy3d::Vec<2, float>::size() const --> unsigned long");
		cl.def("data", (float * (easy3d::Vec<2UL,float>::*)()) &easy3d::Vec<2, float>::data, "C++: easy3d::Vec<2, float>::data() --> float *", pybind11::return_value_policy::automatic);

		{ // easy3d::Vec<2, float>::(anonymous union at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:393:9) file:easy3d/core/vec.h line:393

			{ // easy3d::Vec<2, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:395:13) file:easy3d/core/vec.h line:395
				cl.def_readwrite("x", &easy3d::Vec<2, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:395:13)::x);
				cl.def_readwrite("y", &easy3d::Vec<2, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:395:13)::y);
			}

			{ // easy3d::Vec<2, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:396:13) file:easy3d/core/vec.h line:396
				cl.def_readwrite("u", &easy3d::Vec<2, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:396:13)::u);
				cl.def_readwrite("v", &easy3d::Vec<2, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:396:13)::v);
			}

		}

	}
	{ // easy3d::Vec file:easy3d/core/vec.h line:438
		pybind11::class_<easy3d::Vec<3UL,float>, std::shared_ptr<easy3d::Vec<3UL,float>>> cl(M("easy3d"), "Vec_3UL_float_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Vec<3UL,float>(); } ) );
		cl.def( pybind11::init( [](const class easy3d::Vec<2, float> & a0){ return new easy3d::Vec<3UL,float>(a0); } ), "doc" , pybind11::arg("v"));
		cl.def( pybind11::init<const class easy3d::Vec<2, float> &, const float &>(), pybind11::arg("v"), pybind11::arg("s") );

		cl.def( pybind11::init<const class easy3d::Vec<4, float> &>(), pybind11::arg("v") );

		cl.def( pybind11::init<float, float, float>(), pybind11::arg("x_in"), pybind11::arg("y_in"), pybind11::arg("z_in") );

		cl.def( pybind11::init<const float &>(), pybind11::arg("s") );

		cl.def( pybind11::init( [](easy3d::Vec<3UL,float> const &o){ return new easy3d::Vec<3UL,float>(o); } ) );
		cl.def("__imul__", (class easy3d::Vec<3, float> & (easy3d::Vec<3UL,float>::*)(float)) &easy3d::Vec<3, float>::operator*=<float>, "C++: easy3d::Vec<3, float>::operator*=(float) --> class easy3d::Vec<3, float> &", pybind11::return_value_policy::automatic, pybind11::arg("s"));
		cl.def("__mul__", (class easy3d::Vec<3, float> (easy3d::Vec<3UL,float>::*)(float) const) &easy3d::Vec<3, float>::operator*<float>, "C++: easy3d::Vec<3, float>::operator*(float) const --> class easy3d::Vec<3, float>", pybind11::arg("s"));
		cl.def("__truediv__", (class easy3d::Vec<3, float> (easy3d::Vec<3UL,float>::*)(float) const) &easy3d::Vec<3, float>::operator/<float>, "C++: easy3d::Vec<3, float>::operator/(float) const --> class easy3d::Vec<3, float>", pybind11::arg("s"));
		cl.def("length2", (float (easy3d::Vec<3UL,float>::*)() const) &easy3d::Vec<3, float>::length2, "C++: easy3d::Vec<3, float>::length2() const --> float");
		cl.def("length", (float (easy3d::Vec<3UL,float>::*)() const) &easy3d::Vec<3, float>::length, "C++: easy3d::Vec<3, float>::length() const --> float");
		cl.def("norm", (float (easy3d::Vec<3UL,float>::*)() const) &easy3d::Vec<3, float>::norm, "C++: easy3d::Vec<3, float>::norm() const --> float");
		cl.def("distance2", (float (easy3d::Vec<3UL,float>::*)(const class easy3d::Vec<3, float> &) const) &easy3d::Vec<3, float>::distance2, "C++: easy3d::Vec<3, float>::distance2(const class easy3d::Vec<3, float> &) const --> float", pybind11::arg("rhs"));
		cl.def("normalize", (class easy3d::Vec<3, float> & (easy3d::Vec<3UL,float>::*)()) &easy3d::Vec<3, float>::normalize, "C++: easy3d::Vec<3, float>::normalize() --> class easy3d::Vec<3, float> &", pybind11::return_value_policy::automatic);
		cl.def("__iadd__", (class easy3d::Vec<3, float> & (easy3d::Vec<3UL,float>::*)(const class easy3d::Vec<3, float> &)) &easy3d::Vec<3, float>::operator+=, "C++: easy3d::Vec<3, float>::operator+=(const class easy3d::Vec<3, float> &) --> class easy3d::Vec<3, float> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__isub__", (class easy3d::Vec<3, float> & (easy3d::Vec<3UL,float>::*)(const class easy3d::Vec<3, float> &)) &easy3d::Vec<3, float>::operator-=, "C++: easy3d::Vec<3, float>::operator-=(const class easy3d::Vec<3, float> &) --> class easy3d::Vec<3, float> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__imul__", (class easy3d::Vec<3, float> & (easy3d::Vec<3UL,float>::*)(const class easy3d::Vec<3, float> &)) &easy3d::Vec<3, float>::operator*=, "C++: easy3d::Vec<3, float>::operator*=(const class easy3d::Vec<3, float> &) --> class easy3d::Vec<3, float> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__itruediv__", (class easy3d::Vec<3, float> & (easy3d::Vec<3UL,float>::*)(const class easy3d::Vec<3, float> &)) &easy3d::Vec<3, float>::operator/=, "C++: easy3d::Vec<3, float>::operator/=(const class easy3d::Vec<3, float> &) --> class easy3d::Vec<3, float> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__add__", (class easy3d::Vec<3, float> (easy3d::Vec<3UL,float>::*)(const class easy3d::Vec<3, float> &) const) &easy3d::Vec<3, float>::operator+, "C++: easy3d::Vec<3, float>::operator+(const class easy3d::Vec<3, float> &) const --> class easy3d::Vec<3, float>", pybind11::arg("v"));
		cl.def("__sub__", (class easy3d::Vec<3, float> (easy3d::Vec<3UL,float>::*)(const class easy3d::Vec<3, float> &) const) &easy3d::Vec<3, float>::operator-, "C++: easy3d::Vec<3, float>::operator-(const class easy3d::Vec<3, float> &) const --> class easy3d::Vec<3, float>", pybind11::arg("v"));
		cl.def("__neg__", (class easy3d::Vec<3, float> (easy3d::Vec<3UL,float>::*)() const) &easy3d::Vec<3, float>::operator-, "C++: easy3d::Vec<3, float>::operator-() const --> class easy3d::Vec<3, float>");
		cl.def("dimension", (unsigned long (easy3d::Vec<3UL,float>::*)() const) &easy3d::Vec<3, float>::dimension, "C++: easy3d::Vec<3, float>::dimension() const --> unsigned long");
		cl.def("size", (unsigned long (easy3d::Vec<3UL,float>::*)() const) &easy3d::Vec<3, float>::size, "C++: easy3d::Vec<3, float>::size() const --> unsigned long");
		cl.def("data", (float * (easy3d::Vec<3UL,float>::*)()) &easy3d::Vec<3, float>::data, "C++: easy3d::Vec<3, float>::data() --> float *", pybind11::return_value_policy::automatic);
		cl.def("xy", (class easy3d::Vec<2, float> (easy3d::Vec<3UL,float>::*)() const) &easy3d::Vec<3, float>::xy, "C++: easy3d::Vec<3, float>::xy() const --> class easy3d::Vec<2, float>");
		cl.def("assign", (class easy3d::Vec<3, float> & (easy3d::Vec<3UL,float>::*)(const class easy3d::Vec<3, float> &)) &easy3d::Vec<3, float>::operator=, "C++: easy3d::Vec<3, float>::operator=(const class easy3d::Vec<3, float> &) --> class easy3d::Vec<3, float> &", pybind11::return_value_policy::automatic, pybind11::arg(""));

		{ // easy3d::Vec<3, float>::(anonymous union at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:520:9) file:easy3d/core/vec.h line:520

			{ // easy3d::Vec<3, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:522:13) file:easy3d/core/vec.h line:522
				cl.def_readwrite("x", &easy3d::Vec<3, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:522:13)::x);
				cl.def_readwrite("y", &easy3d::Vec<3, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:522:13)::y);
				cl.def_readwrite("z", &easy3d::Vec<3, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:522:13)::z);
			}

			{ // easy3d::Vec<3, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:523:13) file:easy3d/core/vec.h line:523
				cl.def_readwrite("r", &easy3d::Vec<3, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:523:13)::r);
				cl.def_readwrite("g", &easy3d::Vec<3, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:523:13)::g);
				cl.def_readwrite("b", &easy3d::Vec<3, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:523:13)::b);
			}

		}

	}
	{ // easy3d::Vec file:easy3d/core/vec.h line:583
		pybind11::class_<easy3d::Vec<4UL,float>, std::shared_ptr<easy3d::Vec<4UL,float>>> cl(M("easy3d"), "Vec_4UL_float_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Vec<4UL,float>(); } ) );
		cl.def( pybind11::init( [](const class easy3d::Vec<3, float> & a0){ return new easy3d::Vec<4UL,float>(a0); } ), "doc" , pybind11::arg("v"));
		cl.def( pybind11::init<const class easy3d::Vec<3, float> &, const float &>(), pybind11::arg("v"), pybind11::arg("s") );

		cl.def( pybind11::init<float, float, float, float>(), pybind11::arg("x_in"), pybind11::arg("y_in"), pybind11::arg("z_in"), pybind11::arg("w_in") );

		cl.def( pybind11::init<const float &>(), pybind11::arg("s") );

		cl.def( pybind11::init( [](easy3d::Vec<4UL,float> const &o){ return new easy3d::Vec<4UL,float>(o); } ) );
		cl.def("length2", (float (easy3d::Vec<4UL,float>::*)() const) &easy3d::Vec<4, float>::length2, "C++: easy3d::Vec<4, float>::length2() const --> float");
		cl.def("length", (float (easy3d::Vec<4UL,float>::*)() const) &easy3d::Vec<4, float>::length, "C++: easy3d::Vec<4, float>::length() const --> float");
		cl.def("norm", (float (easy3d::Vec<4UL,float>::*)() const) &easy3d::Vec<4, float>::norm, "C++: easy3d::Vec<4, float>::norm() const --> float");
		cl.def("distance2", (float (easy3d::Vec<4UL,float>::*)(const class easy3d::Vec<4, float> &) const) &easy3d::Vec<4, float>::distance2, "C++: easy3d::Vec<4, float>::distance2(const class easy3d::Vec<4, float> &) const --> float", pybind11::arg("rhs"));
		cl.def("normalize", (class easy3d::Vec<4, float> & (easy3d::Vec<4UL,float>::*)()) &easy3d::Vec<4, float>::normalize, "C++: easy3d::Vec<4, float>::normalize() --> class easy3d::Vec<4, float> &", pybind11::return_value_policy::automatic);
		cl.def("dimension", (unsigned long (easy3d::Vec<4UL,float>::*)() const) &easy3d::Vec<4, float>::dimension, "C++: easy3d::Vec<4, float>::dimension() const --> unsigned long");
		cl.def("size", (unsigned long (easy3d::Vec<4UL,float>::*)() const) &easy3d::Vec<4, float>::size, "C++: easy3d::Vec<4, float>::size() const --> unsigned long");
		cl.def("__iadd__", (class easy3d::Vec<4, float> & (easy3d::Vec<4UL,float>::*)(const class easy3d::Vec<4, float> &)) &easy3d::Vec<4, float>::operator+=, "C++: easy3d::Vec<4, float>::operator+=(const class easy3d::Vec<4, float> &) --> class easy3d::Vec<4, float> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__isub__", (class easy3d::Vec<4, float> & (easy3d::Vec<4UL,float>::*)(const class easy3d::Vec<4, float> &)) &easy3d::Vec<4, float>::operator-=, "C++: easy3d::Vec<4, float>::operator-=(const class easy3d::Vec<4, float> &) --> class easy3d::Vec<4, float> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__imul__", (class easy3d::Vec<4, float> & (easy3d::Vec<4UL,float>::*)(const class easy3d::Vec<4, float> &)) &easy3d::Vec<4, float>::operator*=, "C++: easy3d::Vec<4, float>::operator*=(const class easy3d::Vec<4, float> &) --> class easy3d::Vec<4, float> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__itruediv__", (class easy3d::Vec<4, float> & (easy3d::Vec<4UL,float>::*)(const class easy3d::Vec<4, float> &)) &easy3d::Vec<4, float>::operator/=, "C++: easy3d::Vec<4, float>::operator/=(const class easy3d::Vec<4, float> &) --> class easy3d::Vec<4, float> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__add__", (class easy3d::Vec<4, float> (easy3d::Vec<4UL,float>::*)(const class easy3d::Vec<4, float> &) const) &easy3d::Vec<4, float>::operator+, "C++: easy3d::Vec<4, float>::operator+(const class easy3d::Vec<4, float> &) const --> class easy3d::Vec<4, float>", pybind11::arg("v"));
		cl.def("__sub__", (class easy3d::Vec<4, float> (easy3d::Vec<4UL,float>::*)(const class easy3d::Vec<4, float> &) const) &easy3d::Vec<4, float>::operator-, "C++: easy3d::Vec<4, float>::operator-(const class easy3d::Vec<4, float> &) const --> class easy3d::Vec<4, float>", pybind11::arg("v"));
		cl.def("__neg__", (class easy3d::Vec<4, float> (easy3d::Vec<4UL,float>::*)() const) &easy3d::Vec<4, float>::operator-, "C++: easy3d::Vec<4, float>::operator-() const --> class easy3d::Vec<4, float>");
		cl.def("data", (float * (easy3d::Vec<4UL,float>::*)()) &easy3d::Vec<4, float>::data, "C++: easy3d::Vec<4, float>::data() --> float *", pybind11::return_value_policy::automatic);
		cl.def("xyz", (class easy3d::Vec<3, float> (easy3d::Vec<4UL,float>::*)() const) &easy3d::Vec<4, float>::xyz, "C++: easy3d::Vec<4, float>::xyz() const --> class easy3d::Vec<3, float>");
		cl.def("assign", (class easy3d::Vec<4, float> & (easy3d::Vec<4UL,float>::*)(const class easy3d::Vec<4, float> &)) &easy3d::Vec<4, float>::operator=, "C++: easy3d::Vec<4, float>::operator=(const class easy3d::Vec<4, float> &) --> class easy3d::Vec<4, float> &", pybind11::return_value_policy::automatic, pybind11::arg(""));

		{ // easy3d::Vec<4, float>::(anonymous union at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:663:9) file:easy3d/core/vec.h line:663

			{ // easy3d::Vec<4, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:665:13) file:easy3d/core/vec.h line:665
				cl.def_readwrite("x", &easy3d::Vec<4, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:665:13)::x);
				cl.def_readwrite("y", &easy3d::Vec<4, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:665:13)::y);
				cl.def_readwrite("z", &easy3d::Vec<4, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:665:13)::z);
				cl.def_readwrite("w", &easy3d::Vec<4, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:665:13)::w);
			}

			{ // easy3d::Vec<4, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:666:13) file:easy3d/core/vec.h line:666
				cl.def_readwrite("r", &easy3d::Vec<4, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:666:13)::r);
				cl.def_readwrite("g", &easy3d::Vec<4, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:666:13)::g);
				cl.def_readwrite("b", &easy3d::Vec<4, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:666:13)::b);
				cl.def_readwrite("a", &easy3d::Vec<4, float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:666:13)::a);
			}

		}

	}
}
