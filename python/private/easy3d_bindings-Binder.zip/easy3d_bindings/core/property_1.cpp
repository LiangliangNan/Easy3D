#include <easy3d/core/property.h>
#include <easy3d/core/surface_mesh.h>
#include <easy3d/core/vec.h>
#include <memory>
#include <sstream> // __str__
#include <string>
#include <string_view>
#include <typeinfo>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

// easy3d::PropertyArray file:easy3d/core/property.h line:111
struct PyCallBack_easy3d_PropertyArray_easy3d_SurfaceMesh_FaceConnectivity_t : public easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity> {
	using easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::PropertyArray;

	void reserve(unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity> *>(this), "reserve");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::reserve(a0);
	}
	void resize(unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity> *>(this), "resize");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::resize(a0);
	}
	void push_back() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity> *>(this), "push_back");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::push_back();
	}
	void reset(unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity> *>(this), "reset");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::reset(a0);
	}
	bool transfer(const class easy3d::BasePropertyArray & a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity> *>(this), "transfer");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return PropertyArray::transfer(a0);
	}
	bool transfer(const class easy3d::BasePropertyArray & a0, std::size_t a1, std::size_t a2) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity> *>(this), "transfer");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return PropertyArray::transfer(a0, a1, a2);
	}
	void shrink_to_fit() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity> *>(this), "shrink_to_fit");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::shrink_to_fit();
	}
	void swap(unsigned long a0, unsigned long a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity> *>(this), "swap");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::swap(a0, a1);
	}
	void copy(unsigned long a0, unsigned long a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity> *>(this), "copy");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::copy(a0, a1);
	}
	class easy3d::BasePropertyArray * clone() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity> *>(this), "clone");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<class easy3d::BasePropertyArray *>::value) {
				static pybind11::detail::override_caster_t<class easy3d::BasePropertyArray *> caster;
				return pybind11::detail::cast_ref<class easy3d::BasePropertyArray *>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<class easy3d::BasePropertyArray *>(std::move(o));
		}
		return PropertyArray::clone();
	}
	class easy3d::BasePropertyArray * empty_clone() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity> *>(this), "empty_clone");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<class easy3d::BasePropertyArray *>::value) {
				static pybind11::detail::override_caster_t<class easy3d::BasePropertyArray *> caster;
				return pybind11::detail::cast_ref<class easy3d::BasePropertyArray *>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<class easy3d::BasePropertyArray *>(std::move(o));
		}
		return PropertyArray::empty_clone();
	}
	const class std::type_info & type() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity> *>(this), "type");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<const class std::type_info &>::value) {
				static pybind11::detail::override_caster_t<const class std::type_info &> caster;
				return pybind11::detail::cast_ref<const class std::type_info &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<const class std::type_info &>(std::move(o));
		}
		return PropertyArray::type();
	}
};

// easy3d::PropertyArray file:easy3d/core/property.h line:111
struct PyCallBack_easy3d_PropertyArray_easy3d_Vec_3_float_t : public easy3d::PropertyArray<easy3d::Vec<3, float>> {
	using easy3d::PropertyArray<easy3d::Vec<3, float>>::PropertyArray;

	void reserve(unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Vec<3, float>> *>(this), "reserve");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::reserve(a0);
	}
	void resize(unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Vec<3, float>> *>(this), "resize");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::resize(a0);
	}
	void push_back() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Vec<3, float>> *>(this), "push_back");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::push_back();
	}
	void reset(unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Vec<3, float>> *>(this), "reset");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::reset(a0);
	}
	bool transfer(const class easy3d::BasePropertyArray & a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Vec<3, float>> *>(this), "transfer");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return PropertyArray::transfer(a0);
	}
	bool transfer(const class easy3d::BasePropertyArray & a0, std::size_t a1, std::size_t a2) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Vec<3, float>> *>(this), "transfer");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return PropertyArray::transfer(a0, a1, a2);
	}
	void shrink_to_fit() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Vec<3, float>> *>(this), "shrink_to_fit");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::shrink_to_fit();
	}
	void swap(unsigned long a0, unsigned long a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Vec<3, float>> *>(this), "swap");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::swap(a0, a1);
	}
	void copy(unsigned long a0, unsigned long a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Vec<3, float>> *>(this), "copy");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::copy(a0, a1);
	}
	class easy3d::BasePropertyArray * clone() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Vec<3, float>> *>(this), "clone");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<class easy3d::BasePropertyArray *>::value) {
				static pybind11::detail::override_caster_t<class easy3d::BasePropertyArray *> caster;
				return pybind11::detail::cast_ref<class easy3d::BasePropertyArray *>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<class easy3d::BasePropertyArray *>(std::move(o));
		}
		return PropertyArray::clone();
	}
	class easy3d::BasePropertyArray * empty_clone() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Vec<3, float>> *>(this), "empty_clone");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<class easy3d::BasePropertyArray *>::value) {
				static pybind11::detail::override_caster_t<class easy3d::BasePropertyArray *> caster;
				return pybind11::detail::cast_ref<class easy3d::BasePropertyArray *>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<class easy3d::BasePropertyArray *>(std::move(o));
		}
		return PropertyArray::empty_clone();
	}
	const class std::type_info & type() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::Vec<3, float>> *>(this), "type");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<const class std::type_info &>::value) {
				static pybind11::detail::override_caster_t<const class std::type_info &> caster;
				return pybind11::detail::cast_ref<const class std::type_info &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<const class std::type_info &>(std::move(o));
		}
		return PropertyArray::type();
	}
};

void bind_easy3d_core_property_1(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	{ // easy3d::PropertyArray file:easy3d/core/property.h line:111
		pybind11::class_<easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>, std::shared_ptr<easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>>, PyCallBack_easy3d_PropertyArray_easy3d_SurfaceMesh_FaceConnectivity_t, easy3d::BasePropertyArray> cl(M("easy3d"), "PropertyArray_easy3d_SurfaceMesh_FaceConnectivity_t", "");
		cl.def( pybind11::init( [](const std::string & a0){ return new easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>(a0); }, [](const std::string & a0){ return new PyCallBack_easy3d_PropertyArray_easy3d_SurfaceMesh_FaceConnectivity_t(a0); } ), "doc");
		cl.def( pybind11::init<const std::string &, struct easy3d::SurfaceMesh::FaceConnectivity>(), pybind11::arg("name"), pybind11::arg("t") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_PropertyArray_easy3d_SurfaceMesh_FaceConnectivity_t const &o){ return new PyCallBack_easy3d_PropertyArray_easy3d_SurfaceMesh_FaceConnectivity_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity> const &o){ return new easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>(o); } ) );
		cl.def("reserve", (void (easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::reserve, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::reserve(unsigned long) --> void", pybind11::arg("n"));
		cl.def("resize", (void (easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::resize, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::resize(unsigned long) --> void", pybind11::arg("n"));
		cl.def("push_back", (void (easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::*)()) &easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::push_back, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::push_back() --> void");
		cl.def("reset", (void (easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::reset, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::reset(unsigned long) --> void", pybind11::arg("idx"));
		cl.def("transfer", (bool (easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::*)(const class easy3d::BasePropertyArray &)) &easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::transfer, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::transfer(const class easy3d::BasePropertyArray &) --> bool", pybind11::arg("other"));
		cl.def("transfer", (bool (easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::*)(const class easy3d::BasePropertyArray &, std::size_t, std::size_t)) &easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::transfer, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::transfer(const class easy3d::BasePropertyArray &, std::size_t, std::size_t) --> bool", pybind11::arg("other"), pybind11::arg("from"), pybind11::arg("to"));
		cl.def("shrink_to_fit", (void (easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::*)()) &easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::shrink_to_fit, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::shrink_to_fit() --> void");
		cl.def("swap", (void (easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::*)(unsigned long, unsigned long)) &easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::swap, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::swap(unsigned long, unsigned long) --> void", pybind11::arg("i0"), pybind11::arg("i1"));
		cl.def("copy", (void (easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::*)(unsigned long, unsigned long)) &easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::copy, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::copy(unsigned long, unsigned long) --> void", pybind11::arg("from"), pybind11::arg("to"));
		cl.def("clone", (class easy3d::BasePropertyArray * (easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::*)() const) &easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::clone, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("empty_clone", (class easy3d::BasePropertyArray * (easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::*)() const) &easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::empty_clone, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::empty_clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("type", (const class std::type_info & (easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::*)() const) &easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::type, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::type() const --> const class std::type_info &", pybind11::return_value_policy::automatic);
		cl.def("data", (const struct easy3d::SurfaceMesh::FaceConnectivity * (easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::*)() const) &easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::data, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::data() const --> const struct easy3d::SurfaceMesh::FaceConnectivity *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<struct easy3d::SurfaceMesh::FaceConnectivity> & (easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::*)()) &easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::vector, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::vector() --> class std::vector<struct easy3d::SurfaceMesh::FaceConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("__getitem__", (struct easy3d::SurfaceMesh::FaceConnectivity & (easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::operator[], "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::operator[](unsigned long) --> struct easy3d::SurfaceMesh::FaceConnectivity &", pybind11::return_value_policy::automatic, pybind11::arg("_idx"));
		cl.def("assign", (class easy3d::PropertyArray<struct easy3d::SurfaceMesh::FaceConnectivity> & (easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::*)(const class easy3d::PropertyArray<struct easy3d::SurfaceMesh::FaceConnectivity> &)) &easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::operator=, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::FaceConnectivity>::operator=(const class easy3d::PropertyArray<struct easy3d::SurfaceMesh::FaceConnectivity> &) --> class easy3d::PropertyArray<struct easy3d::SurfaceMesh::FaceConnectivity> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
		cl.def("reserve", (void (easy3d::BasePropertyArray::*)(unsigned long)) &easy3d::BasePropertyArray::reserve, "Reserve memory for n elements.\n\nC++: easy3d::BasePropertyArray::reserve(unsigned long) --> void", pybind11::arg("n"));
		cl.def("resize", (void (easy3d::BasePropertyArray::*)(unsigned long)) &easy3d::BasePropertyArray::resize, "Resize storage to hold n elements.\n\nC++: easy3d::BasePropertyArray::resize(unsigned long) --> void", pybind11::arg("n"));
		cl.def("shrink_to_fit", (void (easy3d::BasePropertyArray::*)()) &easy3d::BasePropertyArray::shrink_to_fit, "Free unused memory.\n\nC++: easy3d::BasePropertyArray::shrink_to_fit() --> void");
		cl.def("push_back", (void (easy3d::BasePropertyArray::*)()) &easy3d::BasePropertyArray::push_back, "Extend the number of elements by one.\n\nC++: easy3d::BasePropertyArray::push_back() --> void");
		cl.def("reset", (void (easy3d::BasePropertyArray::*)(unsigned long)) &easy3d::BasePropertyArray::reset, "Reset element to default value\n\nC++: easy3d::BasePropertyArray::reset(unsigned long) --> void", pybind11::arg("idx"));
		cl.def("transfer", (bool (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &)) &easy3d::BasePropertyArray::transfer, "Copy the entire properties from \n\nC++: easy3d::BasePropertyArray::transfer(const class easy3d::BasePropertyArray &) --> bool", pybind11::arg("other"));
		cl.def("transfer", (bool (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &, std::size_t, std::size_t)) &easy3d::BasePropertyArray::transfer, "Copy the property[from] of  to this->property[to].\n\nC++: easy3d::BasePropertyArray::transfer(const class easy3d::BasePropertyArray &, std::size_t, std::size_t) --> bool", pybind11::arg("other"), pybind11::arg("from"), pybind11::arg("to"));
		cl.def("swap", (void (easy3d::BasePropertyArray::*)(unsigned long, unsigned long)) &easy3d::BasePropertyArray::swap, "Let two elements swap their storage place.\n\nC++: easy3d::BasePropertyArray::swap(unsigned long, unsigned long) --> void", pybind11::arg("i0"), pybind11::arg("i1"));
		cl.def("copy", (void (easy3d::BasePropertyArray::*)(unsigned long, unsigned long)) &easy3d::BasePropertyArray::copy, "Let copy 'from' -> 'to'.\n\nC++: easy3d::BasePropertyArray::copy(unsigned long, unsigned long) --> void", pybind11::arg("from"), pybind11::arg("to"));
		cl.def("clone", (class easy3d::BasePropertyArray * (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::clone, "Return a deep copy of self.\n\nC++: easy3d::BasePropertyArray::clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("empty_clone", (class easy3d::BasePropertyArray * (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::empty_clone, "Return a empty copy of self.\n\nC++: easy3d::BasePropertyArray::empty_clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("type", (const class std::type_info & (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::type, "Return the type_info of the property\n\nC++: easy3d::BasePropertyArray::type() const --> const class std::type_info &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::name, "Return the name of the property\n\nC++: easy3d::BasePropertyArray::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::BasePropertyArray::*)(const std::string &)) &easy3d::BasePropertyArray::set_name, "Set the name of the property\n\nC++: easy3d::BasePropertyArray::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("is_same", (bool (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &) const) &easy3d::BasePropertyArray::is_same, "Test if two properties are the same.\n \n\n true only if their names and types are both identical.\n\nC++: easy3d::BasePropertyArray::is_same(const class easy3d::BasePropertyArray &) const --> bool", pybind11::arg("other"));
		cl.def("assign", (class easy3d::BasePropertyArray & (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &)) &easy3d::BasePropertyArray::operator=, "C++: easy3d::BasePropertyArray::operator=(const class easy3d::BasePropertyArray &) --> class easy3d::BasePropertyArray &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::PropertyArray file:easy3d/core/property.h line:111
		pybind11::class_<easy3d::PropertyArray<easy3d::Vec<3, float>>, std::shared_ptr<easy3d::PropertyArray<easy3d::Vec<3, float>>>, PyCallBack_easy3d_PropertyArray_easy3d_Vec_3_float_t, easy3d::BasePropertyArray> cl(M("easy3d"), "PropertyArray_easy3d_Vec_3_float_t", "");
		cl.def( pybind11::init( [](const std::string & a0){ return new easy3d::PropertyArray<easy3d::Vec<3, float>>(a0); }, [](const std::string & a0){ return new PyCallBack_easy3d_PropertyArray_easy3d_Vec_3_float_t(a0); } ), "doc");
		cl.def( pybind11::init<const std::string &, class easy3d::Vec<3, float>>(), pybind11::arg("name"), pybind11::arg("t") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_PropertyArray_easy3d_Vec_3_float_t const &o){ return new PyCallBack_easy3d_PropertyArray_easy3d_Vec_3_float_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::PropertyArray<easy3d::Vec<3, float>> const &o){ return new easy3d::PropertyArray<easy3d::Vec<3, float>>(o); } ) );
		cl.def("reserve", (void (easy3d::PropertyArray<easy3d::Vec<3, float>>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::Vec<3, float>>::reserve, "C++: easy3d::PropertyArray<easy3d::Vec<3, float>>::reserve(unsigned long) --> void", pybind11::arg("n"));
		cl.def("resize", (void (easy3d::PropertyArray<easy3d::Vec<3, float>>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::Vec<3, float>>::resize, "C++: easy3d::PropertyArray<easy3d::Vec<3, float>>::resize(unsigned long) --> void", pybind11::arg("n"));
		cl.def("push_back", (void (easy3d::PropertyArray<easy3d::Vec<3, float>>::*)()) &easy3d::PropertyArray<easy3d::Vec<3, float>>::push_back, "C++: easy3d::PropertyArray<easy3d::Vec<3, float>>::push_back() --> void");
		cl.def("reset", (void (easy3d::PropertyArray<easy3d::Vec<3, float>>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::Vec<3, float>>::reset, "C++: easy3d::PropertyArray<easy3d::Vec<3, float>>::reset(unsigned long) --> void", pybind11::arg("idx"));
		cl.def("transfer", (bool (easy3d::PropertyArray<easy3d::Vec<3, float>>::*)(const class easy3d::BasePropertyArray &)) &easy3d::PropertyArray<easy3d::Vec<3, float>>::transfer, "C++: easy3d::PropertyArray<easy3d::Vec<3, float>>::transfer(const class easy3d::BasePropertyArray &) --> bool", pybind11::arg("other"));
		cl.def("transfer", (bool (easy3d::PropertyArray<easy3d::Vec<3, float>>::*)(const class easy3d::BasePropertyArray &, std::size_t, std::size_t)) &easy3d::PropertyArray<easy3d::Vec<3, float>>::transfer, "C++: easy3d::PropertyArray<easy3d::Vec<3, float>>::transfer(const class easy3d::BasePropertyArray &, std::size_t, std::size_t) --> bool", pybind11::arg("other"), pybind11::arg("from"), pybind11::arg("to"));
		cl.def("shrink_to_fit", (void (easy3d::PropertyArray<easy3d::Vec<3, float>>::*)()) &easy3d::PropertyArray<easy3d::Vec<3, float>>::shrink_to_fit, "C++: easy3d::PropertyArray<easy3d::Vec<3, float>>::shrink_to_fit() --> void");
		cl.def("swap", (void (easy3d::PropertyArray<easy3d::Vec<3, float>>::*)(unsigned long, unsigned long)) &easy3d::PropertyArray<easy3d::Vec<3, float>>::swap, "C++: easy3d::PropertyArray<easy3d::Vec<3, float>>::swap(unsigned long, unsigned long) --> void", pybind11::arg("i0"), pybind11::arg("i1"));
		cl.def("copy", (void (easy3d::PropertyArray<easy3d::Vec<3, float>>::*)(unsigned long, unsigned long)) &easy3d::PropertyArray<easy3d::Vec<3, float>>::copy, "C++: easy3d::PropertyArray<easy3d::Vec<3, float>>::copy(unsigned long, unsigned long) --> void", pybind11::arg("from"), pybind11::arg("to"));
		cl.def("clone", (class easy3d::BasePropertyArray * (easy3d::PropertyArray<easy3d::Vec<3, float>>::*)() const) &easy3d::PropertyArray<easy3d::Vec<3, float>>::clone, "C++: easy3d::PropertyArray<easy3d::Vec<3, float>>::clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("empty_clone", (class easy3d::BasePropertyArray * (easy3d::PropertyArray<easy3d::Vec<3, float>>::*)() const) &easy3d::PropertyArray<easy3d::Vec<3, float>>::empty_clone, "C++: easy3d::PropertyArray<easy3d::Vec<3, float>>::empty_clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("type", (const class std::type_info & (easy3d::PropertyArray<easy3d::Vec<3, float>>::*)() const) &easy3d::PropertyArray<easy3d::Vec<3, float>>::type, "C++: easy3d::PropertyArray<easy3d::Vec<3, float>>::type() const --> const class std::type_info &", pybind11::return_value_policy::automatic);
		cl.def("data", (const class easy3d::Vec<3, float> * (easy3d::PropertyArray<easy3d::Vec<3, float>>::*)() const) &easy3d::PropertyArray<easy3d::Vec<3, float>>::data, "C++: easy3d::PropertyArray<easy3d::Vec<3, float>>::data() const --> const class easy3d::Vec<3, float> *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<class easy3d::Vec<3, float> > & (easy3d::PropertyArray<easy3d::Vec<3, float>>::*)()) &easy3d::PropertyArray<easy3d::Vec<3, float>>::vector, "C++: easy3d::PropertyArray<easy3d::Vec<3, float>>::vector() --> class std::vector<class easy3d::Vec<3, float> > &", pybind11::return_value_policy::automatic);
		cl.def("__getitem__", (class easy3d::Vec<3, float> & (easy3d::PropertyArray<easy3d::Vec<3, float>>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::Vec<3, float>>::operator[], "C++: easy3d::PropertyArray<easy3d::Vec<3, float>>::operator[](unsigned long) --> class easy3d::Vec<3, float> &", pybind11::return_value_policy::automatic, pybind11::arg("_idx"));
		cl.def("assign", (class easy3d::PropertyArray<class easy3d::Vec<3, float> > & (easy3d::PropertyArray<easy3d::Vec<3, float>>::*)(const class easy3d::PropertyArray<class easy3d::Vec<3, float> > &)) &easy3d::PropertyArray<easy3d::Vec<3, float>>::operator=, "C++: easy3d::PropertyArray<easy3d::Vec<3, float>>::operator=(const class easy3d::PropertyArray<class easy3d::Vec<3, float> > &) --> class easy3d::PropertyArray<class easy3d::Vec<3, float> > &", pybind11::return_value_policy::automatic, pybind11::arg(""));
		cl.def("reserve", (void (easy3d::BasePropertyArray::*)(unsigned long)) &easy3d::BasePropertyArray::reserve, "Reserve memory for n elements.\n\nC++: easy3d::BasePropertyArray::reserve(unsigned long) --> void", pybind11::arg("n"));
		cl.def("resize", (void (easy3d::BasePropertyArray::*)(unsigned long)) &easy3d::BasePropertyArray::resize, "Resize storage to hold n elements.\n\nC++: easy3d::BasePropertyArray::resize(unsigned long) --> void", pybind11::arg("n"));
		cl.def("shrink_to_fit", (void (easy3d::BasePropertyArray::*)()) &easy3d::BasePropertyArray::shrink_to_fit, "Free unused memory.\n\nC++: easy3d::BasePropertyArray::shrink_to_fit() --> void");
		cl.def("push_back", (void (easy3d::BasePropertyArray::*)()) &easy3d::BasePropertyArray::push_back, "Extend the number of elements by one.\n\nC++: easy3d::BasePropertyArray::push_back() --> void");
		cl.def("reset", (void (easy3d::BasePropertyArray::*)(unsigned long)) &easy3d::BasePropertyArray::reset, "Reset element to default value\n\nC++: easy3d::BasePropertyArray::reset(unsigned long) --> void", pybind11::arg("idx"));
		cl.def("transfer", (bool (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &)) &easy3d::BasePropertyArray::transfer, "Copy the entire properties from \n\nC++: easy3d::BasePropertyArray::transfer(const class easy3d::BasePropertyArray &) --> bool", pybind11::arg("other"));
		cl.def("transfer", (bool (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &, std::size_t, std::size_t)) &easy3d::BasePropertyArray::transfer, "Copy the property[from] of  to this->property[to].\n\nC++: easy3d::BasePropertyArray::transfer(const class easy3d::BasePropertyArray &, std::size_t, std::size_t) --> bool", pybind11::arg("other"), pybind11::arg("from"), pybind11::arg("to"));
		cl.def("swap", (void (easy3d::BasePropertyArray::*)(unsigned long, unsigned long)) &easy3d::BasePropertyArray::swap, "Let two elements swap their storage place.\n\nC++: easy3d::BasePropertyArray::swap(unsigned long, unsigned long) --> void", pybind11::arg("i0"), pybind11::arg("i1"));
		cl.def("copy", (void (easy3d::BasePropertyArray::*)(unsigned long, unsigned long)) &easy3d::BasePropertyArray::copy, "Let copy 'from' -> 'to'.\n\nC++: easy3d::BasePropertyArray::copy(unsigned long, unsigned long) --> void", pybind11::arg("from"), pybind11::arg("to"));
		cl.def("clone", (class easy3d::BasePropertyArray * (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::clone, "Return a deep copy of self.\n\nC++: easy3d::BasePropertyArray::clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("empty_clone", (class easy3d::BasePropertyArray * (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::empty_clone, "Return a empty copy of self.\n\nC++: easy3d::BasePropertyArray::empty_clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("type", (const class std::type_info & (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::type, "Return the type_info of the property\n\nC++: easy3d::BasePropertyArray::type() const --> const class std::type_info &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::name, "Return the name of the property\n\nC++: easy3d::BasePropertyArray::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::BasePropertyArray::*)(const std::string &)) &easy3d::BasePropertyArray::set_name, "Set the name of the property\n\nC++: easy3d::BasePropertyArray::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("is_same", (bool (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &) const) &easy3d::BasePropertyArray::is_same, "Test if two properties are the same.\n \n\n true only if their names and types are both identical.\n\nC++: easy3d::BasePropertyArray::is_same(const class easy3d::BasePropertyArray &) const --> bool", pybind11::arg("other"));
		cl.def("assign", (class easy3d::BasePropertyArray & (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &)) &easy3d::BasePropertyArray::operator=, "C++: easy3d::BasePropertyArray::operator=(const class easy3d::BasePropertyArray &) --> class easy3d::BasePropertyArray &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
}
