#include <easy3d/core/constant.h>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_core_constant(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	// easy3d::epsilon() file:easy3d/core/constant.h line:69
	M("easy3d").def("epsilon", (float (*)()) &easy3d::epsilon<float>, "Function returning  for float type numbers.\n\nC++: easy3d::epsilon() --> float");

	// easy3d::epsilon_sqr() file:easy3d/core/constant.h line:71
	M("easy3d").def("epsilon_sqr", (float (*)()) &easy3d::epsilon_sqr<float>, "Function returning  epsilon for float type numbers.\n\nC++: easy3d::epsilon_sqr() --> float");

	// easy3d::epsilon() file:easy3d/core/constant.h line:73
	M("easy3d").def("epsilon", (double (*)()) &easy3d::epsilon<double>, "Function returning  for double type numbers.\n\nC++: easy3d::epsilon() --> double");

	// easy3d::epsilon_sqr() file:easy3d/core/constant.h line:75
	M("easy3d").def("epsilon_sqr", (double (*)()) &easy3d::epsilon_sqr<double>, "Function returning  epsilon for double type numbers.\n\nC++: easy3d::epsilon_sqr() --> double");

}
