#include <easy3d/core/graph.h>
#include <easy3d/core/poly_mesh.h>
#include <easy3d/core/property.h>
#include <easy3d/core/vec.h>
#include <istream>
#include <memory>
#include <ostream>
#include <sstream> // __str__
#include <string>
#include <string_view>
#include <typeinfo>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

// easy3d::Property file:easy3d/core/property.h line:253
struct PyCallBack_easy3d_Property_std_vector_easy3d_Vec_3_float_t : public easy3d::Property<std::vector<easy3d::Vec<3, float> >> {
	using easy3d::Property<std::vector<easy3d::Vec<3, float> >>::Property;

	using _binder_ret_0 = std::vector<class easy3d::Vec<3, float> > &;
	_binder_ret_0 operator[](unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Property<std::vector<easy3d::Vec<3, float> >> *>(this), "__getitem__");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<_binder_ret_0>::value) {
				static pybind11::detail::override_caster_t<_binder_ret_0> caster;
				return pybind11::detail::cast_ref<_binder_ret_0>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<_binder_ret_0>(std::move(o));
		}
		return Property::operator[](a0);
	}
};

// easy3d::Property file:easy3d/core/property.h line:253
struct PyCallBack_easy3d_Property_easy3d_Graph_VertexConnectivity_t : public easy3d::Property<easy3d::Graph::VertexConnectivity> {
	using easy3d::Property<easy3d::Graph::VertexConnectivity>::Property;

	struct easy3d::Graph::VertexConnectivity & operator[](unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Property<easy3d::Graph::VertexConnectivity> *>(this), "__getitem__");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<struct easy3d::Graph::VertexConnectivity &>::value) {
				static pybind11::detail::override_caster_t<struct easy3d::Graph::VertexConnectivity &> caster;
				return pybind11::detail::cast_ref<struct easy3d::Graph::VertexConnectivity &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<struct easy3d::Graph::VertexConnectivity &>(std::move(o));
		}
		return Property::operator[](a0);
	}
};

// easy3d::Property file:easy3d/core/property.h line:253
struct PyCallBack_easy3d_Property_easy3d_Graph_EdgeConnectivity_t : public easy3d::Property<easy3d::Graph::EdgeConnectivity> {
	using easy3d::Property<easy3d::Graph::EdgeConnectivity>::Property;

	struct easy3d::Graph::EdgeConnectivity & operator[](unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Property<easy3d::Graph::EdgeConnectivity> *>(this), "__getitem__");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<struct easy3d::Graph::EdgeConnectivity &>::value) {
				static pybind11::detail::override_caster_t<struct easy3d::Graph::EdgeConnectivity &> caster;
				return pybind11::detail::cast_ref<struct easy3d::Graph::EdgeConnectivity &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<struct easy3d::Graph::EdgeConnectivity &>(std::move(o));
		}
		return Property::operator[](a0);
	}
};

// easy3d::Property file:easy3d/core/property.h line:253
struct PyCallBack_easy3d_Property_easy3d_PolyMesh_VertexConnectivity_t : public easy3d::Property<easy3d::PolyMesh::VertexConnectivity> {
	using easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::Property;

	struct easy3d::PolyMesh::VertexConnectivity & operator[](unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Property<easy3d::PolyMesh::VertexConnectivity> *>(this), "__getitem__");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<struct easy3d::PolyMesh::VertexConnectivity &>::value) {
				static pybind11::detail::override_caster_t<struct easy3d::PolyMesh::VertexConnectivity &> caster;
				return pybind11::detail::cast_ref<struct easy3d::PolyMesh::VertexConnectivity &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<struct easy3d::PolyMesh::VertexConnectivity &>(std::move(o));
		}
		return Property::operator[](a0);
	}
};

// easy3d::Property file:easy3d/core/property.h line:253
struct PyCallBack_easy3d_Property_easy3d_PolyMesh_EdgeConnectivity_t : public easy3d::Property<easy3d::PolyMesh::EdgeConnectivity> {
	using easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::Property;

	struct easy3d::PolyMesh::EdgeConnectivity & operator[](unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::Property<easy3d::PolyMesh::EdgeConnectivity> *>(this), "__getitem__");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<struct easy3d::PolyMesh::EdgeConnectivity &>::value) {
				static pybind11::detail::override_caster_t<struct easy3d::PolyMesh::EdgeConnectivity &> caster;
				return pybind11::detail::cast_ref<struct easy3d::PolyMesh::EdgeConnectivity &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<struct easy3d::PolyMesh::EdgeConnectivity &>(std::move(o));
		}
		return Property::operator[](a0);
	}
};

void bind_easy3d_core_property_11(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<std::vector<easy3d::Vec<3, float> >>, std::shared_ptr<easy3d::Property<std::vector<easy3d::Vec<3, float> >>>, PyCallBack_easy3d_Property_std_vector_easy3d_Vec_3_float_t> cl(M("easy3d"), "Property_std_vector_easy3d_Vec_3_float_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<std::vector<easy3d::Vec<3, float> >>(); }, [](){ return new PyCallBack_easy3d_Property_std_vector_easy3d_Vec_3_float_t(); } ), "doc");
		cl.def( pybind11::init<class easy3d::PropertyArray<class std::vector<class easy3d::Vec<3, float> > > *>(), pybind11::arg("p") );

		cl.def("reset", (void (easy3d::Property<std::vector<easy3d::Vec<3, float> >>::*)()) &easy3d::Property<std::vector<easy3d::Vec<3, float>>>::reset, "C++: easy3d::Property<std::vector<easy3d::Vec<3, float>>>::reset() --> void");
		cl.def("__getitem__", (class std::vector<class easy3d::Vec<3, float> > & (easy3d::Property<std::vector<easy3d::Vec<3, float> >>::*)(unsigned long)) &easy3d::Property<std::vector<easy3d::Vec<3, float>>>::operator[], "C++: easy3d::Property<std::vector<easy3d::Vec<3, float>>>::operator[](unsigned long) --> class std::vector<class easy3d::Vec<3, float> > &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("data", (const class std::vector<class easy3d::Vec<3, float> > * (easy3d::Property<std::vector<easy3d::Vec<3, float> >>::*)() const) &easy3d::Property<std::vector<easy3d::Vec<3, float>>>::data, "C++: easy3d::Property<std::vector<easy3d::Vec<3, float>>>::data() const --> const class std::vector<class easy3d::Vec<3, float> > *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<class std::vector<class easy3d::Vec<3, float> > > & (easy3d::Property<std::vector<easy3d::Vec<3, float> >>::*)()) &easy3d::Property<std::vector<easy3d::Vec<3, float>>>::vector, "C++: easy3d::Property<std::vector<easy3d::Vec<3, float>>>::vector() --> class std::vector<class std::vector<class easy3d::Vec<3, float> > > &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<class std::vector<class easy3d::Vec<3, float> > > & (easy3d::Property<std::vector<easy3d::Vec<3, float> >>::*)()) &easy3d::Property<std::vector<easy3d::Vec<3, float>>>::array, "C++: easy3d::Property<std::vector<easy3d::Vec<3, float>>>::array() --> class easy3d::PropertyArray<class std::vector<class easy3d::Vec<3, float> > > &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<std::vector<easy3d::Vec<3, float> >>::*)() const) &easy3d::Property<std::vector<easy3d::Vec<3, float>>>::name, "C++: easy3d::Property<std::vector<easy3d::Vec<3, float>>>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<std::vector<easy3d::Vec<3, float> >>::*)(const std::string &)) &easy3d::Property<std::vector<easy3d::Vec<3, float>>>::set_name, "C++: easy3d::Property<std::vector<easy3d::Vec<3, float>>>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<class std::vector<class easy3d::Vec<3, float> > > & (easy3d::Property<std::vector<easy3d::Vec<3, float> >>::*)(const class easy3d::Property<class std::vector<class easy3d::Vec<3, float> > > &)) &easy3d::Property<std::vector<easy3d::Vec<3, float>>>::operator=, "C++: easy3d::Property<std::vector<easy3d::Vec<3, float>>>::operator=(const class easy3d::Property<class std::vector<class easy3d::Vec<3, float> > > &) --> class easy3d::Property<class std::vector<class easy3d::Vec<3, float> > > &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<easy3d::Graph::VertexConnectivity>, std::shared_ptr<easy3d::Property<easy3d::Graph::VertexConnectivity>>, PyCallBack_easy3d_Property_easy3d_Graph_VertexConnectivity_t> cl(M("easy3d"), "Property_easy3d_Graph_VertexConnectivity_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<easy3d::Graph::VertexConnectivity>(); }, [](){ return new PyCallBack_easy3d_Property_easy3d_Graph_VertexConnectivity_t(); } ), "doc");
		cl.def( pybind11::init<class easy3d::PropertyArray<struct easy3d::Graph::VertexConnectivity> *>(), pybind11::arg("p") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_Property_easy3d_Graph_VertexConnectivity_t const &o){ return new PyCallBack_easy3d_Property_easy3d_Graph_VertexConnectivity_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::Property<easy3d::Graph::VertexConnectivity> const &o){ return new easy3d::Property<easy3d::Graph::VertexConnectivity>(o); } ) );
		cl.def("reset", (void (easy3d::Property<easy3d::Graph::VertexConnectivity>::*)()) &easy3d::Property<easy3d::Graph::VertexConnectivity>::reset, "C++: easy3d::Property<easy3d::Graph::VertexConnectivity>::reset() --> void");
		cl.def("__getitem__", (struct easy3d::Graph::VertexConnectivity & (easy3d::Property<easy3d::Graph::VertexConnectivity>::*)(unsigned long)) &easy3d::Property<easy3d::Graph::VertexConnectivity>::operator[], "C++: easy3d::Property<easy3d::Graph::VertexConnectivity>::operator[](unsigned long) --> struct easy3d::Graph::VertexConnectivity &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("data", (const struct easy3d::Graph::VertexConnectivity * (easy3d::Property<easy3d::Graph::VertexConnectivity>::*)() const) &easy3d::Property<easy3d::Graph::VertexConnectivity>::data, "C++: easy3d::Property<easy3d::Graph::VertexConnectivity>::data() const --> const struct easy3d::Graph::VertexConnectivity *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<struct easy3d::Graph::VertexConnectivity> & (easy3d::Property<easy3d::Graph::VertexConnectivity>::*)()) &easy3d::Property<easy3d::Graph::VertexConnectivity>::vector, "C++: easy3d::Property<easy3d::Graph::VertexConnectivity>::vector() --> class std::vector<struct easy3d::Graph::VertexConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<struct easy3d::Graph::VertexConnectivity> & (easy3d::Property<easy3d::Graph::VertexConnectivity>::*)()) &easy3d::Property<easy3d::Graph::VertexConnectivity>::array, "C++: easy3d::Property<easy3d::Graph::VertexConnectivity>::array() --> class easy3d::PropertyArray<struct easy3d::Graph::VertexConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<easy3d::Graph::VertexConnectivity>::*)() const) &easy3d::Property<easy3d::Graph::VertexConnectivity>::name, "C++: easy3d::Property<easy3d::Graph::VertexConnectivity>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<easy3d::Graph::VertexConnectivity>::*)(const std::string &)) &easy3d::Property<easy3d::Graph::VertexConnectivity>::set_name, "C++: easy3d::Property<easy3d::Graph::VertexConnectivity>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<struct easy3d::Graph::VertexConnectivity> & (easy3d::Property<easy3d::Graph::VertexConnectivity>::*)(const class easy3d::Property<struct easy3d::Graph::VertexConnectivity> &)) &easy3d::Property<easy3d::Graph::VertexConnectivity>::operator=, "C++: easy3d::Property<easy3d::Graph::VertexConnectivity>::operator=(const class easy3d::Property<struct easy3d::Graph::VertexConnectivity> &) --> class easy3d::Property<struct easy3d::Graph::VertexConnectivity> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<easy3d::Graph::EdgeConnectivity>, std::shared_ptr<easy3d::Property<easy3d::Graph::EdgeConnectivity>>, PyCallBack_easy3d_Property_easy3d_Graph_EdgeConnectivity_t> cl(M("easy3d"), "Property_easy3d_Graph_EdgeConnectivity_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<easy3d::Graph::EdgeConnectivity>(); }, [](){ return new PyCallBack_easy3d_Property_easy3d_Graph_EdgeConnectivity_t(); } ), "doc");
		cl.def( pybind11::init<class easy3d::PropertyArray<struct easy3d::Graph::EdgeConnectivity> *>(), pybind11::arg("p") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_Property_easy3d_Graph_EdgeConnectivity_t const &o){ return new PyCallBack_easy3d_Property_easy3d_Graph_EdgeConnectivity_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::Property<easy3d::Graph::EdgeConnectivity> const &o){ return new easy3d::Property<easy3d::Graph::EdgeConnectivity>(o); } ) );
		cl.def("reset", (void (easy3d::Property<easy3d::Graph::EdgeConnectivity>::*)()) &easy3d::Property<easy3d::Graph::EdgeConnectivity>::reset, "C++: easy3d::Property<easy3d::Graph::EdgeConnectivity>::reset() --> void");
		cl.def("__getitem__", (struct easy3d::Graph::EdgeConnectivity & (easy3d::Property<easy3d::Graph::EdgeConnectivity>::*)(unsigned long)) &easy3d::Property<easy3d::Graph::EdgeConnectivity>::operator[], "C++: easy3d::Property<easy3d::Graph::EdgeConnectivity>::operator[](unsigned long) --> struct easy3d::Graph::EdgeConnectivity &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("data", (const struct easy3d::Graph::EdgeConnectivity * (easy3d::Property<easy3d::Graph::EdgeConnectivity>::*)() const) &easy3d::Property<easy3d::Graph::EdgeConnectivity>::data, "C++: easy3d::Property<easy3d::Graph::EdgeConnectivity>::data() const --> const struct easy3d::Graph::EdgeConnectivity *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<struct easy3d::Graph::EdgeConnectivity> & (easy3d::Property<easy3d::Graph::EdgeConnectivity>::*)()) &easy3d::Property<easy3d::Graph::EdgeConnectivity>::vector, "C++: easy3d::Property<easy3d::Graph::EdgeConnectivity>::vector() --> class std::vector<struct easy3d::Graph::EdgeConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<struct easy3d::Graph::EdgeConnectivity> & (easy3d::Property<easy3d::Graph::EdgeConnectivity>::*)()) &easy3d::Property<easy3d::Graph::EdgeConnectivity>::array, "C++: easy3d::Property<easy3d::Graph::EdgeConnectivity>::array() --> class easy3d::PropertyArray<struct easy3d::Graph::EdgeConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<easy3d::Graph::EdgeConnectivity>::*)() const) &easy3d::Property<easy3d::Graph::EdgeConnectivity>::name, "C++: easy3d::Property<easy3d::Graph::EdgeConnectivity>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<easy3d::Graph::EdgeConnectivity>::*)(const std::string &)) &easy3d::Property<easy3d::Graph::EdgeConnectivity>::set_name, "C++: easy3d::Property<easy3d::Graph::EdgeConnectivity>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<struct easy3d::Graph::EdgeConnectivity> & (easy3d::Property<easy3d::Graph::EdgeConnectivity>::*)(const class easy3d::Property<struct easy3d::Graph::EdgeConnectivity> &)) &easy3d::Property<easy3d::Graph::EdgeConnectivity>::operator=, "C++: easy3d::Property<easy3d::Graph::EdgeConnectivity>::operator=(const class easy3d::Property<struct easy3d::Graph::EdgeConnectivity> &) --> class easy3d::Property<struct easy3d::Graph::EdgeConnectivity> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<easy3d::PolyMesh::VertexConnectivity>, std::shared_ptr<easy3d::Property<easy3d::PolyMesh::VertexConnectivity>>, PyCallBack_easy3d_Property_easy3d_PolyMesh_VertexConnectivity_t> cl(M("easy3d"), "Property_easy3d_PolyMesh_VertexConnectivity_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<easy3d::PolyMesh::VertexConnectivity>(); }, [](){ return new PyCallBack_easy3d_Property_easy3d_PolyMesh_VertexConnectivity_t(); } ), "doc");
		cl.def( pybind11::init<class easy3d::PropertyArray<struct easy3d::PolyMesh::VertexConnectivity> *>(), pybind11::arg("p") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_Property_easy3d_PolyMesh_VertexConnectivity_t const &o){ return new PyCallBack_easy3d_Property_easy3d_PolyMesh_VertexConnectivity_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::Property<easy3d::PolyMesh::VertexConnectivity> const &o){ return new easy3d::Property<easy3d::PolyMesh::VertexConnectivity>(o); } ) );
		cl.def("reset", (void (easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::*)()) &easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::reset, "C++: easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::reset() --> void");
		cl.def("__getitem__", (struct easy3d::PolyMesh::VertexConnectivity & (easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::*)(unsigned long)) &easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::operator[], "C++: easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::operator[](unsigned long) --> struct easy3d::PolyMesh::VertexConnectivity &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("data", (const struct easy3d::PolyMesh::VertexConnectivity * (easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::*)() const) &easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::data, "C++: easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::data() const --> const struct easy3d::PolyMesh::VertexConnectivity *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<struct easy3d::PolyMesh::VertexConnectivity> & (easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::*)()) &easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::vector, "C++: easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::vector() --> class std::vector<struct easy3d::PolyMesh::VertexConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<struct easy3d::PolyMesh::VertexConnectivity> & (easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::*)()) &easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::array, "C++: easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::array() --> class easy3d::PropertyArray<struct easy3d::PolyMesh::VertexConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::*)() const) &easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::name, "C++: easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::*)(const std::string &)) &easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::set_name, "C++: easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<struct easy3d::PolyMesh::VertexConnectivity> & (easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::*)(const class easy3d::Property<struct easy3d::PolyMesh::VertexConnectivity> &)) &easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::operator=, "C++: easy3d::Property<easy3d::PolyMesh::VertexConnectivity>::operator=(const class easy3d::Property<struct easy3d::PolyMesh::VertexConnectivity> &) --> class easy3d::Property<struct easy3d::PolyMesh::VertexConnectivity> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::Property file:easy3d/core/property.h line:253
		pybind11::class_<easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>, std::shared_ptr<easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>>, PyCallBack_easy3d_Property_easy3d_PolyMesh_EdgeConnectivity_t> cl(M("easy3d"), "Property_easy3d_PolyMesh_EdgeConnectivity_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>(); }, [](){ return new PyCallBack_easy3d_Property_easy3d_PolyMesh_EdgeConnectivity_t(); } ), "doc");
		cl.def( pybind11::init<class easy3d::PropertyArray<struct easy3d::PolyMesh::EdgeConnectivity> *>(), pybind11::arg("p") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_Property_easy3d_PolyMesh_EdgeConnectivity_t const &o){ return new PyCallBack_easy3d_Property_easy3d_PolyMesh_EdgeConnectivity_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::Property<easy3d::PolyMesh::EdgeConnectivity> const &o){ return new easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>(o); } ) );
		cl.def("reset", (void (easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::*)()) &easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::reset, "C++: easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::reset() --> void");
		cl.def("__getitem__", (struct easy3d::PolyMesh::EdgeConnectivity & (easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::*)(unsigned long)) &easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::operator[], "C++: easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::operator[](unsigned long) --> struct easy3d::PolyMesh::EdgeConnectivity &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("data", (const struct easy3d::PolyMesh::EdgeConnectivity * (easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::*)() const) &easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::data, "C++: easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::data() const --> const struct easy3d::PolyMesh::EdgeConnectivity *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<struct easy3d::PolyMesh::EdgeConnectivity> & (easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::*)()) &easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::vector, "C++: easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::vector() --> class std::vector<struct easy3d::PolyMesh::EdgeConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("array", (class easy3d::PropertyArray<struct easy3d::PolyMesh::EdgeConnectivity> & (easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::*)()) &easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::array, "C++: easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::array() --> class easy3d::PropertyArray<struct easy3d::PolyMesh::EdgeConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::*)() const) &easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::name, "C++: easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::*)(const std::string &)) &easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::set_name, "C++: easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("assign", (class easy3d::Property<struct easy3d::PolyMesh::EdgeConnectivity> & (easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::*)(const class easy3d::Property<struct easy3d::PolyMesh::EdgeConnectivity> &)) &easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::operator=, "C++: easy3d::Property<easy3d::PolyMesh::EdgeConnectivity>::operator=(const class easy3d::Property<struct easy3d::PolyMesh::EdgeConnectivity> &) --> class easy3d::Property<struct easy3d::PolyMesh::EdgeConnectivity> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
}
