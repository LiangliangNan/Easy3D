#include <easy3d/core/mat.h>
#include <easy3d/core/quat.h>
#include <easy3d/core/vec.h>
#include <ios>
#include <locale>
#include <ostream>
#include <sstream> // __str__
#include <streambuf>
#include <string>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_core_mat(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	{ // easy3d::Mat file:easy3d/core/mat.h line:65
		pybind11::class_<easy3d::Mat<3UL,3UL,float>, std::shared_ptr<easy3d::Mat<3UL,3UL,float>>> cl(M("easy3d"), "Mat_3UL_3UL_float_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Mat<3UL,3UL,float>(); } ) );
		cl.def( pybind11::init<float>(), pybind11::arg("s") );

		cl.def( pybind11::init<const float *>(), pybind11::arg("m") );

		cl.def( pybind11::init( [](easy3d::Mat<3UL,3UL,float> const &o){ return new easy3d::Mat<3UL,3UL,float>(o); } ) );
		cl.def_static("identity", (class easy3d::Mat<3, 3, float> (*)()) &easy3d::Mat<3, 3, float>::identity, "C++: easy3d::Mat<3, 3, float>::identity() --> class easy3d::Mat<3, 3, float>");
		cl.def("num_rows", (unsigned long (easy3d::Mat<3UL,3UL,float>::*)() const) &easy3d::Mat<3, 3, float>::num_rows, "C++: easy3d::Mat<3, 3, float>::num_rows() const --> unsigned long");
		cl.def("num_columns", (unsigned long (easy3d::Mat<3UL,3UL,float>::*)() const) &easy3d::Mat<3, 3, float>::num_columns, "C++: easy3d::Mat<3, 3, float>::num_columns() const --> unsigned long");
		cl.def("row", (class easy3d::Vec<3, float> (easy3d::Mat<3UL,3UL,float>::*)(unsigned long) const) &easy3d::Mat<3, 3, float>::row, "C++: easy3d::Mat<3, 3, float>::row(unsigned long) const --> class easy3d::Vec<3, float>", pybind11::arg("r"));
		cl.def("col", (class easy3d::Vec<3, float> (easy3d::Mat<3UL,3UL,float>::*)(unsigned long) const) &easy3d::Mat<3, 3, float>::col, "C++: easy3d::Mat<3, 3, float>::col(unsigned long) const --> class easy3d::Vec<3, float>", pybind11::arg("c"));
		cl.def("__call__", (float & (easy3d::Mat<3UL,3UL,float>::*)(unsigned long, unsigned long)) &easy3d::Mat<3, 3, float>::operator(), "C++: easy3d::Mat<3, 3, float>::operator()(unsigned long, unsigned long) --> float &", pybind11::return_value_policy::automatic, pybind11::arg("row"), pybind11::arg("col"));
		cl.def("load_zero", (void (easy3d::Mat<3UL,3UL,float>::*)()) &easy3d::Mat<3, 3, float>::load_zero, "C++: easy3d::Mat<3, 3, float>::load_zero() --> void");
		cl.def("load_identity", [](easy3d::Mat<3UL,3UL,float> &o) -> void { return o.load_identity(); }, "");
		cl.def("load_identity", (void (easy3d::Mat<3UL,3UL,float>::*)(float)) &easy3d::Mat<3, 3, float>::load_identity, "C++: easy3d::Mat<3, 3, float>::load_identity(float) --> void", pybind11::arg("s"));
		cl.def("swap_rows", (void (easy3d::Mat<3UL,3UL,float>::*)(unsigned long, unsigned long)) &easy3d::Mat<3, 3, float>::swap_rows, "C++: easy3d::Mat<3, 3, float>::swap_rows(unsigned long, unsigned long) --> void", pybind11::arg("a"), pybind11::arg("b"));
		cl.def("swap_cols", (void (easy3d::Mat<3UL,3UL,float>::*)(unsigned long, unsigned long)) &easy3d::Mat<3, 3, float>::swap_cols, "C++: easy3d::Mat<3, 3, float>::swap_cols(unsigned long, unsigned long) --> void", pybind11::arg("a"), pybind11::arg("b"));
		cl.def("__eq__", (bool (easy3d::Mat<3UL,3UL,float>::*)(const class easy3d::Mat<3, 3, float> &) const) &easy3d::Mat<3, 3, float>::operator==, "C++: easy3d::Mat<3, 3, float>::operator==(const class easy3d::Mat<3, 3, float> &) const --> bool", pybind11::arg("rhs"));
		cl.def("__ne__", (bool (easy3d::Mat<3UL,3UL,float>::*)(const class easy3d::Mat<3, 3, float> &) const) &easy3d::Mat<3, 3, float>::operator!=, "C++: easy3d::Mat<3, 3, float>::operator!=(const class easy3d::Mat<3, 3, float> &) const --> bool", pybind11::arg("rhs"));
		cl.def("__add__", (class easy3d::Mat<3, 3, float> (easy3d::Mat<3UL,3UL,float>::*)(const class easy3d::Mat<3, 3, float> &) const) &easy3d::Mat<3, 3, float>::operator+, "C++: easy3d::Mat<3, 3, float>::operator+(const class easy3d::Mat<3, 3, float> &) const --> class easy3d::Mat<3, 3, float>", pybind11::arg("rhs"));
		cl.def("__sub__", (class easy3d::Mat<3, 3, float> (easy3d::Mat<3UL,3UL,float>::*)(const class easy3d::Mat<3, 3, float> &) const) &easy3d::Mat<3, 3, float>::operator-, "C++: easy3d::Mat<3, 3, float>::operator-(const class easy3d::Mat<3, 3, float> &) const --> class easy3d::Mat<3, 3, float>", pybind11::arg("rhs"));
		cl.def("__neg__", (class easy3d::Mat<3, 3, float> (easy3d::Mat<3UL,3UL,float>::*)() const) &easy3d::Mat<3, 3, float>::operator-, "C++: easy3d::Mat<3, 3, float>::operator-() const --> class easy3d::Mat<3, 3, float>");
		cl.def("__mul__", (class easy3d::Vec<3, float> (easy3d::Mat<3UL,3UL,float>::*)(const class easy3d::Vec<3, float> &) const) &easy3d::Mat<3, 3, float>::operator*, "C++: easy3d::Mat<3, 3, float>::operator*(const class easy3d::Vec<3, float> &) const --> class easy3d::Vec<3, float>", pybind11::arg("rhs"));
		cl.def("__mul__", (class easy3d::Mat<3, 3, float> (easy3d::Mat<3UL,3UL,float>::*)(float) const) &easy3d::Mat<3, 3, float>::operator*, "C++: easy3d::Mat<3, 3, float>::operator*(float) const --> class easy3d::Mat<3, 3, float>", pybind11::arg("rhs"));
		cl.def("__truediv__", (class easy3d::Mat<3, 3, float> (easy3d::Mat<3UL,3UL,float>::*)(float) const) &easy3d::Mat<3, 3, float>::operator/, "C++: easy3d::Mat<3, 3, float>::operator/(float) const --> class easy3d::Mat<3, 3, float>", pybind11::arg("rhs"));
		cl.def("__imul__", (class easy3d::Mat<3, 3, float> & (easy3d::Mat<3UL,3UL,float>::*)(const class easy3d::Mat<3, 3, float> &)) &easy3d::Mat<3, 3, float>::operator*=, "C++: easy3d::Mat<3, 3, float>::operator*=(const class easy3d::Mat<3, 3, float> &) --> class easy3d::Mat<3, 3, float> &", pybind11::return_value_policy::automatic, pybind11::arg("rhs"));
		cl.def("__iadd__", (class easy3d::Mat<3, 3, float> & (easy3d::Mat<3UL,3UL,float>::*)(const class easy3d::Mat<3, 3, float> &)) &easy3d::Mat<3, 3, float>::operator+=, "C++: easy3d::Mat<3, 3, float>::operator+=(const class easy3d::Mat<3, 3, float> &) --> class easy3d::Mat<3, 3, float> &", pybind11::return_value_policy::automatic, pybind11::arg("rhs"));
		cl.def("__isub__", (class easy3d::Mat<3, 3, float> & (easy3d::Mat<3UL,3UL,float>::*)(const class easy3d::Mat<3, 3, float> &)) &easy3d::Mat<3, 3, float>::operator-=, "C++: easy3d::Mat<3, 3, float>::operator-=(const class easy3d::Mat<3, 3, float> &) --> class easy3d::Mat<3, 3, float> &", pybind11::return_value_policy::automatic, pybind11::arg("rhs"));
		cl.def("__imul__", (class easy3d::Mat<3, 3, float> & (easy3d::Mat<3UL,3UL,float>::*)(float)) &easy3d::Mat<3, 3, float>::operator*=, "C++: easy3d::Mat<3, 3, float>::operator*=(float) --> class easy3d::Mat<3, 3, float> &", pybind11::return_value_policy::automatic, pybind11::arg("rhs"));
		cl.def("__itruediv__", (class easy3d::Mat<3, 3, float> & (easy3d::Mat<3UL,3UL,float>::*)(float)) &easy3d::Mat<3, 3, float>::operator/=, "C++: easy3d::Mat<3, 3, float>::operator/=(float) --> class easy3d::Mat<3, 3, float> &", pybind11::return_value_policy::automatic, pybind11::arg("rhs"));
		cl.def("__iadd__", (class easy3d::Mat<3, 3, float> & (easy3d::Mat<3UL,3UL,float>::*)(float)) &easy3d::Mat<3, 3, float>::operator+=, "C++: easy3d::Mat<3, 3, float>::operator+=(float) --> class easy3d::Mat<3, 3, float> &", pybind11::return_value_policy::automatic, pybind11::arg("rhs"));
		cl.def("__isub__", (class easy3d::Mat<3, 3, float> & (easy3d::Mat<3UL,3UL,float>::*)(float)) &easy3d::Mat<3, 3, float>::operator-=, "C++: easy3d::Mat<3, 3, float>::operator-=(float) --> class easy3d::Mat<3, 3, float> &", pybind11::return_value_policy::automatic, pybind11::arg("rhs"));
	}
	{ // easy3d::Mat file:easy3d/core/mat.h line:65
		pybind11::class_<easy3d::Mat<4UL,4UL,float>, std::shared_ptr<easy3d::Mat<4UL,4UL,float>>> cl(M("easy3d"), "Mat_4UL_4UL_float_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Mat<4UL,4UL,float>(); } ) );
		cl.def( pybind11::init<float>(), pybind11::arg("s") );

		cl.def( pybind11::init<const float *>(), pybind11::arg("m") );

		cl.def_static("identity", (class easy3d::Mat<4, 4, float> (*)()) &easy3d::Mat<4, 4, float>::identity, "C++: easy3d::Mat<4, 4, float>::identity() --> class easy3d::Mat<4, 4, float>");
		cl.def("num_rows", (unsigned long (easy3d::Mat<4UL,4UL,float>::*)() const) &easy3d::Mat<4, 4, float>::num_rows, "C++: easy3d::Mat<4, 4, float>::num_rows() const --> unsigned long");
		cl.def("num_columns", (unsigned long (easy3d::Mat<4UL,4UL,float>::*)() const) &easy3d::Mat<4, 4, float>::num_columns, "C++: easy3d::Mat<4, 4, float>::num_columns() const --> unsigned long");
		cl.def("row", (class easy3d::Vec<4, float> (easy3d::Mat<4UL,4UL,float>::*)(unsigned long) const) &easy3d::Mat<4, 4, float>::row, "C++: easy3d::Mat<4, 4, float>::row(unsigned long) const --> class easy3d::Vec<4, float>", pybind11::arg("r"));
		cl.def("col", (class easy3d::Vec<4, float> (easy3d::Mat<4UL,4UL,float>::*)(unsigned long) const) &easy3d::Mat<4, 4, float>::col, "C++: easy3d::Mat<4, 4, float>::col(unsigned long) const --> class easy3d::Vec<4, float>", pybind11::arg("c"));
		cl.def("__call__", (float & (easy3d::Mat<4UL,4UL,float>::*)(unsigned long, unsigned long)) &easy3d::Mat<4, 4, float>::operator(), "C++: easy3d::Mat<4, 4, float>::operator()(unsigned long, unsigned long) --> float &", pybind11::return_value_policy::automatic, pybind11::arg("r"), pybind11::arg("c"));
		cl.def("load_zero", (void (easy3d::Mat<4UL,4UL,float>::*)()) &easy3d::Mat<4, 4, float>::load_zero, "C++: easy3d::Mat<4, 4, float>::load_zero() --> void");
		cl.def("load_identity", [](easy3d::Mat<4UL,4UL,float> &o) -> void { return o.load_identity(); }, "");
		cl.def("load_identity", (void (easy3d::Mat<4UL,4UL,float>::*)(float)) &easy3d::Mat<4, 4, float>::load_identity, "C++: easy3d::Mat<4, 4, float>::load_identity(float) --> void", pybind11::arg("s"));
		cl.def("swap_rows", (void (easy3d::Mat<4UL,4UL,float>::*)(unsigned long, unsigned long)) &easy3d::Mat<4, 4, float>::swap_rows, "C++: easy3d::Mat<4, 4, float>::swap_rows(unsigned long, unsigned long) --> void", pybind11::arg("a"), pybind11::arg("b"));
		cl.def("swap_cols", (void (easy3d::Mat<4UL,4UL,float>::*)(unsigned long, unsigned long)) &easy3d::Mat<4, 4, float>::swap_cols, "C++: easy3d::Mat<4, 4, float>::swap_cols(unsigned long, unsigned long) --> void", pybind11::arg("a"), pybind11::arg("b"));
		cl.def("__eq__", (bool (easy3d::Mat<4UL,4UL,float>::*)(const class easy3d::Mat<4, 4, float> &) const) &easy3d::Mat<4, 4, float>::operator==, "C++: easy3d::Mat<4, 4, float>::operator==(const class easy3d::Mat<4, 4, float> &) const --> bool", pybind11::arg("rhs"));
		cl.def("__ne__", (bool (easy3d::Mat<4UL,4UL,float>::*)(const class easy3d::Mat<4, 4, float> &) const) &easy3d::Mat<4, 4, float>::operator!=, "C++: easy3d::Mat<4, 4, float>::operator!=(const class easy3d::Mat<4, 4, float> &) const --> bool", pybind11::arg("rhs"));
		cl.def("__add__", (class easy3d::Mat<4, 4, float> (easy3d::Mat<4UL,4UL,float>::*)(const class easy3d::Mat<4, 4, float> &) const) &easy3d::Mat<4, 4, float>::operator+, "C++: easy3d::Mat<4, 4, float>::operator+(const class easy3d::Mat<4, 4, float> &) const --> class easy3d::Mat<4, 4, float>", pybind11::arg("rhs"));
		cl.def("__sub__", (class easy3d::Mat<4, 4, float> (easy3d::Mat<4UL,4UL,float>::*)(const class easy3d::Mat<4, 4, float> &) const) &easy3d::Mat<4, 4, float>::operator-, "C++: easy3d::Mat<4, 4, float>::operator-(const class easy3d::Mat<4, 4, float> &) const --> class easy3d::Mat<4, 4, float>", pybind11::arg("rhs"));
		cl.def("__neg__", (class easy3d::Mat<4, 4, float> (easy3d::Mat<4UL,4UL,float>::*)() const) &easy3d::Mat<4, 4, float>::operator-, "C++: easy3d::Mat<4, 4, float>::operator-() const --> class easy3d::Mat<4, 4, float>");
		cl.def("__mul__", (class easy3d::Vec<4, float> (easy3d::Mat<4UL,4UL,float>::*)(const class easy3d::Vec<4, float> &) const) &easy3d::Mat<4, 4, float>::operator*, "C++: easy3d::Mat<4, 4, float>::operator*(const class easy3d::Vec<4, float> &) const --> class easy3d::Vec<4, float>", pybind11::arg("rhs"));
		cl.def("__mul__", (class easy3d::Mat<4, 4, float> (easy3d::Mat<4UL,4UL,float>::*)(float) const) &easy3d::Mat<4, 4, float>::operator*, "C++: easy3d::Mat<4, 4, float>::operator*(float) const --> class easy3d::Mat<4, 4, float>", pybind11::arg("rhs"));
		cl.def("__truediv__", (class easy3d::Mat<4, 4, float> (easy3d::Mat<4UL,4UL,float>::*)(float) const) &easy3d::Mat<4, 4, float>::operator/, "C++: easy3d::Mat<4, 4, float>::operator/(float) const --> class easy3d::Mat<4, 4, float>", pybind11::arg("rhs"));
		cl.def("__imul__", (class easy3d::Mat<4, 4, float> & (easy3d::Mat<4UL,4UL,float>::*)(const class easy3d::Mat<4, 4, float> &)) &easy3d::Mat<4, 4, float>::operator*=, "C++: easy3d::Mat<4, 4, float>::operator*=(const class easy3d::Mat<4, 4, float> &) --> class easy3d::Mat<4, 4, float> &", pybind11::return_value_policy::automatic, pybind11::arg("rhs"));
		cl.def("__iadd__", (class easy3d::Mat<4, 4, float> & (easy3d::Mat<4UL,4UL,float>::*)(const class easy3d::Mat<4, 4, float> &)) &easy3d::Mat<4, 4, float>::operator+=, "C++: easy3d::Mat<4, 4, float>::operator+=(const class easy3d::Mat<4, 4, float> &) --> class easy3d::Mat<4, 4, float> &", pybind11::return_value_policy::automatic, pybind11::arg("rhs"));
		cl.def("__isub__", (class easy3d::Mat<4, 4, float> & (easy3d::Mat<4UL,4UL,float>::*)(const class easy3d::Mat<4, 4, float> &)) &easy3d::Mat<4, 4, float>::operator-=, "C++: easy3d::Mat<4, 4, float>::operator-=(const class easy3d::Mat<4, 4, float> &) --> class easy3d::Mat<4, 4, float> &", pybind11::return_value_policy::automatic, pybind11::arg("rhs"));
		cl.def("__imul__", (class easy3d::Mat<4, 4, float> & (easy3d::Mat<4UL,4UL,float>::*)(float)) &easy3d::Mat<4, 4, float>::operator*=, "C++: easy3d::Mat<4, 4, float>::operator*=(float) --> class easy3d::Mat<4, 4, float> &", pybind11::return_value_policy::automatic, pybind11::arg("rhs"));
		cl.def("__itruediv__", (class easy3d::Mat<4, 4, float> & (easy3d::Mat<4UL,4UL,float>::*)(float)) &easy3d::Mat<4, 4, float>::operator/=, "C++: easy3d::Mat<4, 4, float>::operator/=(float) --> class easy3d::Mat<4, 4, float> &", pybind11::return_value_policy::automatic, pybind11::arg("rhs"));
		cl.def("__iadd__", (class easy3d::Mat<4, 4, float> & (easy3d::Mat<4UL,4UL,float>::*)(float)) &easy3d::Mat<4, 4, float>::operator+=, "C++: easy3d::Mat<4, 4, float>::operator+=(float) --> class easy3d::Mat<4, 4, float> &", pybind11::return_value_policy::automatic, pybind11::arg("rhs"));
		cl.def("__isub__", (class easy3d::Mat<4, 4, float> & (easy3d::Mat<4UL,4UL,float>::*)(float)) &easy3d::Mat<4, 4, float>::operator-=, "C++: easy3d::Mat<4, 4, float>::operator-=(float) --> class easy3d::Mat<4, 4, float> &", pybind11::return_value_policy::automatic, pybind11::arg("rhs"));
	}
	// easy3d::determinant(const class easy3d::Mat<3, 3, float> &) file:easy3d/core/mat.h line:930
	M("easy3d").def("determinant", (float (*)(const class easy3d::Mat<3, 3, float> &)) &easy3d::determinant<3UL,float>, "C++: easy3d::determinant(const class easy3d::Mat<3, 3, float> &) --> float", pybind11::arg("m"));

	// easy3d::determinant(const class easy3d::Mat3<float> &) file:easy3d/core/mat.h line:949
	M("easy3d").def("determinant", (float (*)(const class easy3d::Mat3<float> &)) &easy3d::determinant<float>, "C++: easy3d::determinant(const class easy3d::Mat3<float> &) --> float", pybind11::arg("m"));

	{ // easy3d::Quat file:easy3d/core/quat.h line:106
		pybind11::class_<easy3d::Quat<float>, std::shared_ptr<easy3d::Quat<float>>> cl(M("easy3d"), "Quat_float_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Quat<float>(); } ) );
		cl.def( pybind11::init<const class easy3d::Mat3<float> &>(), pybind11::arg("m") );

		cl.def( pybind11::init<const class easy3d::Vec<3, float> &, float>(), pybind11::arg("axis"), pybind11::arg("angle") );

		cl.def( pybind11::init<const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &>(), pybind11::arg("from"), pybind11::arg("to") );

		cl.def( pybind11::init<float, float, float, float>(), pybind11::arg("q0"), pybind11::arg("q1"), pybind11::arg("q2"), pybind11::arg("q3") );

		cl.def( pybind11::init( [](easy3d::Quat<float> const &o){ return new easy3d::Quat<float>(o); } ) );
		cl.def("assign", (class easy3d::Quat<float> & (easy3d::Quat<float>::*)(const class easy3d::Quat<float> &)) &easy3d::Quat<float>::operator=, "C++: easy3d::Quat<float>::operator=(const class easy3d::Quat<float> &) --> class easy3d::Quat<float> &", pybind11::return_value_policy::automatic, pybind11::arg("Q"));
		cl.def("set_axis_angle", (void (easy3d::Quat<float>::*)(const class easy3d::Vec<3, float> &, float)) &easy3d::Quat<float>::set_axis_angle, "C++: easy3d::Quat<float>::set_axis_angle(const class easy3d::Vec<3, float> &, float) --> void", pybind11::arg("axis"), pybind11::arg("angle"));
		cl.def("set_value", (void (easy3d::Quat<float>::*)(float, float, float, float)) &easy3d::Quat<float>::set_value, "C++: easy3d::Quat<float>::set_value(float, float, float, float) --> void", pybind11::arg("q0"), pybind11::arg("q1"), pybind11::arg("q2"), pybind11::arg("q3"));
		cl.def("set_from_rotation_matrix", (void (easy3d::Quat<float>::*)(const class easy3d::Mat3<float> &)) &easy3d::Quat<float>::set_from_rotation_matrix, "C++: easy3d::Quat<float>::set_from_rotation_matrix(const class easy3d::Mat3<float> &) --> void", pybind11::arg("m"));
		cl.def("set_from_rotated_basis", (void (easy3d::Quat<float>::*)(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &)) &easy3d::Quat<float>::set_from_rotated_basis, "C++: easy3d::Quat<float>::set_from_rotated_basis(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &) --> void", pybind11::arg("X"), pybind11::arg("Y"), pybind11::arg("Z"));
		cl.def("axis", (class easy3d::Vec<3, float> (easy3d::Quat<float>::*)() const) &easy3d::Quat<float>::axis, "C++: easy3d::Quat<float>::axis() const --> class easy3d::Vec<3, float>");
		cl.def("angle", (float (easy3d::Quat<float>::*)() const) &easy3d::Quat<float>::angle, "C++: easy3d::Quat<float>::angle() const --> float");
		cl.def("get_axis_angle", (void (easy3d::Quat<float>::*)(class easy3d::Vec<3, float> &, float &) const) &easy3d::Quat<float>::get_axis_angle, "C++: easy3d::Quat<float>::get_axis_angle(class easy3d::Vec<3, float> &, float &) const --> void", pybind11::arg("axis"), pybind11::arg("angle"));
		cl.def("__getitem__", (float & (easy3d::Quat<float>::*)(int)) &easy3d::Quat<float>::operator[], "C++: easy3d::Quat<float>::operator[](int) --> float &", pybind11::return_value_policy::automatic, pybind11::arg("i"));
		cl.def("__imul__", (class easy3d::Quat<float> & (easy3d::Quat<float>::*)(const class easy3d::Quat<float> &)) &easy3d::Quat<float>::operator*=, "C++: easy3d::Quat<float>::operator*=(const class easy3d::Quat<float> &) --> class easy3d::Quat<float> &", pybind11::return_value_policy::automatic, pybind11::arg("q"));
		cl.def("rotate", (class easy3d::Vec<3, float> (easy3d::Quat<float>::*)(const class easy3d::Vec<3, float> &) const) &easy3d::Quat<float>::rotate, "C++: easy3d::Quat<float>::rotate(const class easy3d::Vec<3, float> &) const --> class easy3d::Vec<3, float>", pybind11::arg("v"));
		cl.def("inverse_rotate", (class easy3d::Vec<3, float> (easy3d::Quat<float>::*)(const class easy3d::Vec<3, float> &) const) &easy3d::Quat<float>::inverse_rotate, "C++: easy3d::Quat<float>::inverse_rotate(const class easy3d::Vec<3, float> &) const --> class easy3d::Vec<3, float>", pybind11::arg("v"));
		cl.def("inverse", (class easy3d::Quat<float> (easy3d::Quat<float>::*)() const) &easy3d::Quat<float>::inverse, "C++: easy3d::Quat<float>::inverse() const --> class easy3d::Quat<float>");
		cl.def("invert", (void (easy3d::Quat<float>::*)()) &easy3d::Quat<float>::invert, "C++: easy3d::Quat<float>::invert() --> void");
		cl.def("negate", (void (easy3d::Quat<float>::*)()) &easy3d::Quat<float>::negate, "C++: easy3d::Quat<float>::negate() --> void");
		cl.def("length", (float (easy3d::Quat<float>::*)() const) &easy3d::Quat<float>::length, "C++: easy3d::Quat<float>::length() const --> float");
		cl.def("normalize", (float (easy3d::Quat<float>::*)()) &easy3d::Quat<float>::normalize, "C++: easy3d::Quat<float>::normalize() --> float");
		cl.def("normalized", (class easy3d::Quat<float> (easy3d::Quat<float>::*)() const) &easy3d::Quat<float>::normalized, "C++: easy3d::Quat<float>::normalized() const --> class easy3d::Quat<float>");
		cl.def("matrix", (class easy3d::Mat4<float> (easy3d::Quat<float>::*)() const) &easy3d::Quat<float>::matrix, "C++: easy3d::Quat<float>::matrix() const --> class easy3d::Mat4<float>");
		cl.def("inverse_matrix", (class easy3d::Mat4<float> (easy3d::Quat<float>::*)() const) &easy3d::Quat<float>::inverse_matrix, "C++: easy3d::Quat<float>::inverse_matrix() const --> class easy3d::Mat4<float>");
		cl.def_static("slerp", [](const class easy3d::Quat<float> & a0, const class easy3d::Quat<float> & a1, float const & a2) -> easy3d::Quat<float> { return easy3d::Quat<float>::slerp(a0, a1, a2); }, "", pybind11::arg("a"), pybind11::arg("b"), pybind11::arg("t"));
		cl.def_static("slerp", (class easy3d::Quat<float> (*)(const class easy3d::Quat<float> &, const class easy3d::Quat<float> &, float, bool)) &easy3d::Quat<float>::slerp, "C++: easy3d::Quat<float>::slerp(const class easy3d::Quat<float> &, const class easy3d::Quat<float> &, float, bool) --> class easy3d::Quat<float>", pybind11::arg("a"), pybind11::arg("b"), pybind11::arg("t"), pybind11::arg("allowFlip"));
		cl.def_static("squad", (class easy3d::Quat<float> (*)(const class easy3d::Quat<float> &, const class easy3d::Quat<float> &, const class easy3d::Quat<float> &, const class easy3d::Quat<float> &, float)) &easy3d::Quat<float>::squad, "C++: easy3d::Quat<float>::squad(const class easy3d::Quat<float> &, const class easy3d::Quat<float> &, const class easy3d::Quat<float> &, const class easy3d::Quat<float> &, float) --> class easy3d::Quat<float>", pybind11::arg("a"), pybind11::arg("tgA"), pybind11::arg("tgB"), pybind11::arg("b"), pybind11::arg("t"));
		cl.def_static("dot", (float (*)(const class easy3d::Quat<float> &, const class easy3d::Quat<float> &)) &easy3d::Quat<float>::dot, "C++: easy3d::Quat<float>::dot(const class easy3d::Quat<float> &, const class easy3d::Quat<float> &) --> float", pybind11::arg("a"), pybind11::arg("b"));
		cl.def("log", (class easy3d::Quat<float> (easy3d::Quat<float>::*)()) &easy3d::Quat<float>::log, "C++: easy3d::Quat<float>::log() --> class easy3d::Quat<float>");
		cl.def("exp", (class easy3d::Quat<float> (easy3d::Quat<float>::*)()) &easy3d::Quat<float>::exp, "C++: easy3d::Quat<float>::exp() --> class easy3d::Quat<float>");
		cl.def_static("ln_dif", (class easy3d::Quat<float> (*)(const class easy3d::Quat<float> &, const class easy3d::Quat<float> &)) &easy3d::Quat<float>::ln_dif, "C++: easy3d::Quat<float>::ln_dif(const class easy3d::Quat<float> &, const class easy3d::Quat<float> &) --> class easy3d::Quat<float>", pybind11::arg("a"), pybind11::arg("b"));
		cl.def_static("squad_tangent", (class easy3d::Quat<float> (*)(const class easy3d::Quat<float> &, const class easy3d::Quat<float> &, const class easy3d::Quat<float> &)) &easy3d::Quat<float>::squad_tangent, "C++: easy3d::Quat<float>::squad_tangent(const class easy3d::Quat<float> &, const class easy3d::Quat<float> &, const class easy3d::Quat<float> &) --> class easy3d::Quat<float>", pybind11::arg("before"), pybind11::arg("center"), pybind11::arg("after"));
		cl.def_static("random_quat", (class easy3d::Quat<float> (*)()) &easy3d::Quat<float>::random_quat, "C++: easy3d::Quat<float>::random_quat() --> class easy3d::Quat<float>");

		cl.def("__str__", [](easy3d::Quat<float> const &o) -> std::string { std::ostringstream s; using namespace easy3d; s << o; return s.str(); } );

		{ // easy3d::Quat<float>::(anonymous union at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/quat.h:371:9) file:easy3d/core/quat.h line:371

			{ // easy3d::Quat<float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/quat.h:372:13) file:easy3d/core/quat.h line:372
				cl.def_readwrite("x", &easy3d::Quat<float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/quat.h:372:13)::x);
				cl.def_readwrite("y", &easy3d::Quat<float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/quat.h:372:13)::y);
				cl.def_readwrite("z", &easy3d::Quat<float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/quat.h:372:13)::z);
				cl.def_readwrite("w", &easy3d::Quat<float>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/quat.h:372:13)::w);
			}

		}

	}
}
