#include <easy3d/core/constant.h>
#include <easy3d/core/vec.h>
#include <sstream> // __str__

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_core_vec_1(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	{ // easy3d::Vec file:easy3d/core/vec.h line:438
		pybind11::class_<easy3d::Vec<3UL,double>, std::shared_ptr<easy3d::Vec<3UL,double>>> cl(M("easy3d"), "Vec_3UL_double_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Vec<3UL,double>(); } ) );
		cl.def( pybind11::init<double, double, double>(), pybind11::arg("x_in"), pybind11::arg("y_in"), pybind11::arg("z_in") );

		cl.def( pybind11::init<const double &>(), pybind11::arg("s") );

		cl.def( pybind11::init( [](easy3d::Vec<3UL,double> const &o){ return new easy3d::Vec<3UL,double>(o); } ) );
		cl.def("length2", (double (easy3d::Vec<3UL,double>::*)() const) &easy3d::Vec<3, double>::length2, "C++: easy3d::Vec<3, double>::length2() const --> double");
		cl.def("length", (double (easy3d::Vec<3UL,double>::*)() const) &easy3d::Vec<3, double>::length, "C++: easy3d::Vec<3, double>::length() const --> double");
		cl.def("norm", (double (easy3d::Vec<3UL,double>::*)() const) &easy3d::Vec<3, double>::norm, "C++: easy3d::Vec<3, double>::norm() const --> double");
		cl.def("distance2", (double (easy3d::Vec<3UL,double>::*)(const class easy3d::Vec<3, double> &) const) &easy3d::Vec<3, double>::distance2, "C++: easy3d::Vec<3, double>::distance2(const class easy3d::Vec<3, double> &) const --> double", pybind11::arg("rhs"));
		cl.def("normalize", (class easy3d::Vec<3, double> & (easy3d::Vec<3UL,double>::*)()) &easy3d::Vec<3, double>::normalize, "C++: easy3d::Vec<3, double>::normalize() --> class easy3d::Vec<3, double> &", pybind11::return_value_policy::automatic);
		cl.def("__iadd__", (class easy3d::Vec<3, double> & (easy3d::Vec<3UL,double>::*)(const class easy3d::Vec<3, double> &)) &easy3d::Vec<3, double>::operator+=, "C++: easy3d::Vec<3, double>::operator+=(const class easy3d::Vec<3, double> &) --> class easy3d::Vec<3, double> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__isub__", (class easy3d::Vec<3, double> & (easy3d::Vec<3UL,double>::*)(const class easy3d::Vec<3, double> &)) &easy3d::Vec<3, double>::operator-=, "C++: easy3d::Vec<3, double>::operator-=(const class easy3d::Vec<3, double> &) --> class easy3d::Vec<3, double> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__imul__", (class easy3d::Vec<3, double> & (easy3d::Vec<3UL,double>::*)(const class easy3d::Vec<3, double> &)) &easy3d::Vec<3, double>::operator*=, "C++: easy3d::Vec<3, double>::operator*=(const class easy3d::Vec<3, double> &) --> class easy3d::Vec<3, double> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__itruediv__", (class easy3d::Vec<3, double> & (easy3d::Vec<3UL,double>::*)(const class easy3d::Vec<3, double> &)) &easy3d::Vec<3, double>::operator/=, "C++: easy3d::Vec<3, double>::operator/=(const class easy3d::Vec<3, double> &) --> class easy3d::Vec<3, double> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__add__", (class easy3d::Vec<3, double> (easy3d::Vec<3UL,double>::*)(const class easy3d::Vec<3, double> &) const) &easy3d::Vec<3, double>::operator+, "C++: easy3d::Vec<3, double>::operator+(const class easy3d::Vec<3, double> &) const --> class easy3d::Vec<3, double>", pybind11::arg("v"));
		cl.def("__sub__", (class easy3d::Vec<3, double> (easy3d::Vec<3UL,double>::*)(const class easy3d::Vec<3, double> &) const) &easy3d::Vec<3, double>::operator-, "C++: easy3d::Vec<3, double>::operator-(const class easy3d::Vec<3, double> &) const --> class easy3d::Vec<3, double>", pybind11::arg("v"));
		cl.def("__neg__", (class easy3d::Vec<3, double> (easy3d::Vec<3UL,double>::*)() const) &easy3d::Vec<3, double>::operator-, "C++: easy3d::Vec<3, double>::operator-() const --> class easy3d::Vec<3, double>");
		cl.def("dimension", (unsigned long (easy3d::Vec<3UL,double>::*)() const) &easy3d::Vec<3, double>::dimension, "C++: easy3d::Vec<3, double>::dimension() const --> unsigned long");
		cl.def("size", (unsigned long (easy3d::Vec<3UL,double>::*)() const) &easy3d::Vec<3, double>::size, "C++: easy3d::Vec<3, double>::size() const --> unsigned long");
		cl.def("data", (double * (easy3d::Vec<3UL,double>::*)()) &easy3d::Vec<3, double>::data, "C++: easy3d::Vec<3, double>::data() --> double *", pybind11::return_value_policy::automatic);
		cl.def("assign", (class easy3d::Vec<3, double> & (easy3d::Vec<3UL,double>::*)(const class easy3d::Vec<3, double> &)) &easy3d::Vec<3, double>::operator=, "C++: easy3d::Vec<3, double>::operator=(const class easy3d::Vec<3, double> &) --> class easy3d::Vec<3, double> &", pybind11::return_value_policy::automatic, pybind11::arg(""));

		{ // easy3d::Vec<3, double>::(anonymous union at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:520:9) file:easy3d/core/vec.h line:520

			{ // easy3d::Vec<3, double>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:522:13) file:easy3d/core/vec.h line:522
				cl.def_readwrite("x", &easy3d::Vec<3, double>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:522:13)::x);
				cl.def_readwrite("y", &easy3d::Vec<3, double>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:522:13)::y);
				cl.def_readwrite("z", &easy3d::Vec<3, double>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:522:13)::z);
			}

			{ // easy3d::Vec<3, double>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:523:13) file:easy3d/core/vec.h line:523
				cl.def_readwrite("r", &easy3d::Vec<3, double>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:523:13)::r);
				cl.def_readwrite("g", &easy3d::Vec<3, double>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:523:13)::g);
				cl.def_readwrite("b", &easy3d::Vec<3, double>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:523:13)::b);
			}

		}

	}
	{ // easy3d::Vec file:easy3d/core/vec.h line:583
		pybind11::class_<easy3d::Vec<4UL,int>, std::shared_ptr<easy3d::Vec<4UL,int>>> cl(M("easy3d"), "Vec_4UL_int_t", "");
		cl.def( pybind11::init( [](){ return new easy3d::Vec<4UL,int>(); } ) );
		cl.def( pybind11::init<int, int, int, int>(), pybind11::arg("x_in"), pybind11::arg("y_in"), pybind11::arg("z_in"), pybind11::arg("w_in") );

		cl.def( pybind11::init<const int &>(), pybind11::arg("s") );

		cl.def( pybind11::init( [](easy3d::Vec<4UL,int> const &o){ return new easy3d::Vec<4UL,int>(o); } ) );
		cl.def("length2", (int (easy3d::Vec<4UL,int>::*)() const) &easy3d::Vec<4, int>::length2, "C++: easy3d::Vec<4, int>::length2() const --> int");
		cl.def("length", (int (easy3d::Vec<4UL,int>::*)() const) &easy3d::Vec<4, int>::length, "C++: easy3d::Vec<4, int>::length() const --> int");
		cl.def("norm", (int (easy3d::Vec<4UL,int>::*)() const) &easy3d::Vec<4, int>::norm, "C++: easy3d::Vec<4, int>::norm() const --> int");
		cl.def("distance2", (int (easy3d::Vec<4UL,int>::*)(const class easy3d::Vec<4, int> &) const) &easy3d::Vec<4, int>::distance2, "C++: easy3d::Vec<4, int>::distance2(const class easy3d::Vec<4, int> &) const --> int", pybind11::arg("rhs"));
		cl.def("normalize", (class easy3d::Vec<4, int> & (easy3d::Vec<4UL,int>::*)()) &easy3d::Vec<4, int>::normalize, "C++: easy3d::Vec<4, int>::normalize() --> class easy3d::Vec<4, int> &", pybind11::return_value_policy::automatic);
		cl.def("dimension", (unsigned long (easy3d::Vec<4UL,int>::*)() const) &easy3d::Vec<4, int>::dimension, "C++: easy3d::Vec<4, int>::dimension() const --> unsigned long");
		cl.def("size", (unsigned long (easy3d::Vec<4UL,int>::*)() const) &easy3d::Vec<4, int>::size, "C++: easy3d::Vec<4, int>::size() const --> unsigned long");
		cl.def("__iadd__", (class easy3d::Vec<4, int> & (easy3d::Vec<4UL,int>::*)(const class easy3d::Vec<4, int> &)) &easy3d::Vec<4, int>::operator+=, "C++: easy3d::Vec<4, int>::operator+=(const class easy3d::Vec<4, int> &) --> class easy3d::Vec<4, int> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__isub__", (class easy3d::Vec<4, int> & (easy3d::Vec<4UL,int>::*)(const class easy3d::Vec<4, int> &)) &easy3d::Vec<4, int>::operator-=, "C++: easy3d::Vec<4, int>::operator-=(const class easy3d::Vec<4, int> &) --> class easy3d::Vec<4, int> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__imul__", (class easy3d::Vec<4, int> & (easy3d::Vec<4UL,int>::*)(const class easy3d::Vec<4, int> &)) &easy3d::Vec<4, int>::operator*=, "C++: easy3d::Vec<4, int>::operator*=(const class easy3d::Vec<4, int> &) --> class easy3d::Vec<4, int> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__itruediv__", (class easy3d::Vec<4, int> & (easy3d::Vec<4UL,int>::*)(const class easy3d::Vec<4, int> &)) &easy3d::Vec<4, int>::operator/=, "C++: easy3d::Vec<4, int>::operator/=(const class easy3d::Vec<4, int> &) --> class easy3d::Vec<4, int> &", pybind11::return_value_policy::automatic, pybind11::arg("v"));
		cl.def("__add__", (class easy3d::Vec<4, int> (easy3d::Vec<4UL,int>::*)(const class easy3d::Vec<4, int> &) const) &easy3d::Vec<4, int>::operator+, "C++: easy3d::Vec<4, int>::operator+(const class easy3d::Vec<4, int> &) const --> class easy3d::Vec<4, int>", pybind11::arg("v"));
		cl.def("__sub__", (class easy3d::Vec<4, int> (easy3d::Vec<4UL,int>::*)(const class easy3d::Vec<4, int> &) const) &easy3d::Vec<4, int>::operator-, "C++: easy3d::Vec<4, int>::operator-(const class easy3d::Vec<4, int> &) const --> class easy3d::Vec<4, int>", pybind11::arg("v"));
		cl.def("__neg__", (class easy3d::Vec<4, int> (easy3d::Vec<4UL,int>::*)() const) &easy3d::Vec<4, int>::operator-, "C++: easy3d::Vec<4, int>::operator-() const --> class easy3d::Vec<4, int>");
		cl.def("data", (int * (easy3d::Vec<4UL,int>::*)()) &easy3d::Vec<4, int>::data, "C++: easy3d::Vec<4, int>::data() --> int *", pybind11::return_value_policy::automatic);
		cl.def("assign", (class easy3d::Vec<4, int> & (easy3d::Vec<4UL,int>::*)(const class easy3d::Vec<4, int> &)) &easy3d::Vec<4, int>::operator=, "C++: easy3d::Vec<4, int>::operator=(const class easy3d::Vec<4, int> &) --> class easy3d::Vec<4, int> &", pybind11::return_value_policy::automatic, pybind11::arg(""));

		{ // easy3d::Vec<4, int>::(anonymous union at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:663:9) file:easy3d/core/vec.h line:663

			{ // easy3d::Vec<4, int>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:665:13) file:easy3d/core/vec.h line:665
				cl.def_readwrite("x", &easy3d::Vec<4, int>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:665:13)::x);
				cl.def_readwrite("y", &easy3d::Vec<4, int>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:665:13)::y);
				cl.def_readwrite("z", &easy3d::Vec<4, int>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:665:13)::z);
				cl.def_readwrite("w", &easy3d::Vec<4, int>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:665:13)::w);
			}

			{ // easy3d::Vec<4, int>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:666:13) file:easy3d/core/vec.h line:666
				cl.def_readwrite("r", &easy3d::Vec<4, int>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:666:13)::r);
				cl.def_readwrite("g", &easy3d::Vec<4, int>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:666:13)::g);
				cl.def_readwrite("b", &easy3d::Vec<4, int>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:666:13)::b);
				cl.def_readwrite("a", &easy3d::Vec<4, int>::(anonymous union)::(anonymous struct at /Users/lnan/Documents/Projects/Easy3D/easy3d/core/vec.h:666:13)::a);
			}

		}

	}
	// easy3d::dot(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &) file:easy3d/core/vec.h line:241
	M("easy3d").def("dot", (float (*)(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &)) &easy3d::dot<3UL,float>, "C++: easy3d::dot(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &) --> float", pybind11::arg("v1"), pybind11::arg("v2"));

	// easy3d::length(const class easy3d::Vec<3, float> &) file:easy3d/core/vec.h line:288
	M("easy3d").def("length", (float (*)(const class easy3d::Vec<3, float> &)) &easy3d::length<3UL,float>, "C++: easy3d::length(const class easy3d::Vec<3, float> &) --> float", pybind11::arg("v"));

	// easy3d::norm(const class easy3d::Vec<3, float> &) file:easy3d/core/vec.h line:290
	M("easy3d").def("norm", (float (*)(const class easy3d::Vec<3, float> &)) &easy3d::norm<3UL,float>, "C++: easy3d::norm(const class easy3d::Vec<3, float> &) --> float", pybind11::arg("v"));

	// easy3d::length2(const class easy3d::Vec<3, float> &) file:easy3d/core/vec.h line:292
	M("easy3d").def("length2", (float (*)(const class easy3d::Vec<3, float> &)) &easy3d::length2<3UL,float>, "C++: easy3d::length2(const class easy3d::Vec<3, float> &) --> float", pybind11::arg("v"));

	// easy3d::distance(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &) file:easy3d/core/vec.h line:294
	M("easy3d").def("distance", (float (*)(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &)) &easy3d::distance<3UL,float>, "C++: easy3d::distance(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &) --> float", pybind11::arg("v1"), pybind11::arg("v2"));

	// easy3d::normalize(const class easy3d::Vec<3, float> &) file:easy3d/core/vec.h line:298
	M("easy3d").def("normalize", (class easy3d::Vec<3, float> (*)(const class easy3d::Vec<3, float> &)) &easy3d::normalize<3UL,float>, "C++: easy3d::normalize(const class easy3d::Vec<3, float> &) --> class easy3d::Vec<3, float>", pybind11::arg("v"));

	// easy3d::det(const class easy3d::Vec<2, float> &, const class easy3d::Vec<2, float> &) file:easy3d/core/vec.h line:404
	M("easy3d").def("det", (float (*)(const class easy3d::Vec<2, float> &, const class easy3d::Vec<2, float> &)) &easy3d::det<float>, "C++: easy3d::det(const class easy3d::Vec<2, float> &, const class easy3d::Vec<2, float> &) --> float", pybind11::arg("v1"), pybind11::arg("v2"));

	// easy3d::dot(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &) file:easy3d/core/vec.h line:528
	M("easy3d").def("dot", (float (*)(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &)) &easy3d::dot<float>, "C++: easy3d::dot(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &) --> float", pybind11::arg("v1"), pybind11::arg("v2"));

	// easy3d::cross(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &) file:easy3d/core/vec.h line:533
	M("easy3d").def("cross", (class easy3d::Vec<3, float> (*)(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &)) &easy3d::cross<float>, "C++: easy3d::cross(const class easy3d::Vec<3, float> &, const class easy3d::Vec<3, float> &) --> class easy3d::Vec<3, float>", pybind11::arg("v1"), pybind11::arg("v2"));

	// easy3d::min() file:easy3d/core/constant.h line:50
	M("easy3d").def("min", (int (*)()) &easy3d::min<int>, "Function returning  for int type numbers.\n\nC++: easy3d::min() --> int");

	// easy3d::max() file:easy3d/core/constant.h line:52
	M("easy3d").def("max", (int (*)()) &easy3d::max<int>, "Function returning  for int type numbers.\n\nC++: easy3d::max() --> int");

	// easy3d::min() file:easy3d/core/constant.h line:54
	M("easy3d").def("min", (float (*)()) &easy3d::min<float>, "Function returning  for float type numbers.\n\nC++: easy3d::min() --> float");

	// easy3d::max() file:easy3d/core/constant.h line:56
	M("easy3d").def("max", (float (*)()) &easy3d::max<float>, "Function returning  for float type numbers.\n\nC++: easy3d::max() --> float");

	// easy3d::min() file:easy3d/core/constant.h line:58
	M("easy3d").def("min", (double (*)()) &easy3d::min<double>, "Function returning  for double type numbers.\n\nC++: easy3d::min() --> double");

	// easy3d::max() file:easy3d/core/constant.h line:60
	M("easy3d").def("max", (double (*)()) &easy3d::max<double>, "Function returning  for double type numbers.\n\nC++: easy3d::max() --> double");

}
