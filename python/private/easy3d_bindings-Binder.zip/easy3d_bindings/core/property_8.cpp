#include <easy3d/core/poly_mesh.h>
#include <easy3d/core/property.h>
#include <easy3d/core/surface_mesh.h>
#include <istream>
#include <memory>
#include <ostream>
#include <sstream> // __str__
#include <string>
#include <string_view>
#include <typeinfo>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

// easy3d::PropertyArray file:easy3d/core/property.h line:111
struct PyCallBack_easy3d_PropertyArray_easy3d_PolyMesh_CellConnectivity_t : public easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity> {
	using easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::PropertyArray;

	void reserve(unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity> *>(this), "reserve");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::reserve(a0);
	}
	void resize(unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity> *>(this), "resize");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::resize(a0);
	}
	void push_back() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity> *>(this), "push_back");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::push_back();
	}
	void reset(unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity> *>(this), "reset");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::reset(a0);
	}
	bool transfer(const class easy3d::BasePropertyArray & a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity> *>(this), "transfer");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return PropertyArray::transfer(a0);
	}
	bool transfer(const class easy3d::BasePropertyArray & a0, std::size_t a1, std::size_t a2) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity> *>(this), "transfer");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return PropertyArray::transfer(a0, a1, a2);
	}
	void shrink_to_fit() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity> *>(this), "shrink_to_fit");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::shrink_to_fit();
	}
	void swap(unsigned long a0, unsigned long a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity> *>(this), "swap");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::swap(a0, a1);
	}
	void copy(unsigned long a0, unsigned long a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity> *>(this), "copy");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::copy(a0, a1);
	}
	class easy3d::BasePropertyArray * clone() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity> *>(this), "clone");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<class easy3d::BasePropertyArray *>::value) {
				static pybind11::detail::override_caster_t<class easy3d::BasePropertyArray *> caster;
				return pybind11::detail::cast_ref<class easy3d::BasePropertyArray *>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<class easy3d::BasePropertyArray *>(std::move(o));
		}
		return PropertyArray::clone();
	}
	class easy3d::BasePropertyArray * empty_clone() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity> *>(this), "empty_clone");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<class easy3d::BasePropertyArray *>::value) {
				static pybind11::detail::override_caster_t<class easy3d::BasePropertyArray *> caster;
				return pybind11::detail::cast_ref<class easy3d::BasePropertyArray *>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<class easy3d::BasePropertyArray *>(std::move(o));
		}
		return PropertyArray::empty_clone();
	}
	const class std::type_info & type() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity> *>(this), "type");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<const class std::type_info &>::value) {
				static pybind11::detail::override_caster_t<const class std::type_info &> caster;
				return pybind11::detail::cast_ref<const class std::type_info &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<const class std::type_info &>(std::move(o));
		}
		return PropertyArray::type();
	}
};

// easy3d::PropertyArray file:easy3d/core/property.h line:111
struct PyCallBack_easy3d_PropertyArray_easy3d_SurfaceMesh_Vertex_t : public easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex> {
	using easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::PropertyArray;

	void reserve(unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex> *>(this), "reserve");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::reserve(a0);
	}
	void resize(unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex> *>(this), "resize");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::resize(a0);
	}
	void push_back() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex> *>(this), "push_back");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::push_back();
	}
	void reset(unsigned long a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex> *>(this), "reset");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::reset(a0);
	}
	bool transfer(const class easy3d::BasePropertyArray & a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex> *>(this), "transfer");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return PropertyArray::transfer(a0);
	}
	bool transfer(const class easy3d::BasePropertyArray & a0, std::size_t a1, std::size_t a2) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex> *>(this), "transfer");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return PropertyArray::transfer(a0, a1, a2);
	}
	void shrink_to_fit() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex> *>(this), "shrink_to_fit");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::shrink_to_fit();
	}
	void swap(unsigned long a0, unsigned long a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex> *>(this), "swap");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::swap(a0, a1);
	}
	void copy(unsigned long a0, unsigned long a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex> *>(this), "copy");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return PropertyArray::copy(a0, a1);
	}
	class easy3d::BasePropertyArray * clone() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex> *>(this), "clone");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<class easy3d::BasePropertyArray *>::value) {
				static pybind11::detail::override_caster_t<class easy3d::BasePropertyArray *> caster;
				return pybind11::detail::cast_ref<class easy3d::BasePropertyArray *>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<class easy3d::BasePropertyArray *>(std::move(o));
		}
		return PropertyArray::clone();
	}
	class easy3d::BasePropertyArray * empty_clone() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex> *>(this), "empty_clone");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<class easy3d::BasePropertyArray *>::value) {
				static pybind11::detail::override_caster_t<class easy3d::BasePropertyArray *> caster;
				return pybind11::detail::cast_ref<class easy3d::BasePropertyArray *>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<class easy3d::BasePropertyArray *>(std::move(o));
		}
		return PropertyArray::empty_clone();
	}
	const class std::type_info & type() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex> *>(this), "type");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<const class std::type_info &>::value) {
				static pybind11::detail::override_caster_t<const class std::type_info &> caster;
				return pybind11::detail::cast_ref<const class std::type_info &>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<const class std::type_info &>(std::move(o));
		}
		return PropertyArray::type();
	}
};

void bind_easy3d_core_property_8(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	{ // easy3d::PropertyArray file:easy3d/core/property.h line:111
		pybind11::class_<easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>, std::shared_ptr<easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>>, PyCallBack_easy3d_PropertyArray_easy3d_PolyMesh_CellConnectivity_t, easy3d::BasePropertyArray> cl(M("easy3d"), "PropertyArray_easy3d_PolyMesh_CellConnectivity_t", "");
		cl.def( pybind11::init( [](const std::string & a0){ return new easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>(a0); }, [](const std::string & a0){ return new PyCallBack_easy3d_PropertyArray_easy3d_PolyMesh_CellConnectivity_t(a0); } ), "doc");
		cl.def( pybind11::init<const std::string &, struct easy3d::PolyMesh::CellConnectivity>(), pybind11::arg("name"), pybind11::arg("t") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_PropertyArray_easy3d_PolyMesh_CellConnectivity_t const &o){ return new PyCallBack_easy3d_PropertyArray_easy3d_PolyMesh_CellConnectivity_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity> const &o){ return new easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>(o); } ) );
		cl.def("reserve", (void (easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::reserve, "C++: easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::reserve(unsigned long) --> void", pybind11::arg("n"));
		cl.def("resize", (void (easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::resize, "C++: easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::resize(unsigned long) --> void", pybind11::arg("n"));
		cl.def("push_back", (void (easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::*)()) &easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::push_back, "C++: easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::push_back() --> void");
		cl.def("reset", (void (easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::reset, "C++: easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::reset(unsigned long) --> void", pybind11::arg("idx"));
		cl.def("transfer", (bool (easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::*)(const class easy3d::BasePropertyArray &)) &easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::transfer, "C++: easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::transfer(const class easy3d::BasePropertyArray &) --> bool", pybind11::arg("other"));
		cl.def("transfer", (bool (easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::*)(const class easy3d::BasePropertyArray &, std::size_t, std::size_t)) &easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::transfer, "C++: easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::transfer(const class easy3d::BasePropertyArray &, std::size_t, std::size_t) --> bool", pybind11::arg("other"), pybind11::arg("from"), pybind11::arg("to"));
		cl.def("shrink_to_fit", (void (easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::*)()) &easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::shrink_to_fit, "C++: easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::shrink_to_fit() --> void");
		cl.def("swap", (void (easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::*)(unsigned long, unsigned long)) &easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::swap, "C++: easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::swap(unsigned long, unsigned long) --> void", pybind11::arg("i0"), pybind11::arg("i1"));
		cl.def("copy", (void (easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::*)(unsigned long, unsigned long)) &easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::copy, "C++: easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::copy(unsigned long, unsigned long) --> void", pybind11::arg("from"), pybind11::arg("to"));
		cl.def("clone", (class easy3d::BasePropertyArray * (easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::*)() const) &easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::clone, "C++: easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("empty_clone", (class easy3d::BasePropertyArray * (easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::*)() const) &easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::empty_clone, "C++: easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::empty_clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("type", (const class std::type_info & (easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::*)() const) &easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::type, "C++: easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::type() const --> const class std::type_info &", pybind11::return_value_policy::automatic);
		cl.def("data", (const struct easy3d::PolyMesh::CellConnectivity * (easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::*)() const) &easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::data, "C++: easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::data() const --> const struct easy3d::PolyMesh::CellConnectivity *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<struct easy3d::PolyMesh::CellConnectivity> & (easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::*)()) &easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::vector, "C++: easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::vector() --> class std::vector<struct easy3d::PolyMesh::CellConnectivity> &", pybind11::return_value_policy::automatic);
		cl.def("__getitem__", (struct easy3d::PolyMesh::CellConnectivity & (easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::operator[], "C++: easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::operator[](unsigned long) --> struct easy3d::PolyMesh::CellConnectivity &", pybind11::return_value_policy::automatic, pybind11::arg("_idx"));
		cl.def("assign", (class easy3d::PropertyArray<struct easy3d::PolyMesh::CellConnectivity> & (easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::*)(const class easy3d::PropertyArray<struct easy3d::PolyMesh::CellConnectivity> &)) &easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::operator=, "C++: easy3d::PropertyArray<easy3d::PolyMesh::CellConnectivity>::operator=(const class easy3d::PropertyArray<struct easy3d::PolyMesh::CellConnectivity> &) --> class easy3d::PropertyArray<struct easy3d::PolyMesh::CellConnectivity> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
		cl.def("reserve", (void (easy3d::BasePropertyArray::*)(unsigned long)) &easy3d::BasePropertyArray::reserve, "Reserve memory for n elements.\n\nC++: easy3d::BasePropertyArray::reserve(unsigned long) --> void", pybind11::arg("n"));
		cl.def("resize", (void (easy3d::BasePropertyArray::*)(unsigned long)) &easy3d::BasePropertyArray::resize, "Resize storage to hold n elements.\n\nC++: easy3d::BasePropertyArray::resize(unsigned long) --> void", pybind11::arg("n"));
		cl.def("shrink_to_fit", (void (easy3d::BasePropertyArray::*)()) &easy3d::BasePropertyArray::shrink_to_fit, "Free unused memory.\n\nC++: easy3d::BasePropertyArray::shrink_to_fit() --> void");
		cl.def("push_back", (void (easy3d::BasePropertyArray::*)()) &easy3d::BasePropertyArray::push_back, "Extend the number of elements by one.\n\nC++: easy3d::BasePropertyArray::push_back() --> void");
		cl.def("reset", (void (easy3d::BasePropertyArray::*)(unsigned long)) &easy3d::BasePropertyArray::reset, "Reset element to default value\n\nC++: easy3d::BasePropertyArray::reset(unsigned long) --> void", pybind11::arg("idx"));
		cl.def("transfer", (bool (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &)) &easy3d::BasePropertyArray::transfer, "Copy the entire properties from \n\nC++: easy3d::BasePropertyArray::transfer(const class easy3d::BasePropertyArray &) --> bool", pybind11::arg("other"));
		cl.def("transfer", (bool (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &, std::size_t, std::size_t)) &easy3d::BasePropertyArray::transfer, "Copy the property[from] of  to this->property[to].\n\nC++: easy3d::BasePropertyArray::transfer(const class easy3d::BasePropertyArray &, std::size_t, std::size_t) --> bool", pybind11::arg("other"), pybind11::arg("from"), pybind11::arg("to"));
		cl.def("swap", (void (easy3d::BasePropertyArray::*)(unsigned long, unsigned long)) &easy3d::BasePropertyArray::swap, "Let two elements swap their storage place.\n\nC++: easy3d::BasePropertyArray::swap(unsigned long, unsigned long) --> void", pybind11::arg("i0"), pybind11::arg("i1"));
		cl.def("copy", (void (easy3d::BasePropertyArray::*)(unsigned long, unsigned long)) &easy3d::BasePropertyArray::copy, "Let copy 'from' -> 'to'.\n\nC++: easy3d::BasePropertyArray::copy(unsigned long, unsigned long) --> void", pybind11::arg("from"), pybind11::arg("to"));
		cl.def("clone", (class easy3d::BasePropertyArray * (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::clone, "Return a deep copy of self.\n\nC++: easy3d::BasePropertyArray::clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("empty_clone", (class easy3d::BasePropertyArray * (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::empty_clone, "Return a empty copy of self.\n\nC++: easy3d::BasePropertyArray::empty_clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("type", (const class std::type_info & (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::type, "Return the type_info of the property\n\nC++: easy3d::BasePropertyArray::type() const --> const class std::type_info &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::name, "Return the name of the property\n\nC++: easy3d::BasePropertyArray::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::BasePropertyArray::*)(const std::string &)) &easy3d::BasePropertyArray::set_name, "Set the name of the property\n\nC++: easy3d::BasePropertyArray::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("is_same", (bool (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &) const) &easy3d::BasePropertyArray::is_same, "Test if two properties are the same.\n \n\n true only if their names and types are both identical.\n\nC++: easy3d::BasePropertyArray::is_same(const class easy3d::BasePropertyArray &) const --> bool", pybind11::arg("other"));
		cl.def("assign", (class easy3d::BasePropertyArray & (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &)) &easy3d::BasePropertyArray::operator=, "C++: easy3d::BasePropertyArray::operator=(const class easy3d::BasePropertyArray &) --> class easy3d::BasePropertyArray &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::PropertyArray file:easy3d/core/property.h line:111
		pybind11::class_<easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>, std::shared_ptr<easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>>, PyCallBack_easy3d_PropertyArray_easy3d_SurfaceMesh_Vertex_t, easy3d::BasePropertyArray> cl(M("easy3d"), "PropertyArray_easy3d_SurfaceMesh_Vertex_t", "");
		cl.def( pybind11::init( [](const std::string & a0){ return new easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>(a0); }, [](const std::string & a0){ return new PyCallBack_easy3d_PropertyArray_easy3d_SurfaceMesh_Vertex_t(a0); } ), "doc");
		cl.def( pybind11::init<const std::string &, struct easy3d::SurfaceMesh::Vertex>(), pybind11::arg("name"), pybind11::arg("t") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_PropertyArray_easy3d_SurfaceMesh_Vertex_t const &o){ return new PyCallBack_easy3d_PropertyArray_easy3d_SurfaceMesh_Vertex_t(o); } ) );
		cl.def( pybind11::init( [](easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex> const &o){ return new easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>(o); } ) );
		cl.def("reserve", (void (easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::reserve, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::reserve(unsigned long) --> void", pybind11::arg("n"));
		cl.def("resize", (void (easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::resize, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::resize(unsigned long) --> void", pybind11::arg("n"));
		cl.def("push_back", (void (easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::*)()) &easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::push_back, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::push_back() --> void");
		cl.def("reset", (void (easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::reset, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::reset(unsigned long) --> void", pybind11::arg("idx"));
		cl.def("transfer", (bool (easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::*)(const class easy3d::BasePropertyArray &)) &easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::transfer, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::transfer(const class easy3d::BasePropertyArray &) --> bool", pybind11::arg("other"));
		cl.def("transfer", (bool (easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::*)(const class easy3d::BasePropertyArray &, std::size_t, std::size_t)) &easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::transfer, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::transfer(const class easy3d::BasePropertyArray &, std::size_t, std::size_t) --> bool", pybind11::arg("other"), pybind11::arg("from"), pybind11::arg("to"));
		cl.def("shrink_to_fit", (void (easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::*)()) &easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::shrink_to_fit, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::shrink_to_fit() --> void");
		cl.def("swap", (void (easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::*)(unsigned long, unsigned long)) &easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::swap, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::swap(unsigned long, unsigned long) --> void", pybind11::arg("i0"), pybind11::arg("i1"));
		cl.def("copy", (void (easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::*)(unsigned long, unsigned long)) &easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::copy, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::copy(unsigned long, unsigned long) --> void", pybind11::arg("from"), pybind11::arg("to"));
		cl.def("clone", (class easy3d::BasePropertyArray * (easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::*)() const) &easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::clone, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("empty_clone", (class easy3d::BasePropertyArray * (easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::*)() const) &easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::empty_clone, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::empty_clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("type", (const class std::type_info & (easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::*)() const) &easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::type, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::type() const --> const class std::type_info &", pybind11::return_value_policy::automatic);
		cl.def("data", (const struct easy3d::SurfaceMesh::Vertex * (easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::*)() const) &easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::data, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::data() const --> const struct easy3d::SurfaceMesh::Vertex *", pybind11::return_value_policy::automatic);
		cl.def("vector", (class std::vector<struct easy3d::SurfaceMesh::Vertex> & (easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::*)()) &easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::vector, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::vector() --> class std::vector<struct easy3d::SurfaceMesh::Vertex> &", pybind11::return_value_policy::automatic);
		cl.def("__getitem__", (struct easy3d::SurfaceMesh::Vertex & (easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::*)(unsigned long)) &easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::operator[], "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::operator[](unsigned long) --> struct easy3d::SurfaceMesh::Vertex &", pybind11::return_value_policy::automatic, pybind11::arg("_idx"));
		cl.def("assign", (class easy3d::PropertyArray<struct easy3d::SurfaceMesh::Vertex> & (easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::*)(const class easy3d::PropertyArray<struct easy3d::SurfaceMesh::Vertex> &)) &easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::operator=, "C++: easy3d::PropertyArray<easy3d::SurfaceMesh::Vertex>::operator=(const class easy3d::PropertyArray<struct easy3d::SurfaceMesh::Vertex> &) --> class easy3d::PropertyArray<struct easy3d::SurfaceMesh::Vertex> &", pybind11::return_value_policy::automatic, pybind11::arg(""));
		cl.def("reserve", (void (easy3d::BasePropertyArray::*)(unsigned long)) &easy3d::BasePropertyArray::reserve, "Reserve memory for n elements.\n\nC++: easy3d::BasePropertyArray::reserve(unsigned long) --> void", pybind11::arg("n"));
		cl.def("resize", (void (easy3d::BasePropertyArray::*)(unsigned long)) &easy3d::BasePropertyArray::resize, "Resize storage to hold n elements.\n\nC++: easy3d::BasePropertyArray::resize(unsigned long) --> void", pybind11::arg("n"));
		cl.def("shrink_to_fit", (void (easy3d::BasePropertyArray::*)()) &easy3d::BasePropertyArray::shrink_to_fit, "Free unused memory.\n\nC++: easy3d::BasePropertyArray::shrink_to_fit() --> void");
		cl.def("push_back", (void (easy3d::BasePropertyArray::*)()) &easy3d::BasePropertyArray::push_back, "Extend the number of elements by one.\n\nC++: easy3d::BasePropertyArray::push_back() --> void");
		cl.def("reset", (void (easy3d::BasePropertyArray::*)(unsigned long)) &easy3d::BasePropertyArray::reset, "Reset element to default value\n\nC++: easy3d::BasePropertyArray::reset(unsigned long) --> void", pybind11::arg("idx"));
		cl.def("transfer", (bool (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &)) &easy3d::BasePropertyArray::transfer, "Copy the entire properties from \n\nC++: easy3d::BasePropertyArray::transfer(const class easy3d::BasePropertyArray &) --> bool", pybind11::arg("other"));
		cl.def("transfer", (bool (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &, std::size_t, std::size_t)) &easy3d::BasePropertyArray::transfer, "Copy the property[from] of  to this->property[to].\n\nC++: easy3d::BasePropertyArray::transfer(const class easy3d::BasePropertyArray &, std::size_t, std::size_t) --> bool", pybind11::arg("other"), pybind11::arg("from"), pybind11::arg("to"));
		cl.def("swap", (void (easy3d::BasePropertyArray::*)(unsigned long, unsigned long)) &easy3d::BasePropertyArray::swap, "Let two elements swap their storage place.\n\nC++: easy3d::BasePropertyArray::swap(unsigned long, unsigned long) --> void", pybind11::arg("i0"), pybind11::arg("i1"));
		cl.def("copy", (void (easy3d::BasePropertyArray::*)(unsigned long, unsigned long)) &easy3d::BasePropertyArray::copy, "Let copy 'from' -> 'to'.\n\nC++: easy3d::BasePropertyArray::copy(unsigned long, unsigned long) --> void", pybind11::arg("from"), pybind11::arg("to"));
		cl.def("clone", (class easy3d::BasePropertyArray * (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::clone, "Return a deep copy of self.\n\nC++: easy3d::BasePropertyArray::clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("empty_clone", (class easy3d::BasePropertyArray * (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::empty_clone, "Return a empty copy of self.\n\nC++: easy3d::BasePropertyArray::empty_clone() const --> class easy3d::BasePropertyArray *", pybind11::return_value_policy::automatic);
		cl.def("type", (const class std::type_info & (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::type, "Return the type_info of the property\n\nC++: easy3d::BasePropertyArray::type() const --> const class std::type_info &", pybind11::return_value_policy::automatic);
		cl.def("name", (const std::string & (easy3d::BasePropertyArray::*)() const) &easy3d::BasePropertyArray::name, "Return the name of the property\n\nC++: easy3d::BasePropertyArray::name() const --> const std::string &", pybind11::return_value_policy::automatic);
		cl.def("set_name", (void (easy3d::BasePropertyArray::*)(const std::string &)) &easy3d::BasePropertyArray::set_name, "Set the name of the property\n\nC++: easy3d::BasePropertyArray::set_name(const std::string &) --> void", pybind11::arg("n"));
		cl.def("is_same", (bool (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &) const) &easy3d::BasePropertyArray::is_same, "Test if two properties are the same.\n \n\n true only if their names and types are both identical.\n\nC++: easy3d::BasePropertyArray::is_same(const class easy3d::BasePropertyArray &) const --> bool", pybind11::arg("other"));
		cl.def("assign", (class easy3d::BasePropertyArray & (easy3d::BasePropertyArray::*)(const class easy3d::BasePropertyArray &)) &easy3d::BasePropertyArray::operator=, "C++: easy3d::BasePropertyArray::operator=(const class easy3d::BasePropertyArray &) --> class easy3d::BasePropertyArray &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
}
