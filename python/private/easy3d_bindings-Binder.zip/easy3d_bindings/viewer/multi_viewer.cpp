#include <__memory/shared_ptr.h>
#include <easy3d/core/box.h>
#include <easy3d/core/mat.h>
#include <easy3d/core/model.h>
#include <easy3d/core/quat.h>
#include <easy3d/core/vec.h>
#include <easy3d/renderer/camera.h>
#include <easy3d/renderer/drawable.h>
#include <easy3d/renderer/drawable_lines.h>
#include <easy3d/renderer/drawable_points.h>
#include <easy3d/renderer/drawable_triangles.h>
#include <easy3d/renderer/frame.h>
#include <easy3d/renderer/key_frame_interpolator.h>
#include <easy3d/renderer/manipulated_camera_frame.h>
#include <easy3d/renderer/manipulated_frame.h>
#include <easy3d/renderer/manipulator.h>
#include <easy3d/renderer/renderer.h>
#include <easy3d/renderer/state.h>
#include <easy3d/renderer/vertex_array_object.h>
#include <easy3d/viewer/multi_viewer.h>
#include <easy3d/viewer/offscreen.h>
#include <easy3d/viewer/viewer.h>
#include <functional>
#include <ios>
#include <memory>
#include <ostream>
#include <sstream> // __str__
#include <streambuf>
#include <string>
#include <string_view>
#include <vector>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

// easy3d::MultiViewer file:easy3d/viewer/multi_viewer.h line:45
struct PyCallBack_easy3d_MultiViewer : public easy3d::MultiViewer {
	using easy3d::MultiViewer::MultiViewer;

	using _binder_ret_0 = easy3d::Vec<3, float>;
	_binder_ret_0 point_under_pixel(int a0, int a1, bool & a2) const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "point_under_pixel");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2);
			if (pybind11::detail::cast_is_temporary_value_reference<_binder_ret_0>::value) {
				static pybind11::detail::override_caster_t<_binder_ret_0> caster;
				return pybind11::detail::cast_ref<_binder_ret_0>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<_binder_ret_0>(std::move(o));
		}
		return MultiViewer::point_under_pixel(a0, a1, a2);
	}
	bool snapshot() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "snapshot");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return MultiViewer::snapshot();
	}
	void init() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "init");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return MultiViewer::init();
	}
	void post_resize(int a0, int a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "post_resize");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return MultiViewer::post_resize(a0, a1);
	}
	void draw() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "draw");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return MultiViewer::draw();
	}
	bool mouse_press_event(int a0, int a1, int a2, int a3) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "mouse_press_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2, a3);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return MultiViewer::mouse_press_event(a0, a1, a2, a3);
	}
	bool mouse_release_event(int a0, int a1, int a2, int a3) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "mouse_release_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2, a3);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return MultiViewer::mouse_release_event(a0, a1, a2, a3);
	}
	bool mouse_drag_event(int a0, int a1, int a2, int a3, int a4, int a5) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "mouse_drag_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2, a3, a4, a5);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return MultiViewer::mouse_drag_event(a0, a1, a2, a3, a4, a5);
	}
	void exit() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "exit");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return Viewer::exit();
	}
	bool open() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "open");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::open();
	}
	bool save() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "save");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::save();
	}
	class easy3d::Model * add_model(const std::string & a0, bool a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "add_model");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<class easy3d::Model *>::value) {
				static pybind11::detail::override_caster_t<class easy3d::Model *> caster;
				return pybind11::detail::cast_ref<class easy3d::Model *>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<class easy3d::Model *>(std::move(o));
		}
		return Viewer::add_model(a0, a1);
	}
	bool delete_model(class easy3d::Model * a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "delete_model");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::delete_model(a0);
	}
	void pre_draw() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "pre_draw");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return Viewer::pre_draw();
	}
	void post_draw() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "post_draw");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return Viewer::post_draw();
	}
	bool mouse_free_move_event(int a0, int a1, int a2, int a3, int a4) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "mouse_free_move_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2, a3, a4);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::mouse_free_move_event(a0, a1, a2, a3, a4);
	}
	bool mouse_scroll_event(int a0, int a1, int a2, int a3) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "mouse_scroll_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2, a3);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::mouse_scroll_event(a0, a1, a2, a3);
	}
	bool char_input_event(unsigned int a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "char_input_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::char_input_event(a0);
	}
	bool key_press_event(int a0, int a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "key_press_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::key_press_event(a0, a1);
	}
	bool key_release_event(int a0, int a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "key_release_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::key_release_event(a0, a1);
	}
	bool drop_event(const class std::vector<std::string> & a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "drop_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::drop_event(a0);
	}
	bool focus_event(bool a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "focus_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::focus_event(a0);
	}
	bool callback_event_cursor_pos(double a0, double a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "callback_event_cursor_pos");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::callback_event_cursor_pos(a0, a1);
	}
	bool callback_event_mouse_button(int a0, int a1, int a2) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "callback_event_mouse_button");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::callback_event_mouse_button(a0, a1, a2);
	}
	bool callback_event_keyboard(int a0, int a1, int a2) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "callback_event_keyboard");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::callback_event_keyboard(a0, a1, a2);
	}
	bool callback_event_character(unsigned int a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "callback_event_character");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::callback_event_character(a0);
	}
	bool callback_event_scroll(double a0, double a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "callback_event_scroll");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::callback_event_scroll(a0, a1);
	}
	void callback_event_resize(int a0, int a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::MultiViewer *>(this), "callback_event_resize");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return Viewer::callback_event_resize(a0, a1);
	}
};

// easy3d::OffScreen file:easy3d/viewer/offscreen.h line:50
struct PyCallBack_easy3d_OffScreen : public easy3d::OffScreen {
	using easy3d::OffScreen::OffScreen;

	class easy3d::Model * add_model(const std::string & a0, bool a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "add_model");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<class easy3d::Model *>::value) {
				static pybind11::detail::override_caster_t<class easy3d::Model *> caster;
				return pybind11::detail::cast_ref<class easy3d::Model *>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<class easy3d::Model *>(std::move(o));
		}
		return OffScreen::add_model(a0, a1);
	}
	bool delete_model(class easy3d::Model * a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "delete_model");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return OffScreen::delete_model(a0);
	}
	void exit() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "exit");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return Viewer::exit();
	}
	bool open() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "open");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::open();
	}
	bool save() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "save");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::save();
	}
	bool snapshot() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "snapshot");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::snapshot();
	}
	using _binder_ret_0 = easy3d::Vec<3, float>;
	_binder_ret_0 point_under_pixel(int a0, int a1, bool & a2) const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "point_under_pixel");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2);
			if (pybind11::detail::cast_is_temporary_value_reference<_binder_ret_0>::value) {
				static pybind11::detail::override_caster_t<_binder_ret_0> caster;
				return pybind11::detail::cast_ref<_binder_ret_0>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<_binder_ret_0>(std::move(o));
		}
		return Viewer::point_under_pixel(a0, a1, a2);
	}
	void draw() const override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "draw");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return Viewer::draw();
	}
	void init() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "init");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return Viewer::init();
	}
	void pre_draw() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "pre_draw");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return Viewer::pre_draw();
	}
	void post_draw() override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "post_draw");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>();
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return Viewer::post_draw();
	}
	void post_resize(int a0, int a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "post_resize");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return Viewer::post_resize(a0, a1);
	}
	bool mouse_press_event(int a0, int a1, int a2, int a3) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "mouse_press_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2, a3);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::mouse_press_event(a0, a1, a2, a3);
	}
	bool mouse_release_event(int a0, int a1, int a2, int a3) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "mouse_release_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2, a3);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::mouse_release_event(a0, a1, a2, a3);
	}
	bool mouse_drag_event(int a0, int a1, int a2, int a3, int a4, int a5) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "mouse_drag_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2, a3, a4, a5);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::mouse_drag_event(a0, a1, a2, a3, a4, a5);
	}
	bool mouse_free_move_event(int a0, int a1, int a2, int a3, int a4) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "mouse_free_move_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2, a3, a4);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::mouse_free_move_event(a0, a1, a2, a3, a4);
	}
	bool mouse_scroll_event(int a0, int a1, int a2, int a3) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "mouse_scroll_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2, a3);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::mouse_scroll_event(a0, a1, a2, a3);
	}
	bool char_input_event(unsigned int a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "char_input_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::char_input_event(a0);
	}
	bool key_press_event(int a0, int a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "key_press_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::key_press_event(a0, a1);
	}
	bool key_release_event(int a0, int a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "key_release_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::key_release_event(a0, a1);
	}
	bool drop_event(const class std::vector<std::string> & a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "drop_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::drop_event(a0);
	}
	bool focus_event(bool a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "focus_event");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::focus_event(a0);
	}
	bool callback_event_cursor_pos(double a0, double a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "callback_event_cursor_pos");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::callback_event_cursor_pos(a0, a1);
	}
	bool callback_event_mouse_button(int a0, int a1, int a2) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "callback_event_mouse_button");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::callback_event_mouse_button(a0, a1, a2);
	}
	bool callback_event_keyboard(int a0, int a1, int a2) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "callback_event_keyboard");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1, a2);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::callback_event_keyboard(a0, a1, a2);
	}
	bool callback_event_character(unsigned int a0) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "callback_event_character");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::callback_event_character(a0);
	}
	bool callback_event_scroll(double a0, double a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "callback_event_scroll");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<bool>::value) {
				static pybind11::detail::override_caster_t<bool> caster;
				return pybind11::detail::cast_ref<bool>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<bool>(std::move(o));
		}
		return Viewer::callback_event_scroll(a0, a1);
	}
	void callback_event_resize(int a0, int a1) override {
		pybind11::gil_scoped_acquire gil;
		pybind11::function overload = pybind11::get_overload(static_cast<const easy3d::OffScreen *>(this), "callback_event_resize");
		if (overload) {
			auto o = overload.operator()<pybind11::return_value_policy::reference>(a0, a1);
			if (pybind11::detail::cast_is_temporary_value_reference<void>::value) {
				static pybind11::detail::override_caster_t<void> caster;
				return pybind11::detail::cast_ref<void>(std::move(o), caster);
			}
			return pybind11::detail::cast_safe<void>(std::move(o));
		}
		return Viewer::callback_event_resize(a0, a1);
	}
};

void bind_easy3d_viewer_multi_viewer(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	{ // easy3d::MultiViewer file:easy3d/viewer/multi_viewer.h line:45
		pybind11::class_<easy3d::MultiViewer, std::shared_ptr<easy3d::MultiViewer>, PyCallBack_easy3d_MultiViewer, easy3d::Viewer> cl(M("easy3d"), "MultiViewer", "A viewer that supports multiple views (arranged in a grid layout).\n \n\n\n     ");
		cl.def( pybind11::init( [](int const & a0, int const & a1){ return new easy3d::MultiViewer(a0, a1); }, [](int const & a0, int const & a1){ return new PyCallBack_easy3d_MultiViewer(a0, a1); } ), "doc");
		cl.def( pybind11::init<int, int, const std::string &>(), pybind11::arg("rows"), pybind11::arg("cols"), pybind11::arg("title") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_MultiViewer const &o){ return new PyCallBack_easy3d_MultiViewer(o); } ) );
		cl.def( pybind11::init( [](easy3d::MultiViewer const &o){ return new easy3d::MultiViewer(o); } ) );
		cl.def("assign", (void (easy3d::MultiViewer::*)(int, int, const class easy3d::Model *)) &easy3d::MultiViewer::assign, "Assigns the model  to the view at position ( \n \n\n This function assigns the model  to the view at position (  After that, the\n     model will be visualized in this view (regardless of other views visualizing the same model).\n \n\n You need to first add the model to the viewer by calling add_model(). The add_model() function\n      does not assign the model to any view for rendering. However, add_model() allows the viewer to\n      take ownership of the model.\n\nC++: easy3d::MultiViewer::assign(int, int, const class easy3d::Model *) --> void", pybind11::arg("row"), pybind11::arg("col"), pybind11::arg("m"));
		cl.def("assign", (void (easy3d::MultiViewer::*)(int, int, const class easy3d::Drawable *)) &easy3d::MultiViewer::assign, "Assigns the drawable  to the view at position ( \n  \n\n This function assigns the drawable  to the view at position (  After that, the\n      drawable will be visualized in this view (regardless of other views visualizing the same drawable).\n \n\n You need to first add the drawable to the viewer by calling add_drawable(). The add_drawable()\n      function does not assign the drawable to any view for rendering. However, add_drawable() allows the\n      viewer to take ownership of the drawable.\n\nC++: easy3d::MultiViewer::assign(int, int, const class easy3d::Drawable *) --> void", pybind11::arg("row"), pybind11::arg("col"), pybind11::arg("d"));
		cl.def("set_division_visible", (void (easy3d::MultiViewer::*)(bool)) &easy3d::MultiViewer::set_division_visible, "Sets the visibility of the splitting lines of the views (visible by default).\n\nC++: easy3d::MultiViewer::set_division_visible(bool) --> void", pybind11::arg("b"));
		cl.def("division_visible", (bool (easy3d::MultiViewer::*)() const) &easy3d::MultiViewer::division_visible, "Returns if the splitting lines of the views are visible.\n\nC++: easy3d::MultiViewer::division_visible() const --> bool");
		cl.def("point_under_pixel", (class easy3d::Vec<3, float> (easy3d::MultiViewer::*)(int, int, bool &) const) &easy3d::MultiViewer::point_under_pixel, "Query the XYZ coordinates of the surface point under the cursor.\n \n\n The cursor x-coordinate, relative to the left edge of the content area.\n \n\n The cursor y-coordinate, relative to the top edge of the content area.\n \n\n indicates whether the point was found or not.\n \n\n The coordinates of the 3D point located at pixel (x, y) on screen. The returned point is valid\n      only if found was returned true.\n \n\n The screen point (x, y) is expressed in the screen coordinate system with an origin in the\n      upper left corner. So it doesn't necessarily correspond to a pixel on High DPI devices, e.g., a\n      Mac with a Retina display. If your inherited viewer uses a customized content area, you must also\n      reimplement this function such that the x and y are relative to left and top edges of the content\n      area, respectively.\n\nC++: easy3d::MultiViewer::point_under_pixel(int, int, bool &) const --> class easy3d::Vec<3, float>", pybind11::arg("x"), pybind11::arg("y"), pybind11::arg("found"));
		cl.def("rows", (int (easy3d::MultiViewer::*)() const) &easy3d::MultiViewer::rows, "Return the number of rows (of the grid-like layout) of the viewer.\n\nC++: easy3d::MultiViewer::rows() const --> int");
		cl.def("columns", (int (easy3d::MultiViewer::*)() const) &easy3d::MultiViewer::columns, "Return the number of columns (of the grid-like layout) of the viewer.\n\nC++: easy3d::MultiViewer::columns() const --> int");
		cl.def("set_layout", (void (easy3d::MultiViewer::*)(int, int)) &easy3d::MultiViewer::set_layout, "Set/Change the layout of the viewer.\n \n\n The number of rows (of the grid-like layout).\n \n\n The number of columns (of the grid-like layout).\n\nC++: easy3d::MultiViewer::set_layout(int, int) --> void", pybind11::arg("rows"), pybind11::arg("cols"));
		cl.def("snapshot", (bool (easy3d::MultiViewer::*)() const) &easy3d::MultiViewer::snapshot, "Take a snapshot of the screen and save it to a file.\n \n\n This method takes a snapshot of the screen and saves the snapshot into an image file.\n          Internally, it will pop up a file dialog for specifying the file name.\n \n\n true on success and false otherwise.\n\nC++: easy3d::MultiViewer::snapshot() const --> bool");
		cl.def("assign", (class easy3d::MultiViewer & (easy3d::MultiViewer::*)(const class easy3d::MultiViewer &)) &easy3d::MultiViewer::operator=, "C++: easy3d::MultiViewer::operator=(const class easy3d::MultiViewer &) --> class easy3d::MultiViewer &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
	{ // easy3d::OffScreen file:easy3d/viewer/offscreen.h line:50
		pybind11::class_<easy3d::OffScreen, std::shared_ptr<easy3d::OffScreen>, PyCallBack_easy3d_OffScreen> cl(M("easy3d"), "OffScreen", "Offscreen rendering.\n \n\n\n \n To use offscreen rendering, simply create an instance of OffScreen and call the render() method, e.g.,\n      \n\n\n\n\n\n\n\n\n\n     ");
		cl.def( pybind11::init( [](){ return new easy3d::OffScreen(); }, [](){ return new PyCallBack_easy3d_OffScreen(); } ), "doc");
		cl.def( pybind11::init( [](int const & a0){ return new easy3d::OffScreen(a0); }, [](int const & a0){ return new PyCallBack_easy3d_OffScreen(a0); } ), "doc");
		cl.def( pybind11::init<int, int>(), pybind11::arg("width"), pybind11::arg("height") );

		cl.def( pybind11::init( [](PyCallBack_easy3d_OffScreen const &o){ return new PyCallBack_easy3d_OffScreen(o); } ) );
		cl.def( pybind11::init( [](easy3d::OffScreen const &o){ return new easy3d::OffScreen(o); } ) );
		cl.def("camera", (class easy3d::Camera * (easy3d::OffScreen::*)()) &easy3d::OffScreen::camera, "Returns the camera used by the offscreen renderer. See \n\nC++: easy3d::OffScreen::camera() --> class easy3d::Camera *", pybind11::return_value_policy::automatic);
		cl.def("render", [](easy3d::OffScreen const &o, const std::string & a0) -> bool { return o.render(a0); }, "", pybind11::arg("file_name"));
		cl.def("render", [](easy3d::OffScreen const &o, const std::string & a0, float const & a1) -> bool { return o.render(a0, a1); }, "", pybind11::arg("file_name"), pybind11::arg("scaling"));
		cl.def("render", [](easy3d::OffScreen const &o, const std::string & a0, float const & a1, int const & a2) -> bool { return o.render(a0, a1, a2); }, "", pybind11::arg("file_name"), pybind11::arg("scaling"), pybind11::arg("samples"));
		cl.def("render", [](easy3d::OffScreen const &o, const std::string & a0, float const & a1, int const & a2, int const & a3) -> bool { return o.render(a0, a1, a2, a3); }, "", pybind11::arg("file_name"), pybind11::arg("scaling"), pybind11::arg("samples"), pybind11::arg("back_ground"));
		cl.def("render", (bool (easy3d::OffScreen::*)(const std::string &, float, int, int, bool) const) &easy3d::OffScreen::render, "Render the current scene into an image file. Supported image format: png, jpg, bmp, and tga.\n \n\n This function renders the scene into a framebuffer and takes a snapshot of the framebuffer.\n      It allows the snapshot image to have a dimension different from the offscreen renderer, and it\n      has no limit on the image size (if memory allows).\n \n\n The image file name.\n \n\n The scaling factor that determines the size of the image (default to 1.0, same size as\n      the offscreen renderer), i.e.,\n      image_width = width() * scaling;\n      image_height = height() * scaling;\n \n\n The required number of samples for antialiased rendering (which can be different from\n      that of the default framebuffer). The default value is 4.\n \n\n Determines the background color. 0: current color; 1: white; 2: transparent.\n \n\n Expand the frustum to ensure the image aspect ratio.\n \n\n true on success and false otherwise.\n\nC++: easy3d::OffScreen::render(const std::string &, float, int, int, bool) const --> bool", pybind11::arg("file_name"), pybind11::arg("scaling"), pybind11::arg("samples"), pybind11::arg("back_ground"), pybind11::arg("expand"));
		cl.def("resize", (void (easy3d::OffScreen::*)(int, int)) &easy3d::OffScreen::resize, "Set/Change the size of the offscreen renderer.\n \n\n The requested width/height (in pixels) of the offscreen renderer.\n\nC++: easy3d::OffScreen::resize(int, int) --> void", pybind11::arg("w"), pybind11::arg("h"));
		cl.def("width", (int (easy3d::OffScreen::*)() const) &easy3d::OffScreen::width, "Returns the width of the offscreen renderer.\n\nC++: easy3d::OffScreen::width() const --> int");
		cl.def("height", (int (easy3d::OffScreen::*)() const) &easy3d::OffScreen::height, "Returns the height of the offscreen renderer.\n\nC++: easy3d::OffScreen::height() const --> int");
		cl.def("set_background_color", (void (easy3d::OffScreen::*)(const class easy3d::Vec<4, float> &)) &easy3d::OffScreen::set_background_color, "Set the background color of the offscreen renderer\n \n\n The background color.\n\nC++: easy3d::OffScreen::set_background_color(const class easy3d::Vec<4, float> &) --> void", pybind11::arg("c"));
		cl.def("background_color", (const class easy3d::Vec<4, float> & (easy3d::OffScreen::*)() const) &easy3d::OffScreen::background_color, "Query the background color of the offscreen renderer.\n \n\n The background color of the offscreen renderer\n\nC++: easy3d::OffScreen::background_color() const --> const class easy3d::Vec<4, float> &", pybind11::return_value_policy::automatic);
		cl.def("add_model", [](easy3d::OffScreen &o, const std::string & a0) -> easy3d::Model * { return o.add_model(a0); }, "", pybind11::return_value_policy::automatic, pybind11::arg("file_name"));
		cl.def("add_model", (class easy3d::Model * (easy3d::OffScreen::*)(const std::string &, bool)) &easy3d::OffScreen::add_model, "Add a model from a file to the offscreen renderer. On success, the offscreen renderer\n        will be in charge of the memory management of the model. The loaded model can be\n        accessed by the 'current_model()' method.\n \n\n This method loads a model into the offscreen renderer. It allows the user to control if\n          default drawables will be created. The default drawables are\n            - for point clouds: \"vertices\".\n            - for surface meshes: \"faces\", \"vertices\", \"edges\", \"borders\", and \"locks\".\n            - for graphs: \"vertices\" and \"edges\".\n            - polyhedral meshes: \"faces:border\"， \"faces:interior\"， \"vertices\"， and \"edges\".\n          These drawables are usually sufficient for basic rendering of the model. In case\n          the default drawables don't meet the particular visualization purpose, you can\n          set 'create_default_drawables' to false and create your needed drawables by \n          calling model->renderer()->add_[type]_drawable(). Here the [type] must be one of \n          \"points\", \"lines\", and \"triangles'.\n \n\n The string of the file name.\n \n\n If true, the default drawables will be created. \n \n\n The pointer to the model added to the offscreen renderer (nullptr if failed).\n \n\n\n         \n\nC++: easy3d::OffScreen::add_model(const std::string &, bool) --> class easy3d::Model *", pybind11::return_value_policy::automatic, pybind11::arg("file_name"), pybind11::arg("create_default_drawables"));
		cl.def("add_model", [](easy3d::OffScreen &o, class std::shared_ptr<class easy3d::Model> const & a0) -> easy3d::Model * { return o.add_model(a0); }, "", pybind11::return_value_policy::automatic, pybind11::arg("model"));
		cl.def("add_model", (class easy3d::Model * (easy3d::OffScreen::*)(class std::shared_ptr<class easy3d::Model>, bool)) &easy3d::OffScreen::add_model, "Add an existing model to the offscreen renderer. On success, the offscreen renderer will be in\n      charge of its memory management.\n \n\n This method adds a model into the offscreen renderer. It allows the user to control if\n          default drawables will be created. The default drawables are\n            - for point clouds: \"vertices\".\n            - for surface meshes: \"faces\", \"vertices\", \"edges\", \"borders\", and \"locks\".\n            - for graphs: \"vertices\" and \"edges\".\n            - polyhedral meshes: \"faces:border\"， \"faces:interior\"， \"vertices\"， and \"edges\".\n          These drawables are usually sufficient for basic rendering of the model. In case\n          the default drawables don't meet the particular visualization purpose, you can\n          set 'create_default_drawables' to false and create your needed drawables by\n          calling model->renderer()->add_[type]_drawable(). Here the [type] must be one of\n          \"points\", \"lines\", and \"triangles'.\n \n\n The pointer to the model.\n \n\n If true, the default drawables will be created.\n \n\n The pointer to the model added to the offscreen renderer (nullptr if failed).\n \n\n\n         \n\nC++: easy3d::OffScreen::add_model(class std::shared_ptr<class easy3d::Model>, bool) --> class easy3d::Model *", pybind11::return_value_policy::automatic, pybind11::arg("model"), pybind11::arg("create_default_drawables"));
		cl.def("delete_model", (bool (easy3d::OffScreen::*)(class easy3d::Model *)) &easy3d::OffScreen::delete_model, "Delete a model. The memory of the model will be released and its existing drawables\n        also be deleted.\n \n\n The pointer to the model.\n \n\n True if the model has been deleted.\n\nC++: easy3d::OffScreen::delete_model(class easy3d::Model *) --> bool", pybind11::arg("model"));
		cl.def("models", (const class std::vector<class std::shared_ptr<class easy3d::Model> > & (easy3d::OffScreen::*)() const) &easy3d::OffScreen::models, "Query the models managed by this offscreen renderer.\n \n\n The models managed by this offscreen renderer.\n\nC++: easy3d::OffScreen::models() const --> const class std::vector<class std::shared_ptr<class easy3d::Model> > &", pybind11::return_value_policy::automatic);
		cl.def("current_model", (class easy3d::Model * (easy3d::OffScreen::*)() const) &easy3d::OffScreen::current_model, "Query the active model.\n \n\n The offscreen renderer can manage multiple models, and only one model is actively being processed.\n      This method is used to identify this active model.\n \n\n The active model.\n\nC++: easy3d::OffScreen::current_model() const --> class easy3d::Model *", pybind11::return_value_policy::automatic);
		cl.def("add_drawable", (class easy3d::Drawable * (easy3d::OffScreen::*)(class std::shared_ptr<class easy3d::Drawable>)) &easy3d::OffScreen::add_drawable, "Add a drawable to the offscreen renderer. On success, the offscreen renderer will be in charge of\n      its memory management.\n \n\n The use of drawables for visualization is quite flexible. Drawables are\n          typically created for rendering 3D models (e.g., point clouds, meshes, graphs)\n          and a 3D model is usually loaded from a file or generated by an algorithm. This\n          method allows the user to visualize drawables without defining a 3D model.\n \n\n The pointer to the drawable.\n \n\n The pointer of the drawable added to the viewer.\n\nC++: easy3d::OffScreen::add_drawable(class std::shared_ptr<class easy3d::Drawable>) --> class easy3d::Drawable *", pybind11::return_value_policy::automatic, pybind11::arg("drawable"));
		cl.def("delete_drawable", (bool (easy3d::OffScreen::*)(class easy3d::Drawable *)) &easy3d::OffScreen::delete_drawable, "Delete the drawable from the offscreen renderer. The related drawables will also be deleted.\n \n\n The pointer to the drawable.\n \n\n True if the drawable has been deleted.\n\nC++: easy3d::OffScreen::delete_drawable(class easy3d::Drawable *) --> bool", pybind11::arg("drawable"));
		cl.def("drawables", (const class std::vector<class std::shared_ptr<class easy3d::Drawable> > & (easy3d::OffScreen::*)() const) &easy3d::OffScreen::drawables, "Query the drawables managed by this offscreen renderer.\n \n\n The drawables managed by this offscreen renderer.\n\nC++: easy3d::OffScreen::drawables() const --> const class std::vector<class std::shared_ptr<class easy3d::Drawable> > &", pybind11::return_value_policy::automatic);
		cl.def("clear_scene", (void (easy3d::OffScreen::*)()) &easy3d::OffScreen::clear_scene, "Delete all visual contents of the offscreen renderer (all models and drawables).\n\nC++: easy3d::OffScreen::clear_scene() --> void");
		cl.def("assign", (class easy3d::OffScreen & (easy3d::OffScreen::*)(const class easy3d::OffScreen &)) &easy3d::OffScreen::operator=, "C++: easy3d::OffScreen::operator=(const class easy3d::OffScreen &) --> class easy3d::OffScreen &", pybind11::return_value_policy::automatic, pybind11::arg(""));
	}
}
