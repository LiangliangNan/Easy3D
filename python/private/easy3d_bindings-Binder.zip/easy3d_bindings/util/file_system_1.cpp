#include <easy3d/util/file_system.h>
#include <memory>
#include <string>
#include <string_view>

#include <functional>
#include <pybind11/pybind11.h>
#include <string>
#include <pybind11/stl.h>


#ifndef BINDER_PYBIND11_TYPE_CASTER
	#define BINDER_PYBIND11_TYPE_CASTER
	PYBIND11_DECLARE_HOLDER_TYPE(T, std::shared_ptr<T>, false)
	PYBIND11_DECLARE_HOLDER_TYPE(T, T*, false)
	PYBIND11_MAKE_OPAQUE(std::shared_ptr<void>)
#endif

void bind_easy3d_util_file_system_1(std::function< pybind11::module &(std::string const &namespace_) > &M)
{
	// easy3d::file_system::convert_to_native_style(const std::string &) file:easy3d/util/file_system.h line:295
	M("easy3d::file_system").def("convert_to_native_style", (std::string (*)(const std::string &)) &easy3d::file_system::convert_to_native_style, "Convert a path string such that it uses the current platform's path separators.\n \n\n The path string.\n \n\n The path in native style.\n \n\n convert_to_windows_style(), convert_to_unix_style().\n\nC++: easy3d::file_system::convert_to_native_style(const std::string &) --> std::string", pybind11::arg("path"));

	// easy3d::file_system::native_path_separator() file:easy3d/util/file_system.h line:301
	M("easy3d::file_system").def("native_path_separator", (char (*)()) &easy3d::file_system::native_path_separator, "Gets the path separator of the current platform.\n \n\n The path separator in native style.\n\nC++: easy3d::file_system::native_path_separator() --> char");

	// easy3d::file_system::is_native_style(const std::string &) file:easy3d/util/file_system.h line:307
	M("easy3d::file_system").def("is_native_style", (bool (*)(const std::string &)) &easy3d::file_system::is_native_style, "Checks sif the path contains only the current platform's path separators.\n \n\n true if the path contains only the current platform's path separators.\n\nC++: easy3d::file_system::is_native_style(const std::string &) --> bool", pybind11::arg("path"));

	// easy3d::file_system::copy_file(const std::string &, const std::string &) file:easy3d/util/file_system.h line:315
	M("easy3d::file_system").def("copy_file", (bool (*)(const std::string &, const std::string &)) &easy3d::file_system::copy_file, "Makes a copy of an existing file.\n \n\n The file name of the original file.\n \n\n The file name of the copy\n \n\n true on success.\n\nC++: easy3d::file_system::copy_file(const std::string &, const std::string &) --> bool", pybind11::arg("original"), pybind11::arg("copy"));

	// easy3d::file_system::file_contains_string(const std::string &, const std::string &) file:easy3d/util/file_system.h line:323
	M("easy3d::file_system").def("file_contains_string", (bool (*)(const std::string &, const std::string &)) &easy3d::file_system::file_contains_string, "Checks if a file contains string 'str'.\n \n\n The string of the file name.\n \n\n The string to be checked.\n \n\n true if the file contains the string.\n\nC++: easy3d::file_system::file_contains_string(const std::string &, const std::string &) --> bool", pybind11::arg("filename"), pybind11::arg("str"));

	// easy3d::file_system::read_file_to_string(const std::string &, std::string &) file:easy3d/util/file_system.h line:330
	M("easy3d::file_system").def("read_file_to_string", (void (*)(const std::string &, std::string &)) &easy3d::file_system::read_file_to_string, "Reads the contents of a file into a string.\n \n\n The string of the file name.\n \n\n The destination string.\n\nC++: easy3d::file_system::read_file_to_string(const std::string &, std::string &) --> void", pybind11::arg("filename"), pybind11::arg("str"));

	// easy3d::file_system::write_string_to_file(const std::string &, const std::string &) file:easy3d/util/file_system.h line:337
	M("easy3d::file_system").def("write_string_to_file", (void (*)(const std::string &, const std::string &)) &easy3d::file_system::write_string_to_file, "Writes the string into a file.\n \n\n The string.\n \n\n The string of the file name.\n\nC++: easy3d::file_system::write_string_to_file(const std::string &, const std::string &) --> void", pybind11::arg("str"), pybind11::arg("filename"));

}
