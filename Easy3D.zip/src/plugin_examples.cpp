/*
*	Copyright (C) 2015 by Liangliang Nan (liangliang.nan@gmail.com)
*
*	This file is part of EasyGUI: software for processing and rendering
*   meshes and point clouds.
*
*	EasyGUI is free software; you can redistribute it and/or modify
*	it under the terms of the GNU General Public License Version 3
*	as published by the Free Software Foundation.
*
*	EasyGUI is distributed in the hope that it will be useful,
*	but WITHOUT ANY WARRANTY; without even the implied warranty of
*	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
*	GNU General Public License for more details.
*
*	You should have received a copy of the GNU General Public License
*	along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "plugin_examples.h"

#include <imgui.h>
#include <imgui_impl_glfw.h>
#include <imgui_impl_opengl3.h>
#include <GLFW/glfw3.h>

#include "ImGuiHelpers.h"

#include <iostream>
#include <algorithm>


bool PluginSmartBox::draw() {

	static double doubleVariable = 0.1;

	// Add new group
	if (ImGui::CollapsingHeader(title_.c_str(), ImGuiTreeNodeFlags_DefaultOpen))
	{
		ImGui::PushID(title_.c_str());	//  to avoid ID conflict
		// Expose variable directly ...
		//ImGui::InputDouble("double", &doubleVariable, 0, 0, "%.4f");
		ImGui::DragScalar("double", ImGuiDataType_Double, &doubleVariable, 0.1f, 0, 0, "%.4f");

		// ... or using a custom callback
		static bool boolVariable = true;
		if (ImGui::Checkbox("bool", &boolVariable))
		{
			// do something
			std::cout << "boolVariable: " << std::boolalpha << boolVariable << std::endl;
		}

		// Expose an enumeration type
		enum Orientation { Up = 0, Down, Left, Right };
		static Orientation dir = Up;
		ImGui::Combo("Direction", (int *)(&dir), "Up\0Down\0Left\0Right\0\0");

		// We can also use a std::vector<std::string> defined dynamically
		static int num_choices = 3;
		static std::vector<std::string> choices;
		static int idx_choice = 0;
		if (ImGui::InputInt("Num letters", &num_choices))
		{
			num_choices = std::max(1, std::min(26, num_choices));
		}
		if (num_choices != (int)choices.size())
		{
			choices.resize(num_choices);
			for (int i = 0; i < num_choices; ++i)
				choices[i] = std::string(1, 'A' + i);
			if (idx_choice >= num_choices)
				idx_choice = num_choices - 1;
		}
		ImGui::Combo("Letter", &idx_choice, choices);

		// Add a button
		if (ImGui::Button("Print Hello", ImVec2(-1, 0)))
		{
			std::cout << "Hello\n";
		}
		ImGui::PopID();
	}
	return false;
}



bool PluginPolyFit::draw() {

	static double doubleVariable = 0.1;

	// Add new group
	if (ImGui::CollapsingHeader(title_.c_str(), ImGuiTreeNodeFlags_DefaultOpen))
	{
		ImGui::PushID(title_.c_str());	//  to avoid ID conflict
		// Expose variable directly ...
		ImGui::InputDouble("double", &doubleVariable, 0, 0, "%.4f");
		//ImGui::DragScalar("double", ImGuiDataType_Double, &doubleVariable, 0.1, 0, 0, "%.4f");

		// ... or using a custom callback
		static bool boolVariable = true;
		if (ImGui::Checkbox("bool", &boolVariable))
		{
			// do something
			std::cout << "boolVariable: " << std::boolalpha << boolVariable << std::endl;
		}

		// Expose an enumeration type
		enum Orientation { Up = 0, Down, Left, Right };
		static Orientation dir = Up;
		ImGui::Combo("Direction", (int *)(&dir), "Up\0Down\0Left\0Right\0\0");

		// We can also use a std::vector<std::string> defined dynamically
		static int num_choices = 3;
		static std::vector<std::string> choices;
		static int idx_choice = 0;
		if (ImGui::InputInt("Num letters", &num_choices))
		{
			num_choices = std::max(1, std::min(26, num_choices));
		}
		if (num_choices != (int)choices.size())
		{
			choices.resize(num_choices);
			for (int i = 0; i < num_choices; ++i)
				choices[i] = std::string(1, 'A' + i);
			if (idx_choice >= num_choices)
				idx_choice = num_choices - 1;
		}
		ImGui::Combo("Letter", &idx_choice, choices);

		// Add a button
		if (ImGui::Button("Print Hello", ImVec2(-1, 0)))
		{
			std::cout << "Hello\n";
		}
		ImGui::PopID();
	}
	return false;
}